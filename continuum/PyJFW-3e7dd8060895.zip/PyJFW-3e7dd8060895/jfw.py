from pywintypes import com_error
import win32gui
import win32com.client

class JFWAPI(object):

 def __init__(self):
  try:
   self.object = win32com.client.Dispatch("FreedomSci.JawsApi")
  except com_error: #try jfwapi
   try:
    self.object = win32com.client.Dispatch("jfwapi")
   except com_error: #give up
    raise WindowsError('Unable to initialize the JFW API')

 def say_string(self, message, interrupt=False):
  self.object.SayString(message, interrupt)

 def run_script(self, script_name, *args):
  self.object.RunScript('%s%s' % (script_name, self._make_argument_string(*args)))
  
 def run_function(self, function_name, *args):
  self.object.RunFunction('%s%s' % (function_name, self._make_argument_string(*args)))
  
 def _make_argument_string(self, *args):
  new_args = ""
  for a in args:
   if isinstance(a, basestring):
    new_arg = '"%s"' % a
   else:
    new_arg = a
   new_args = '%s, %s' % (new_args, new_arg)
  new_args = '(%s)' % (new_args[2:])
  return new_args

 def is_loaded(self):
  try:
   return self.object.SayString('',0) == True or win32gui.FindWindow("JFWUI2", "JAWS") != 0
  except:
   return False


class Scripts(object):
 """Transparently passes method calls on to RunScript calls."""

 def __init__(self):
  super(Scripts, self).__init__()
  self.JFW_API = JFWAPI()

 def __getattr__(self, script):
  return lambda *a: self.JFW_API.run_function(script, *a)

class Functions(object):
 """Transparently passes method calls on to RunFunction calls."""

 def __init__(self):
  super(Functions, self).__init__()
  self.JFW_API = JFWAPI()

 def __getattr__(self, function):
  return lambda *a: self.JFW_API.run_function(function, *a)
