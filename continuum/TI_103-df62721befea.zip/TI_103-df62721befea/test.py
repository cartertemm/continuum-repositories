import ti103
import x10

driver = ti103.TI103()
studio = x10.X10Object(driver=driver, housecode='a', address=1)

heater = x10.X10Object(driver=driver, housecode='b', address=1)
