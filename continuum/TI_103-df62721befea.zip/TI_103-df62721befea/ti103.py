import serial


class TI103(object):
	baud = 19200
	prefix = '$>28'
	suffix = '#'

	def __init__(self, serial_port='COM1', address='00', ):
		self.port = serial.serial_for_url(serial_port, self.baud)
		self.address = address

	def read(self):
		res = [self.port.read(size=1)]
		while res[-1] != self.suffix:
			res.append(self.port.read(size=1))
		return "".join(res)

	def transmit(self, data):
		self.send(1, data)
		return self.read()

	def query(self):
		self.send(0, 0)
		return self.read()

	def send(self, command, arguments=None):
		to_send = self.prefix + str(self.address) + str(command)
		if arguments is not None:
			to_send += str(arguments)
		to_send += str(self.calculate_checksum(to_send)).upper()
		to_send += '#'
		return self.port.write(to_send)

	@staticmethod
	def calculate_checksum(command_string):
		return hex(sum([ord(x) for x in command_string]))[-2:]
