
class X10Object(object):

	def __init__(self, driver, housecode, address):
		self.driver = driver
		self.housecode = housecode
		self.address = address

	def on(self):
		self.driver.transmit(self.build_command('on'))

	def off(self):
		self.driver.transmit(self.build_command('off'))

	def build_command(self, command):
		address = self.get_address()
		command = '%s%s' % (self.housecode, command.upper())
		return '%s%s %s%s' % (address, address, command, command)

	def get_address(self):
		return '%s%.2d' % (self.housecode.upper(), int(self.address))

	def __str__(self):
		return self.get_address()

	def __repr__(self):
		return '<%s at %s address=%s>' % (self.__class__.__name__, hex(id(self)), self.get_address())


class X10Light(X10Object):

	def dim(self):
		self.driver.transmit(self.build_command('dim'))

def populate_addresses(driver):
	for hc in 'abcdefghijklmnop'.upper():
		for addr in xrange(1, 17):
			yield X10Object(driver=driver, housecode=hc, address=addr)

