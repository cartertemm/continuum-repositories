
 The accessible_output library
================================================================================

:Author: Christopher Toth <Q@Qwitter-Client.net>
:Date: $Date: 06-14-2012 18:30:00 -0400 (Thu, Jun 14, 2012)
:Web site: http://q-continuum.net
:Copyright: 2012


.. contents::

================================================================================
Introduction
================================================================================

  Accessible Output provides a standard way for developers to output text in either speech or braille utilizing the user's preinstalled screen reader.  Using accessible_output makes creating self-voicing applications extremely easy.  

================================================================================
Basic Usage
================================================================================

The high level interface to accessible_output looks like:

>>> from accessible_output.main_output import Output
>>> output = Output(braille=True, speech=True)
>>> output.output("text")

By default, this will utilize whatever is available on the system for which you are trying to output information accessibly. If the user has a screen reader loaded this will be used. Otherwise the system's default voice such as SAPI on Windows is used.
To specify an alternative output, find it in either the speech.outputs or braille.outputs package and pass it as an argument during the creation of MainOutput like:

>>> output = Output(speech_output=accessible_outputs.speech.outputs.Jaws)
  
================================================================================
Speech Outputs
================================================================================

* JAWS for Windows
* Window Eyes
* Dolphin Screen Readers newer than v11.
* NVDA 2010.1 or newer
* System Access and System Access To Go
* Microsoft sapi 5 speech
* Speech Dispatcher
* Apple VoiceOver (note that because of the architecture of VoiceOver, the speech output also outputs Braille)

================================================================================
Braille Outputs
================================================================================

* JAWS for Windows
* Window Eyes
* NVDA
* System Access and System Access To Go
