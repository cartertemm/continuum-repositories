__author__ = "Christopher Toth"
__version__ = "0.7.91"

def find_datafiles():
 import os
 import platform
 from glob import glob
 import accessible_output
 if platform.system() != 'Windows':
  return []
 path = os.path.join(accessible_output.__path__[0], 'lib', '*.dll')
 results = glob(path)
 dest_dir = os.path.join('accessible_output', 'lib')
 return [(dest_dir, results)]
