from accessible_output.output import OutputError, OutputHandler

from . import outputs


class Brailler (OutputHandler):
 """main brailler class which handles all braille outputs.
  Instantiate this class and call its output method with the text to be brailled"""
 outputs_package = outputs
    
 def braille(self, text=""):
  """Braille text through the first available brailler that can braille."""
  self.current_output.output(text)
    
 def clear(self):
  self.current_output.clear()
  