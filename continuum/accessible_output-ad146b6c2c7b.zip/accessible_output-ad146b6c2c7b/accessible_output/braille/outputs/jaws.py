from accessible_output.loader import load_com
import win32gui

from .main import OutputError, BrailleOutput

class Jaws (BrailleOutput):
 """Braille output supporting the Jaws for Windows screen reader."""

 name = 'jaws'

 def __init__(self, *args, **kwargs):
  super (Jaws, self).__init__(*args, **kwargs)
  self.object = load_com("FreedomSci.JawsApi", "jfwapi")

 def output(self, text):
  # HACK: replace " with ', Jaws doesn't seem to understand escaping them with \
  text = text.replace('"', "'")
  self.object.RunFunction("BrailleString(\"%s\")" % text)

 def is_active(self):
  try:
   return self.object.SayString('',0) == True or win32gui.FindWindow("JFWUI2", "JAWS") != 0
  except:
   return False
