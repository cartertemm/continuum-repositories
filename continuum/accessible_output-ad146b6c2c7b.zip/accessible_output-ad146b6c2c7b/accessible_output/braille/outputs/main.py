from accessible_output.output import OutputError, AccessibleOutput

class BrailleOutput (AccessibleOutput):
 """Parent Braille output class"""

 def braille(self, *args, **kwargs):
  self.output(*args, **kwargs)

 def clear (self):
  self.braille("")
