import platform
from accessible_output.loader import load_lib
from accessible_output.py3fixes import u
from .main import OutputError, BrailleOutput

class NVDA (BrailleOutput):

 """Brailler which supports The NVDA screen reader"""

 name = 'NVDA'

 def __init__(self, *args, **kwargs):
  if platform.architecture()[0] == "32bit":
   self.dll = load_lib('nvdaControllerClient32')
  else:
   self.dll = load_lib('nvdaControllerClient64')

 def output(self, text):
  self.dll.nvdaController_brailleMessage(u(text))

 def is_active(self):
  try:
   return self.dll.nvdaController_testIfRunning() == 0
  except:
   return False

