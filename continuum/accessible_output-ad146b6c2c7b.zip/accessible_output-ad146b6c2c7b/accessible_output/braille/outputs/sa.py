from accessible_output.py3fixes import u
from accessible_output.loader import load_lib
from .main import BrailleOutput, OutputError

class SystemAccess (BrailleOutput):

 """Supports Brailling to System Access."""

 name = 'System Access'

 def __init__(self, *args, **kwargs):
  super(SystemAccess, self).__init__(*args, **kwargs)
  self.dll = load_lib('SAAPI32')

 def output(self, text):
  self.dll.SA_BrlShowTextW(u(text))

 def is_active(self):
  try:
   return self.dll.SA_IsRunning()
  except:
   return False
