import win32gui
from accessible_output.loader import load_com

from .main import OutputError, BrailleOutput

class WindowEyes (BrailleOutput):
 """Braille output which supports Window Eyes"""

 name = ' Window-Eyes'

 def __init__(self, *args, **kwargs):
  super(WindowEyes, self).__init__(*args, **kwargs)
  # See if WindowEyes is active, the call will start the interface if available
  self.is_active()
  
 def is_active(self):
  try:
   result = win32gui.FindWindow("GWMExternalControl", "External Control") != 0
   # If WindowEyes is active then start the interface
   if result and self.object is None:
    self.object = load_com("WindowEyes.Application")
   if not result:
    self.object = None
   return result
  except:
   self.object = None
   return False

 def output(self, text):
  # Check whether WindowEyes is active and so can output
  if self.is_active():
   self.object.Braille.display(text)
