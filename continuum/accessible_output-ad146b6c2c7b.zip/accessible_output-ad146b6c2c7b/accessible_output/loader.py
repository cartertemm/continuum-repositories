import os
from pywintypes import com_error
from win32com.client import gencache
from accessible_output import libloader, paths
from .output import OutputError

gencache.is_readonly = False
gencache.GetGeneratePath()

def load_com(*names):
 result = None
 for name in names:
  try:
   result = gencache.EnsureDispatch(name)
   break
  except com_error:
   continue
 if result is None:
  raise OutputError("Unable to load any of the provided com objects.")
 return result

def load_lib(name):
 library_path = os.path.join(paths.module_path(), 'lib')
 try:
  return libloader.load_library(name, x86_path=library_path, x64_path=library_path)
 except:
  raise OutputError("Unable to load library %r" % name)

