from accessible_output.speech.speaker import Speaker
from accessible_output.braille.brailler import Brailler

class Output(object):

 def __init__(self, braille=True, speech=True, braille_output=None, speech_output=None):
  self.braille = braille
  self.speech = speech
  self.braille_output = Brailler(default_output=braille_output)
  self.speech_output = Speaker(default_output=speech_output)

 def output(self, text, interrupt=True):
  if self.speech:
   self.speech_output.say(text, interrupt)
  if self.braille:
   self.braille_output.braille(text)

