from . import priorities

import logging
log = logging.getLogger(__name__)

class OutputError (Exception):
 pass

class AccessibleOutput (object):
 priority = priorities.DEFAULT

 def __init__ (self, priority=None, *args, **kwargs):
  if priority is None:
   priority = self.priority
  self.priority = priority

 def output (self, *args, **kwargs):
  #Override this in subclasses.
  raise NotImplementedError

 write = output

 def is_active(self):
  return False

class OutputHandler(object):
 outputs_package = None

 def __init__(self, default_output=None):
  log.debug("Creating output handler")
  self.output_names = []
  self.possible_outputs = []
  possible_outputs = []
  log.debug("About to search for outputs which work")
  for possible in self.outputs_package.__all__:
   log.debug("Attempting to find output %s" % possible)
   possible_outputs.append(getattr(self.outputs_package, possible))
  log.debug("Sorting outputs")
  possible_outputs.sort(key=lambda x: getattr(x, 'priority', None), reverse=True)
  for o in possible_outputs:
   log.debug("Trying to initialise output %s" % o.name)
   if callable(o):
    try:
     self.possible_outputs.append(o())
     self.output_names.append(o.__name__)
    except OutputError:
     log.debug("A problem while loading the output module, it will not be used")
     continue
  self.setDefaultOutput(default_output)
 def setDefaultOutput(self, default_output):
  if default_output in self.output_names or default_output == '':
   log.debug("Valid default output name given, restoring original order")
   # First restore original order
   old_default = self.possible_outputs.pop(0)
   old_index = self.output_names.index(old_default.__class__.__name__)
   self.possible_outputs.insert(old_index, old_default)
   # Set the new default
   # '' means just restore original order, so ignore that case
   if default_output != '':
    log.debug("Settings %s as default output" % default_output)
    default_index = self.output_names.index(default_output)
    output = self.possible_outputs.pop(default_index)
    self.possible_outputs.insert(0, output)
   # Indicate success
   return True
  log.debug("Invalid default output name given")
  return False
 @property
 def current_output(self):
  log.debug("Trying to find the current output")
  try:
   output = [i for i in self.possible_outputs if i.is_active()][0]
  except IndexError:
   log.warning("There is no outputs available")
   return None
  return output

 def output(self, text, *args, **kwargs):
  output = self.current_output
  if output is None:
   raise RuntimeError("No outputs are available.")
  log.debug("Outputting to %s" % output.name)
  output.output(text, *args, **kwargs)

 write = output
