

class Output(object):
 name = "Unnamed Output" #The name of this output

 def output(self, text, **options):
  output = False
  if hasattr(self, 'speak') and callable(self.speak):
   self.speak(text, **options)
   output = True
  if hasattr(self, 'braille') and callable(self.braille):
   self.braille(text, **options)
   output = True
  if not output:
   raise RuntimeError("Output %r does not have any method defined to output" % self)


