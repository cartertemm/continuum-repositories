from accessible_output.loader import load_lib
from accessible_output.py3fixes import u
from base import Output
import platform

class NVDA(Output):
 """Supports The NVDA screen reader"""
 name = "NVDA"

 def __init__(self, *args, **kwargs):
  super(NVDA, self).__init__(*args, **kwargs)
  if platform.architecture()[0] == "32bit":
   self.dll = load_lib('nvdaControllerClient32')
  else:
   self.dll = load_lib('nvdaControllerClient64')
 
 def is_active(self):
  try:
   return self.dll.nvdaController_testIfRunning() == 0
  except:
   return False

 def braille(self, text, **options):
  self.dll.nvdaController_brailleMessage(u(text))

 def speak(self, text, interrupt=False):
  if interrupt:
   self.silence()
  self.dll.nvdaController_speakText(u(text))

 def silence(self):
  self.dll.nvdaController_cancelSpeech()
