from accessible_output.py3fixes import u
from accessible_output.loader import load_lib
from base import Output

class SystemAccess (Output):
 """Supports System Access and System Access Mobile"""

 name = "System Access"

 def __init__(self, *args, **kwargs):
  super(SystemAccess, self).__init__(*args, **kwargs)
  self.dll = load_lib('SAAPI32')
  
 def braille(self, text, **options):
  self.dll.SA_BrlShowTextW(u(text))

 def speak(self, text, interrupt=0):
  if self.is_active():
   self.dll.SA_SayW(u(text))

 def is_active(self):
  try:
   return self.dll.SA_IsRunning()
  except:
   return False
