import imp
import os.path
import sys
import inspect

def root(file=None):

 if hasattr(sys, "frozen"):
  from win32api import GetModuleFileName
  path = os.path.dirname(GetModuleFileName(0))
 else:
  path = os.path.split(os.path.realpath(__file__))[0]

 if file:
  path = os.path.join(path, file)
 return path

def is_frozen():
 """Return a bool indicating if application is compressed"""
 return hasattr(sys, 'frozen') or imp.is_frozen("__main__")

def get_executable():
 if is_frozen():
  return sys.executable
 return sys.argv[0]

def get_module():
 """Hacky method for deriving the caller of this function's module."""
 return inspect.stack()[2][1]

def app_path():
 """Always determine the path to the main module, even when run with py2exe or otherwise frozen"""
 return os.path.abspath(os.path.dirname(get_executable()))

def module_path():
 return os.path.abspath(os.path.dirname(get_module()))

def executable_path():
 return os.path.join(app_path(), get_executable())
