import sys
if sys.version < "3":
 import codecs
 def u(x):
  if isinstance(x, unicode):
   return x
  return codecs.unicode_escape_decode(x)[0]
else:
 def u(x):
  return x
