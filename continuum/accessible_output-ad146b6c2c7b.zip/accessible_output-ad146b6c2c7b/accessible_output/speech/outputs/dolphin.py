from accessible_output.py3fixes import u
from accessible_output.loader import load_lib
import os

from .main import OutputError, ScreenreaderSpeechOutput

class Dolphin (ScreenreaderSpeechOutput):
 """Supports dolphin products."""

 name = 'Dolphin'

 def __init__(self, *args, **kwargs):
  super(Dolphin, self).__init__(*args, **kwargs)
  try:
   self.dll = load_lib("dolapi")
  except Exception as e:
   raise OutputError(e)

 def output(self, text, interrupt=0):
  if interrupt:
   self.silence()
  #If we don't call this, the API won't let us speak.
  if self.is_active():
   self.dll.DolAccess_Command(u(text), (len(text)*2)+2, 1)

 def silence(self):
  self.dll.DolAccess_Action(141)

 def is_active(self):
  try:
   return self.dll.DolAccess_GetSystem() in (1, 4, 8)
  except:
   return False
