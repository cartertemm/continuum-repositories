from accessible_output.output import AccessibleOutput, OutputError

from accessible_output import priorities

class SpeechOutput (AccessibleOutput):
 """Parent speech output class"""

 def __init__(self, *args, **kwargs):
  super(SpeechOutput, self).__init__(*args, **kwargs)

 def silence (self):
  self.speak("", True)

 def output(self, *args, **kwargs):
  self.say(*args, **kwargs)

class ScreenreaderSpeechOutput (SpeechOutput):
 priority = priorities.SCREENREADER
