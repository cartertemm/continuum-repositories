from accessible_output.py3fixes import u
from accessible_output.loader import load_lib
from .main import OutputError, ScreenreaderSpeechOutput

class SystemAccess (ScreenreaderSpeechOutput):
 """Supports System Access and System Access Mobile"""

 name = 'System Access'

 def __init__(self, *args, **kwargs):
  super(SystemAccess, self).__init__(*args, **kwargs)
  self.dll = load_lib('SAAPI32')
  
 def output(self, text, interrupt=0):
  if self.dll.SA_IsRunning():
   self.dll.SA_SayW(u(text))

 def is_active(self):
  try:
   return self.dll.SA_IsRunning()
  except:
   return False
