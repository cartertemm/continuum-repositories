import sys
from . import sapi4voice, sapi5voice
from .main import OutputError, SpeechOutput

import logging
log = logging.getLogger(__name__)

class Sapi(SpeechOutput):
 """Provides speech output via Microsoft speech API, either version 4 or 5."""

 name = 'sapi'

 def __init__(self, rate=None, volume=None, voice=None, pitch=None, *args, **kwargs):
  super(Sapi, self).__init__(*args, **kwargs)
  self.sapi4 = True
  self.sapi5 = True
  log.debug("Starting SAPI module")
  # Try starting SAPI5
  try:
   log.debug("Trying to initialise SAPI5")
   self.sapi5obj = sapi5voice.SAPI5()
  except:
   log.warning("SAPI5 not found")
   self.sapi5 = False
  # Try starting SAPI4
  try:
   log.debug("Trying to initialise SAPI4")
   self.sapi4obj = sapi4voice.SAPI4()
  except:
   log.warning("SAPI4 not available")
   self.sapi4 = False
  if (not self.sapi4) and (not self.sapi5):
   log.warning("Neither SAPI interfaces available therefore the SAPI module will not be used")
   raise OutputError
  self._createVoiceList()
  if not voice in self.listVoices():
   log.debug("No voice specified, using first available voice")
   voice = self.listVoices()[0]
  self._voiceName = voice
  log.debug("loading the voice to be initially used")
  self._loadVoice(voice)
  if rate is None:
   log.debug("No rate specified")
   if self._hasRate:
    log.debug("The voice supports rate, setting voice rate")
    rate = self._absToPercentage(self.object.get_rate(), self._minRate, self._maxRate)
   else:
    log.debug("As the voice does not support rate, setting the rate to 50")
    rate = 50
  if pitch is None:
   log.debug("No pitch specified")
   if self._hasPitch:
    log.debug("The voice supports pitch, try using its default pitch")
    pitch = self._absToPercentage(self.object.get_pitch(), self._minPitch, self._maxPitch)
   else:
    log.debug("As the voice does not support pitch just set the value to 50")
    pitch = 50
  if volume is None:
   log.debug("No volume specified")
   if self._hasVolume:
    log.debug("The voice supports pitch, so try and use its default volume")
    volume = self._absToPercentage(self.object.get_volume(), self._minVolume, self._maxVolume)
   else:
     log.debug("Voice does not support volume, set the value to 100")
     volume = 100
  self._rate = rate
  self._pitch = pitch
  self._volume = volume
  self.voice = voice
 def _createVoiceList(self):
  self._sapi4VoiceList = []
  self._sapi5VoiceList = []
  log.debug("Creating the voice lists")
  if self.sapi5:
   log.debug("SAPI5 list creation")
   self._sapi5VoiceList.extend([voice + " - SAPI5" for voice in self.sapi5obj.list_voices()])
  if self.sapi4:
   log.debug("SAPI4 voice list creation")
   self._sapi4VoiceList.extend([voice + " - SAPI4" for voice in self.sapi4obj.list_voices()])
 def _absToPercentage(self, value, minVal, maxVal):
  valueRange = maxVal - minVal
  return (value - minVal)*100/valueRange
 def _percentageToABS(self, value, minVal, maxVal):
  valueRange = maxVal - minVal
  if valueRange < 0:
   valueRange = 0
  return minVal + (valueRange*value/100)

 def is_active(self):
  if self.sapi4 or self.sapi5:
   return True
  return False
 def output(self, text, interrupt=0):
  if interrupt:
   self.silence()
  self.object.speak(text)
 def silence(self):
  self.object.silence()
 def listVoices(self):
  return self._sapi4VoiceList + self._sapi5VoiceList
 def getRate (self):
  return self._rate
 def setRate (self, rate):
  if rate > 100: rate = 100
  if rate < 0: rate = 0
  # Some synths do not support all features
  if self._hasRate:
   self.object.set_rate(self._percentageToABS(rate, self._minRate, self._maxRate))
  self._rate = rate
 def getVolume (self):
  return self._volume
 def setVolume (self, volume):
  if volume > 100: volume = 100
  if volume < 0: volume = 0
  if self._hasVolume:
   self.object.set_volume(self._percentageToABS(volume, self._minVolume, self._maxVolume))
  self._volume = volume
 def getVoice (self):
  return self._voiceName
 def _loadVoice(self, voice):
  log.debug("Setting voice to \"%s\"" % voice)
  # The voice names we use have " - SAPI4" and " - SAPI5" appended but sapi will not want this
  voiceName = voice[:-8]
  if voice.endswith("SAPI5"):
   log.debug("SAPI5 voice being set")
   self.object = self.sapi5obj
  elif voice.endswith("SAPI4"):
   log.debug("Setting SAPI4 voice")
   self.object = self.sapi4obj
  sapi = self.object
  sapi.set_voice(voiceName)
  self._voiceName = voice
  self._minPitch = sapi.min_pitch
  self._maxPitch = sapi.max_pitch
  self._minRate = sapi.min_rate
  self._maxRate = sapi.max_rate
  self._minVolume = sapi.min_volume
  self._maxVolume = sapi.max_volume
  self._hasPitch = sapi.has_pitch
  self._hasRate = sapi.has_rate
  self._hasVolume = sapi.has_volume
 def setVoice(self, voice):
  if not voice in self.listVoices():
   log.debug("Voice not known")
   return
  self.silence()
  self._loadVoice(voice)
  # Ensure the voice takes the correct settings
  self.rate = self._rate
  self.volume = self._volume
  self.pitch = self._pitch
 def getPitch (self):
  return self._pitch
 def setPitch (self, pitch):
  if pitch < 0: pitch = 0
  if pitch > 100: pitch = 100
  if self._hasPitch:
   self.object.set_pitch(self._percentageToABS(pitch, self._minPitch, self._maxPitch))
  self._pitch = pitch
 rate = property(fget=getRate, fset=setRate)
 volume = property(fget=getVolume, fset=setVolume)
 voice = property(fget=getVoice, fset=setVoice)
 pitch = property(fget=getPitch, fset=setPitch)
