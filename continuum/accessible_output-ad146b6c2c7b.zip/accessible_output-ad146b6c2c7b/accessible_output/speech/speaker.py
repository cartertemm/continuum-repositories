from accessible_output.output import OutputError, OutputHandler

from . import outputs

import logging
log = logging.getLogger(__name__)

class Speaker(OutputHandler):
 """main speaker class which handles all speech outputs.
  Instantiate this class and call its output method with the text to be spoken and an optional boolean argument
  to govern interruption.  Pass in a SpeechOutput class to be used as default output."""

 outputs_package = outputs

 def say(self, text="", interrupt=0):
  self.current_output.output(text, interrupt)

 def silence(self):
  self.current_output.silence()
  