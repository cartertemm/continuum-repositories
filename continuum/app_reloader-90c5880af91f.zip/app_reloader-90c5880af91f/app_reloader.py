from logging import getLogger
logger = getLogger('app_reloader')
import os
import subprocess
import sys

import watchdog
import watchdog.events
from watchdog.observers import Observer

from platform_utils import paths

def list_module_files():
 #From werkzeug
 for module in sys.modules.values():
  filename = getattr(module, '__file__', None)
  if filename:
   old = None
   while not os.path.isfile(filename):
    old = filename
    filename = os.path.dirname(filename)
    if filename == old:
     break
   else:
    if filename[-4:] in ('.pyc', '.pyo'):
     filename = filename[:-1]
    yield os.path.abspath(filename)
  if not paths.is_frozen():
   yield paths.executable_path()


class CodeFileEventWatcher(watchdog.events.FileSystemEventHandler):

 def __init__(self, watched_files=None, callback=None, *args, **kwargs):
  super(CodeFileEventWatcher, self).__init__(*args, **kwargs)
  self.callback = callback
  self.watched_files = watched_files or set()

 def on_any_event(self, event):
  if callable(self.callback):
   if event.src_path in self.watched_files:
    self.callback(event.src_path)

def watch_files(files, callback=None):
 files = list(files)
 observer = Observer()
 event_handler = CodeFileEventWatcher(watched_files=set(list(files)), callback=callback)
 for path in files:
  observer.schedule(event_handler, os.path.split(path)[0], recursive=True)
 return observer

def relaunch_app(callback=None):
 logger.info("Relaunching application")
 args = []
 if not paths.is_frozen():
  args.append(sys.executable)
 args.extend(sys.argv)
 args = [arg for arg in args if arg]
 if callable(callback):
  callback()
 subprocess.Popen(args)

def activate_app_reloader(relaunch_callback=None):
 watcher = watch_files(list_module_files(), callback=lambda path: relaunch_app(callback=relaunch_callback))
 watcher.start()
 logger.info("Activated app_reloader")
 return watcher
