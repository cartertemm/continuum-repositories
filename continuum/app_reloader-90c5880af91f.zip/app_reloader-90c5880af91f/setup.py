from setuptools import setup

__author__ = 'Christopher Toth <q@q-continuum.net>'
__version__ = 0.12
__doc__ = """Restart your apps when their code changes."""


setup(
 name = 'app_reloader',
 version = __version__,
 author = __author__,
 description = __doc__,
 py_modules = ['app_reloader'],
 install_requires = [
  'watchdog',
 ],
 classifiers = [
  'Development Status :: 3 - Alpha',
  'Intended Audience :: Developers',
  'Programming Language :: Python',
  'Topic :: Software Development :: Libraries',
 ],
)
