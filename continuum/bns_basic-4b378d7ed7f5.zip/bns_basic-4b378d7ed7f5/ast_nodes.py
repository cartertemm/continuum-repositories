from lexer import OPERATORS
from symbols import *

OPERATOR_CODES = dict(zip(OPERATORS.values(), OPERATORS.keys()))

class ASTNode(object):

	def __str__(self):
		return repr(self)

	def as_code(self):
		raise NotImplementedError

class Line(ASTNode):

	def __init__(self, number=0, statements=None, branch1=None, branch2=None):
		self.number = number
		if statements is None:
			statements = []
		self.statements = statements

	def __repr__(self):
		return "line " + str(self.number) + " " + str(self.statements)

	def as_code(self):
		return str(self.number.value) + " " + ': '.join([i.as_code() for i in self.statements]) + '\n'

class Command(ASTNode):

	def __init__(self, command, arguments=None):
		self.command = command
		if arguments is None:
			arguments = []
		self.arguments = arguments

	def __repr__(self):
		return "Command("+str(self.command.value).upper() + "(" + str(self.arguments) + ")" + ")"

	def as_code(self):
		arguments = ' '.join([i.as_code() for i in self.arguments])
		res = str(self.command.value)
		if arguments:
			res = res + ' ' + arguments
		return res

class FunctionCall(ASTNode):

	def __init__(self, function, arguments=None):
		if arguments is None:
			arguments = []
		self.function = function
		self.arguments = arguments

	def __repr__(self):
		return str(self.function.value) + "(" + str(self.arguments) + ")"

	def as_code(self):
		arguments = ' '.join([i.as_code() for i in self.arguments])
		res = str(self.function.value)
		if arguments:
			res = res + "(" + arguments + ")"
		return res

class IfStatement(ASTNode):

	def __init__(self, condition, to_execute):
		self.condition = condition
		self.to_execute = to_execute

	def __repr__(self):
		return "if " + str(self.condition) + " then " + str(self.to_execute)

	def as_code(self):
		if hasattr(self.to_execute, 'value'):
			to_execute = str(self.to_execute.value)
		else:
			to_execute = ': '.join([i.as_code() for i in self.to_execute])
		return 'if ' + self.condition.as_code() + ' then ' + to_execute

class ElseStatement(ASTNode):

	def __init__(self, to_execute):
		self.to_execute = to_execute

	def __repr__(self):
		return "Else " + str(self.to_execute)

	def as_code(self):
		if hasattr(self.to_execute, 'value'):
			to_execute = str(self.to_execute.value)
		else:
			to_execute = ': '.join([i.as_code() for i in self.to_execute])
		return 'else ' + to_execute

class BinaryOp(ASTNode):

	def __init__(self, left, operator, right):
		self.left = left
		self.operator = operator
		self.right = right

	def __repr__(self):
		return "BinaryOp(left=" + str(self.left) + ", operator=" + str(self.operator) + ", right=" + str(self.right) + ")"

	def as_code(self):
		op = OPERATOR_CODES[self.operator.value]
		return self.left.as_code() + ' ' + op + ' ' + self.right.as_code()

class Condition(ASTNode):

	def __init__(self, left, operator, right):
		self.left = left
		self.operator = operator
		self.right = right

	def __repr__(self):
		return "Condition(left=" + str(self.left) + ", operator=" + str(self.operator) + ", right=" + str(self.right) + ")"

	def as_code(self):
		op = OPERATOR_CODES[self.operator.value]
		return self.left.as_code() + ' ' + op + ' ' + self.right.as_code()

class Reference(ASTNode):

	def __init__(self, value):
		self.value = value

	def __repr__(self):
		return "Reference(value="+str(self.value)+")"

	def as_code(self):
		if isinstance(self.value, ASTNode):
			return self.value.as_code()
		if self.value.type == STRING:
			return '"' + self.value.value + '"'
		return str(self.value.value)

class Assignment(ASTNode):

	def __init__(self, left, right):
		self.left = left
		self.right = right

	def __repr__(self):
		return "Assignment(" + str(self.left) + " = " + str(self.right) + ")"

	def as_code(self):
		return self.left.as_code() + ' = ' + self.right.as_code()

class ForStatement(ASTNode):

	def __init__(self, variable, start, end, step=1):
		self.variable = variable
		self.start = start
		self.end = end
		self.step = step

	def __repr__(self):
		return "For " + str(self.variable) + " = " + str(self.start) + " to " + str(self.end)

	def as_code(self):
		return 'for ' + self.variable.as_code() + ' = ' + self.start.as_code() + ' to ' + self.end.as_code()

class ArrayRef(ASTNode):

	def __init__(self, array, address):
		self.array = array
		self.address = address

	def __repr__(self):
		return "ArrayRef (" + str(self.array) + ", address=" + str(self.address) + ")"

	def as_code(self):
		return self.array.value + ''.join(['(%s)' % i.as_code() for i in self.address])

class WhileStatement(ASTNode):

	def __init__(self, condition):
		self.condition= condition

	def __repr__(self):
		return "while " + str(self.condition)

	def as_code(self):
		return 'while ' + self.condition.as_code()

class OnStatement(ASTNode):

	def __init__(self, to_execute):
		self.to_execute = to_execute

	def __repr__(self):
		return "On Error " + str(self.to_execute)

	def as_code(self):		
		return "on error " + self.to_execute.as_code()
