import sys
import struct
from cStringIO import StringIO

class UnknownTokenError(Exception):
	pass

class Parser(object):

	def __init__(self, fp):
		self.fp = fp
		self.current_line = 0
		self.tokens = {
			'\x01': lambda line: self.get_argument_statement('print', line),
			'\x02': lambda line: self.get_argument_statement('input', line),
			'\x03': self.if_statement,
			"\x04": self.then,
			"\x05": self.else_statement,
			'\x06': self.gosub, #goto, an if statement checks this
			'\x07': self.gosub,
			'\x08': self.return_statement,
			'\x09': self.dim,
			'\x0a': self.get,
			'\x0b': self.for_statement,
			'\x0e': self.next_statement,
	'\x11': self.open,
	'\x12': self.close,
	'\x13': self.clear,
		'\x14': lambda line: self.get_argument_statement('create', line),
			'\x15': self.end,
			'\x17': self.allcaps,
			'\x18': self.equal,
			'\x19': self.gosub,
		'\x1a': self.data,
		'\x1b': self.read,
			'\x1c': self.on,
			'\x1e': lambda line: self.get_argument_statement('fprint', line),
		'\x1f': self.finput,
			'\x26': self.say,
			'\x28': self.off,
			'\x29': self.click,
			'\x30': self.beep,
		}

	def get_raw_line(self):
		"""Returns one line from the file, without its length byte. Currently (number, contents).
If at end of file, returns (None, None)."""
		#Not sure what this is yet
		flags = fp.read(1)
		if flags == '': return None, None
		line_number = struct.unpack('<H', fp.read(2))[0]
		self.current_line = line_number
		length = struct.unpack('<b', fp.read(1))[0]
		line_contents = fp.read(length - 3)
		return (line_number, line_contents)

	def parse(self):
		lines = {}
		while True:
			line_number, line_contents = self.get_raw_line()
			if line_number is None: break
			line_contents = self.decompile_line(line_contents)
			lines[line_number] = line_contents
		return lines

	def decompile_line(self, line):
		"""Takes a raw line and decompiles it."""
		statements = []
		while line != '':
			try:
				statement, line = self.get_one_statement(line)
				statements.append(statement)
			except UnknownTokenError:
				statements.append("rem "+repr(line))
				break
		#Merge the ifs
		ns = []
		i = 0
		while i <= len(statements) - 1:
			if statements[i].startswith('if') and statements[i+1] == 'then':
				ns.append(statements[i] + " " + statements[i+1] + " " + statements[i+2])
				i += 3
				continue
			ns.append(statements[i])
			i += 1

		return " : ".join(ns)

	def get_one_statement(self, line):
		"""Gets one statement out of the line and decompiles it.
returns (statement, remainder_of_line) if it succeeds; otherwise raises UnknownTokenError."""
		if line[0] not in self.tokens:
			raise UnknownTokenError(repr(line))
		return self.tokens[line[0]](line)

	def equal(self, line):
		var_len = ord(line[1])
		val_len = ord(line[2+var_len])
		var = line[2:var_len+2]
		val = line[var_len+3:var_len+3+val_len]
		statement = '%s = %s' % (var, val)
		line = line[var_len+val_len+3:]
		return statement, line

	def gosub(self, line):
		offset = struct.unpack('<H', line[2:4])[0]
		current = self.fp.tell()
		self.fp.seek(offset-3)
		number = struct.unpack('<H', self.fp.read(2))[0]
		self.fp.seek(current)
		if line[0] == '\x06':
			return 'goto %d' % number, line[5:]
		elif line[0] == '\x19':
			return '%d' % number, line[4:]
		else:
			return 'gosub %d' % number, line[4:]

	def return_statement(self, line):
		return 'return', line[1:]

	def allcaps(self, line):
		return 'allcaps', line[1:]

	def if_statement(self, line):
		length = ord(line[1])
		condition = line[2:length+2]
		return 'if %s' % condition, line[2+length:]

	def then(self, line):
		return 'then', line[1:]

	def get(self, line):
		length = ord(line[2])
		var = line[3:3+length]
		return "get %s" % var, line[length+3:]

	def click(self, line):
		return 'click', line[1:]

	def beep(self, line):
		return 'beep', line[1:]

	def else_statement(self, line):
		return 'else', line[1:]

	def clear(self, line):
		return 'clear', line[1:]

	def end(self, line):
		return 'end', line[1:]

	def for_statement(self, line):
		s = StringIO(line)
		s.read(1) #For
		varname = self.read_string(s)
		start = self.read_string(s)
		to_token = s.read(1)
		if to_token != '\x0c':
			raise RuntimeError("Unknown token: %r" % to_token)
		value = self.read_string(s)
		statement = 'for %s = %s to %s' % (varname, start, value)
		pos = s.tell()
		step = s.read(1)
		if step == '\x0d':
			step = self.read_string(s)
			statement += " step %s" % step
		else:
			s.seek(pos)
		return statement, s.read()

	def next_statement(self, line):
		length = ord(line[2])
		s = line[3:3+length]
		return 'next %s' % s, line[length+3:]

	def off(self, line):
		return 'off', line[1:]

	def dim(self, line):
		s = StringIO(line)
		s.read(1) #Token
		number = ord(s.read(1))
		dims = []
		for i in range(number):
			length = ord(s.read(1))
			var = s.read(length)
			length = ord(s.read(1))
			val = s.read(length)
			null = s.read(1) #Is this always 0?
			if null != '\0':
				raise RuntimeError("Unexpected byte, line: %r" % s.getvalue())
			dims.append("%s(%s)" % (var, val))
		statement = "dim %s" % ", ".join(dims)
		return statement, s.read()

	def on(self, line):
		s = StringIO(line)
		s.read(1)
		length = ord(s.read(1))
		on_type = s.read(length)
		statements = self.decompile_line(s.read())
		return 'on %s %s' % (on_type, statements), ''

	def close(self, line):
		length = ord(line[2])
		return "close "+line[3:3+length], line[3+length:]

	def open(self, line):
		return self.get_argument_statement('open', line)

	def finput(self, line):
		return self.get_argument_statement('finput', line)

	def say(self, line):
		return self.get_argument_statement('say', line)

	def data(self, line):
		return self.get_argument_statement('data', line)

	def read(self, line):
		return self.get_argument_statement('read', line)

	def get_argument_statement(self, name, line):
		s = StringIO(line)
		s.read(1)
		nargs = ord(s.read(1))
		args = []
		for i in range(nargs):
			args.append(self.read_string(s))
		args = ", ".join(args)
		return "%s %s" % (name, args), s.read()

	def read_string(self, s):
		length = ord(s.read(1))
		string = s.read(length)
		return string

if __name__ == '__main__':
	fp = open(sys.argv[1], 'rb')
	parser = Parser(fp)
	lines = parser.parse()
	for line in sorted(lines.keys()):
		print line, lines[line]
