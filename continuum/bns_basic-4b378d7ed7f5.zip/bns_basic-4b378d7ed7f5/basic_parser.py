import operator

from ast_nodes import *
from symbols import *
from keywords import KEYWORDS
import lexer
import basic_program


class LineParser(object):

	def __init__(self, lexer):
		super(LineParser, self).__init__()
		self.lexer = lexer
		self.current_token = None
		self.last_token = None

	def line(self):
		self.advance()
		line = Line()
		line_number = self.line_number()
		line.number = line_number
		line.statements.extend(self.statement_list())
		return line

	def line_number(self):
		line_num = self.current_token
		self.eat(INTEGER)
		return line_num

	def statement_list(self):
		statements = []
		while self.current_token.type is not EOF:
			if self.current_token.type in (COMMENT, STATEMENT_SEP):
				self.advance()
				continue
			statement = self.statement()
			statements.append(statement)
		return statements

	def statement(self):
		if self.current_token.value in KEYWORDS:
			return self.command()
		if self.current_token.type in (STRINGVAR, INTVAR):
			return self.assignment()

	def command(self):
		command = self.current_token
		self.eat(KEYWORD)
		if command.value == 'if':
			return self.if_statement()
		elif command.value == 'else':
			return self.else_statement()
		elif command.value == 'for':
			return self.for_statement()
		elif command.value == 'while':
			return self.while_statement()
		elif command.value == 'on':
			return self.on_statement()
		arguments = self.command_arguments()
		return Command(command, arguments)

	def if_statement(self):
		condition = self.condition()
		if self.current_token.value == 'then':
			self.eat(KEYWORD)
		if self.current_token.type == INTEGER:  # short GOTO
			to_execute = self.current_token
			self.eat(INTEGER)
		else:
			to_execute = self.statement_list()
		return IfStatement(condition=condition, to_execute=to_execute)

	def condition(self):
		left = self.expression()
		op = self.current_token
		self.eat(OPERATOR)
		right = self.expression()
		condition = Condition(left=left, operator=op, right=right)
		if self.current_token.type == OPERATOR and self.current_token.value in (operator.and_, operator.or_):
			op = self.current_token
			self.eat(OPERATOR)
			condition = Condition(condition, op, self.condition())
		return condition

	def else_statement(self):
		to_execute = self.statement_list()
		return ElseStatement(to_execute=to_execute)

	def for_statement(self):
		step = 1
		variable = self.reference()
		self.eat(OPERATOR)
		start = self.expression()
		self.eat(KEYWORD)
		end = self.expression()
		if self.current_token.type == KEYWORD and self.current_token.value == 'step':
			self.eat(KEYWORD)
			step = self.expression()
		return ForStatement(variable=variable, start=start, end=end, step=step)

	def while_statement(self):
		return WhileStatement(condition=self.condition())

	def on_statement(self):
		self.eat(KEYWORD) #the ERROR of "ON ERROR" since the other version isn't supported by bns basic
		return OnStatement(to_execute=self.statement())

	def assignment(self):
		left = self.reference()
		self.eat(OPERATOR)
		right = self.expression()
		return Assignment(left=left, right=right)

	def command_arguments(self):
		if self.current_token.type in (EOF, STATEMENT_SEP):
			return []
		arguments = [self.expression()]
		while self.current_token.type not in (EOF, STATEMENT_SEP):
			if self.current_token.type == EXPRESSION_SEP:
				self.eat(EXPRESSION_SEP)
				continue
			if self.current_token.type in (EOF, STATEMENT_SEP):
				break
			arguments.append(self.expression())
		return arguments

	def expression(self):
		result = self.term()
		if self.current_token.value in (operator.add, operator.sub):
			op = self.current_token
			self.eat(OPERATOR)
			other = self.expression()
			result = BinaryOp(result, op, other)
		return result

	def term(self):
		result = self.reference()
		if self.current_token.value in (operator.mul, operator.truediv):
			op = self.current_token
			self.eat(OPERATOR)
			other = self.term()
			result = BinaryOp(left=result, operator=op, right=other)
		return result

	def reference(self):
		if self.current_token.type == BUILTIN_FUNC:
			return self.function_call()
		if self.current_token.type in (INTVAR, STRINGVAR) and self.lexer.lookahead().type == LPAREN:
			return self.array_ref()
		if self.current_token.type == LPAREN:
			self.eat(LPAREN)
			res = Reference(value=self.expression())
			self.eat(RPAREN)
			return res
		negative = False
		if self.current_token.type == OPERATOR and self.current_token.value == operator.sub and not self.last_token.type in (INTEGER, FLOAT):
			self.eat(OPERATOR)
			negative = True
		if self.current_token.type in (FLOAT, INTEGER):
			res = Reference(value=self.current_token)
			if negative:
				res.value.value *= -1
			self.advance()
			return res
		if self.current_token.type == STRING:
			res = Reference(value=self.current_token)
			self.eat(STRING)
			return res
		if self.current_token.type in (STRINGVAR, INTVAR):
			res = Reference(value=self.current_token)
			self.advance()
			return res
		raise RuntimeError("Don't know what to do with %s" % self.current_token)

	def function_call(self):
		function = self.current_token
		self.eat(BUILTIN_FUNC)
		arguments = self.function_arguments()
		return FunctionCall(function=function, arguments=arguments)

	def function_arguments(self):
		arguments = []
		if self.current_token.type != LPAREN:
			return arguments
		self.eat(LPAREN)
		if self.current_token.type == RPAREN:
			self.eat(RPAREN)
			return arguments
		arguments.append(self.expression())
		while self.current_token.type == EXPRESSION_SEP:
			self.eat(EXPRESSION_SEP)
			arguments.append(self.expression())
		self.eat(RPAREN)
		return arguments

	def array_ref(self):
		name = self.current_token
		self.advance()
		address = self.function_arguments()
		return ArrayRef(array=name, address=address)

	def eat(self, token_type):
		if self.current_token.type == token_type:
			self.advance()
		else:
			raise RuntimeError

	def advance(self):
		self.last_token = self.current_token
		self.current_token = self.lexer.get_next_token()


class BasicParser(object):

	def __init__(self, input_lines):
		self.lexer = lexer.Lexer()
		self.input_lines = input_lines

	def parse_lexed(self, line):
		return LineParser(line).line()

	def parse(self):
		program = basic_program.BasicProgram()
		for line in self.input_lines:
			line = line.strip()
			if not line:
				continue
			lexed = lexer.LineLexer(line)
			parsed_line = self.parse_lexed(lexed)
			program.add_line(parsed_line)
		return program

