from __future__ import print_function
from collections import OrderedDict

class CompileError(Exception):

	def __init__(self, line, message):
		self.line = line
		self.message = message

	def __repr__(self):
		return "Compile error on line %d: %s" % (self.line, self.message)

	__str__ = __repr__

class HostDevice(object):

	def __init__(self, program=None):
		super(HostDevice, self).__init__()
		self.program = program
		if program is not None:
			program.device = self


class BasicProgram(object):

	def __init__(self, filename=None):
		self.filename = filename
		self.variables = {}
		self.allcaps = False
		self.lf = False
		self.open_files = {}
		self.current_line = 0
		self.lines = OrderedDict()
		self.data = []
		self.commands = BuiltinCommands(self)

	def add_line(self, line):
		if line.number in self.lines:
			raise CompileError(line_num, "Line %d defined twice" % line_num)
		self.lines[line.number] = line

	def as_code(self):
		return [i.as_code() for i in self.lines.itervalues()]

class BuiltinCommands(object):

	def __init__(self, program):
		self.program = program

	def PRINT(self, *args):
		for arg in args:
			print (arg, end=' ')
		print()

	def GOTO(self, line):
		self.program.current_line = int(line)

	def END(self):
		self.program.ended = True

	def DATA(self, data):
		self.program.data.append(data)

	def INPUT(self, prompt="", *variables):
		for variable in variables:
			data = input(prompt)
			if not variable.endswith('$'):
				try:
					data = int(data)
				except ValueError:
					data = 0
			self.program.variables[variable] = data

	def LF(self):
		self.program.lf = not self.program.lf

	def GOSUB(self, line):
		self.program.current_line = line

	def RETURN(self):
		line = self.program.gosub_stack.pop()
		self.GOTO(line)

	def IF(self, rest):
		print(rest)
