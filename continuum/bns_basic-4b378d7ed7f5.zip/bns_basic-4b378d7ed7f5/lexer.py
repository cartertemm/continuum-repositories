import operator
import string

from keywords import KEYWORDS, BUILTIN_FUNCTIONS
from symbols import *

OPERATORS = {
	'+': operator.add,
	'-': operator.sub,
	'*': operator.mul,
	'/': operator.truediv,
	'~': operator.pow,
	'=': operator.eq,
	'<': operator.lt,
	'>': operator.gt,
	'<=': operator.le,
	'>=': operator.ge,
	'<>': operator.ne,
	'><': operator.ne,
	'and': operator.and_,
	'or': operator.or_,
}

class Token(object):

	def __init__(self, type, value=None):
		self.type = type
		self.value = value

	def __str__(self):
		return "%s(%s)" % (self.type, self.value)

	__repr__ = __str__

class LineLexer(object):

	def __init__(self, text):
		self.text = text
		self.pos = 0
		self.current_char = self.text[self.pos]

	def get_next_token(self):
		while self.current_char is not None:
			if self.current_char.isspace():
				self.skip_whitespace()
				continue
			if self.current_char.isdigit() or self.current_char == '.':
				pos = self.pos
				word = self.word()
				if '.' in word:
					return Token(type=FLOAT, value=float(word))
				self.pos = pos
				if pos < len(self.text):
					self.current_char = self.text[self.pos]
				return Token(type=INTEGER, value=self.integer())
			if self.current_char == '"':
				return Token(type=STRING, value=self.string())
			if self.current_char in OPERATORS:
				return Token(type=OPERATOR, value=self.operator())
			if self.current_char == '(':
				self.advance()
				return Token(type=LPAREN, value='(')
			if self.current_char == ')':
				self.advance()
				return Token(type=RPAREN, value=')')
			if self.current_char == ':':
				self.advance()
				return Token(type=STATEMENT_SEP, value=':')
			if self.current_char in (',', ';'):
				char = self.current_char
				self.advance()
				return Token(type=EXPRESSION_SEP, value=char)
			if self.current_char == '?':
				self.advance()
				return Token(type=KEYWORD, value='print')
			if self.current_char == "'":
				return Token(type=COMMENT, value=self.comment())
			if self.current_char in list(string.ascii_letters):
				word = self.word()
				if word == 'rem' or word == "'":
					self.skip_whitespace()
					return Token(type=COMMENT, value=self.comment())
				if word == 'or':
					return Token(type=OPERATOR, value=operator.or_)
				if word == 'and':
					return Token(type=OPERATOR, value=operator.and_)
				if word in KEYWORDS:
					return Token(type=KEYWORD, value=word)
				elif word in BUILTIN_FUNCTIONS:
					return Token(type=BUILTIN_FUNC, value=word)
				elif word.endswith('$'):
					return Token(type=STRINGVAR, value=word)
				else:
					return Token(type=INTVAR, value=word)
			raise RuntimeError("Unknown token %s" % self.current_char)
		return Token(type=EOF)

	def lookahead(self):
		if self.pos == len(self.text):
			return Token(type=EOF)
		pos = self.pos
		res = self.get_next_token()
		self.pos = pos
		self.current_char = self.text[self.pos]
		return res

	def __iter__(self):
		token = self.get_next_token()
		while token.type != EOF:
			yield token
			token = self.get_next_token()
		yield token


	def advance(self):
		self.pos += 1
		if self.pos > len(self.text) - 1:
			self.current_char = None
		else:
			self.current_char = self.text[self.pos]

	def skip_whitespace(self):
		while self.current_char is not None and self.current_char.isspace():
			self.advance()

	def integer(self):
		result = ''
		while self.current_char is not None and self.current_char.isdigit():
			result += self.current_char
			self.advance()
		return int(result)

	def string(self):
		result = []
		if self.current_char == '"':
			self.advance()
		escape = False
		while self.current_char is not None:
			if self.current_char == '\\':
				escape = not escape
			if self.current_char == '"' and not escape:
				self.advance()
				break
			result.append(self.current_char)
			self.advance()
		return ''.join(result)

	def operator(self):
		op = self.text[self.pos:self.pos+2]
		operator = OPERATORS.get(op)
		if operator:
			self.advance()
		else:
			operator = OPERATORS[self.current_char]
		self.advance()
		return operator

	def word(self):
		result = []
		while self.current_char is not None and not self.current_char.isspace():
			if self.current_char in list('()[]",+-*/<>=!\'\\:;'):
				break
			result.append(self.current_char)
			self.advance()
		word = ''.join(result)
		return word.lower()

	def comment(self):
		result = []
		while self.current_char is not None and self.current_char not in [':', '\r']:
			result.append(self.current_char)
			self.advance()
		return ''.join(result)

class Lexer(object):

	def parse_line(self, line):
		lexer = LineLexer(line)
		return list(lexer)

	def lex(self, iterator):
		for line in iterator:
			yield self.parse_line(line)
