from setuptools import setup

__version__ = "0.1"
__doc__ = "Bookshare API wrapper"

setup(
 name = "bookshare",
 version = __version__,
 description = __doc__,
 py_modules = ['bookshare'],
 install_requires = [
  'requests',
 ],
 zip_safe = False,
 classifiers = [
  'Development Status :: 3 - Alpha',
  'Intended Audience :: Developers',
  'Programming Language :: Python',
  'Topic :: Software Development :: Libraries',
 ],
)
