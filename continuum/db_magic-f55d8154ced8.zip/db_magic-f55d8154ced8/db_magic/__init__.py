from db_magic.magic import *
