import sys
import threading
import traceback

def thread_frame(thread):
 frame = sys._current_frames()[thread.ident]
 return "".join(traceback.format_stack(frame))

def all_frames():
 res = []
 t=threading.enumerate()
 for i in t:
  res.append(thread_frame(i))
 return res
