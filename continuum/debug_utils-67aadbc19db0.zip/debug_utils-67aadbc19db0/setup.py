from setuptools import setup, find_packages

__version__ = 0.1
__doc__ = """Collected utilities to ease debugging of applications primarily through a remote interface such as Ingress."""
__author__ = u'Christopher Toth'

setup(
 name = 'debug_utils',
 version = __version__,
 author = __author__,
 author_email = u'q@qwitter-client.net',
 description = __doc__,
 package_dir = {'debug_utils': 'debug_utils'},
 packages = find_packages(),
 classifiers = [
  'Development Status :: 3 - Alpha',
  'Intended Audience :: Developers',
  'Programming Language :: Python',
  'License :: OSI Approved :: MIT License',
  'Topic :: Software Development :: Libraries',
 ],
)
