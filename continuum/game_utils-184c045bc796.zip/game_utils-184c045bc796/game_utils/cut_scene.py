from threading import Timer
from wx import CallAfter

def delay(duration, function, *a, **k):
 t = Timer(duration, function, args=a, kwargs=k)
 t.daemon = True
 t.start()
 return t

class CutScene(object):

 def __init__(self, keyboard_handler, scene, method, *args, **kwargs):
  self.keyboard_handler = keyboard_handler
  self.method = method
  self.scene = scene
  self.keyboard_handler.register_key('escape', self.skip)
  self.keyboard_handler.register_key('return', self.skip)
  self.keyboard_handler.register_key('space', self.skip)
  self.delay = delay(round(self.scene.bytes_to_seconds(len(self.scene)), 1), self.finish)
  self.scene.play()

 def skip(self):
  self.scene.stop()
  if hasattr(self, 'delay') and self.delay.isAlive():
   self.delay.cancel()
  self.finish()

 def finish(self):
  self.keyboard_handler.unregister_all_keys()
  CallAfter(self.method)
  del(self)