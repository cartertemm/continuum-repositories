from objects import GameEntity

class EnclosedArea(GameEntity):
 min_x = 0
 min_y = 0
 max_x = 10
 max_y = 10


 def __init__(self, min_x=None, min_y=None, max_x=None, max_y=None, **kwargs):
  super(EnclosedArea, self).__init__(**kwargs)
  if min_x is None:
   min_x = self.min_x
  if min_y is None:
   min_y = self.min_y
  if max_x is None:
   max_x = self.max_x
  if max_y is None:
   max_y = self.max_y
  self.min_x, self.min_y, self.max_x, self.max_y = min_x, min_y, max_x, max_y
  self.objects = {}
  self.exits = {}

 def contains_coordinates(self, coordinates):
  return not (coordinates[0] < 0 or coordinates[0] > self.max_x or coordinates[1] < 0 or coordinates[1] > self.max_y)

 def dimensions(self):
  return ((0, self.max_x), (0, self.max_y))

 def add_object(self, obj=None, coordinates=None):
  if None in (obj, coordinates):
   raise ValueError("Must provide an object and coordinates for said object.")
  if coordinates in self.objects:
   raise ValueError("The supplied coordinates in %s, %r, are already occupied." % (self.name, coordinates))
  if not self.contains_coordinates(coordinates):
   raise ValueError("Provided point %r outside this enclosure (%s) dimensions: %r." % (coordinates, self.name, self.dimensions()))
  self.objects[coordinates] = obj

 def add_exit(self, exit, exit_name, exit_coordinates):
  if exit_name in self.exits:
   raise ValueError("An exit named %r already exists in %r." % (exit_name, self))
  self.add_object(exit, exit_coordinates)
  self.exits[exit_name] = exit

 def get_object_from_point(self, coordinates):
  return self.area[coordinates]
 
 def move_object(self, obj=None, coordinates=None):
  if not self.contains_point(coordinates ):
   raise ValueError("The point %r lies outside this enclosure." % coordinates)
  try:
   current = self.get_object_from_point(coordinates)
  except KeyError:
   self.objects[coordinates] = obj
   return
  if coordinates in self.objects:
   current.encountered_by(obj)
   obj.encountered(current)
   
class Room(EnclosedArea):
 movement_sound = None

 def move_object(self, obj=None, coordinates=None):
  self.sound_manager.play(self.movement_sound)
  super(Room, self).__move_object(obj=obj, coordinates=coordinates)


class Exit(GameEntity):

 def __init__(self, source=None, destination=None, source_name=None, destination_name=None, source_coordinates=None, destination_coordinates=None, **kwargs):
  if source is not None and source_coordinates is None or destination is not None and destination_coordinates is None:
   raise ValueError("Must supply coordinates for source and or destination if present.")
  super(Exit, self).__init__(**kwargs)
  self.source = source
  self.destination = destination
  if source_name is None and destination is not None:
   source_name = destination.name
  if destination_name is None and source is not None:
   destination_name = source.name
  self.source_name = source_name
  self.destination_name = destination_name
  self.source_coordinates = source_coordinates
  self.destination_coordinates = destination_coordinates
  self.source.add_exit(self, source_name, source_coordinates)
  self.destination.add_exit(self, destination_name, destination_coordinates)

 def encountered_by(self, obj):
  if obj.location not in (self.source, self.destination):
   raise ValueError("Object attempting to travel through exit from unsupported location!")
  if obj.location is self.source:
   self.move_object_to(obj, self.destination)
  else:
   self.move_object_to(obj, self.source)


 def move_object_to(self, obj, location):
  try:
   obj.location.on_exit(obj, exit=self)
  except ExitError:
   return
  try:
   location.on_enter(obj, entrance=self)
  except EntryError:
   return
  