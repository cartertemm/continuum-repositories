"""
Basic speech and sound-based menu by Ryan Strunk
Modifications by Q
"""

import accessible_output
from threading import Timer

def delay(duration, function, *a, **k):
 t = Timer(duration, function, args=a, kwargs=k)
 t.daemon = True
 t.start()
 return t


class GameMenu(object):

 def __init__(self, keyboard_handler, choices=None, menu_music=None, intro_sound=None, intro_text="", click_sound=None, wrap_sound=None, confirm_sound=None, escape_sound=None, escape_method=None, default_method=None, is_sub_menu=False, can_wrap=True, use_sapi=False):
  self.keyboard_handler = keyboard_handler #we need this to register and unregister our keys
  if choices is None:
   choices = []
  self.choices = choices[:]
  self.choice_counter = 0
  self.menu_music = menu_music
  self.intro_sound = intro_sound
  self.intro_text = intro_text
  self.click_sound = click_sound
  self.wrap_sound = wrap_sound
  self.confirm_sound = confirm_sound
  self.escape_sound = escape_sound
  self.escape_method = escape_method
  self.default_method = default_method
  self.is_sub_menu = is_sub_menu
  self.can_wrap = can_wrap
  self.sub_menu = False
  #this is true when the menu item has a sub-menu. it keeps the music from stopping.
  if use_sapi:
   self.speaker = accessible_output.speech.Speaker(accessible_output.speech.outputs.Sapi5())
  else:
   self.speaker = accessible_output.speech.Speaker()
  self.keyboard_handler.register_key('up', self.previous_choice)
  self.keyboard_handler.register_key('down', self.next_choice)
  self.keyboard_handler.register_key('home', self.first_choice)
  self.keyboard_handler.register_key('end', self.last_choice)
  self.keyboard_handler.register_key('return', self.confirm_choice)
  self.keyboard_handler.register_key('escape', self.escape_menu)

 def start(self):
  if self.menu_music is not None:
   if not self.menu_music.is_playing:
    self.menu_music.looping = True
    self.menu_music.play(True)
  if self.intro_sound:
   self.intro_sound.play()
   self.intro_timer = delay(round(self.intro_sound.bytes_to_seconds(len(self.intro_sound)), 1), self.announce_choice)
  elif self.intro_text:
   self.speaker.say(self.intro_text + " " + self.choices[0]['text'], True)
  else:
   self.announce_choice()
  if self.choices[0]['sub'] == True:
   self.sub_menu = True

 def add_choice(self, sound=None, text=None, method=None, args=None, sub=False, stay_open=False):
  self.choices.append({'sound': sound, 'text': text, 'method': method, 'args': args, 'sub': sub, 'stay_open': stay_open})

 def add_choices(self, choices):
  for i in choices:
   self.add_choice(**i)

 def next_choice(self):
  self.increment_choice(direction=1)

 def previous_choice(self):
  self.increment_choice(direction=-1)

 def first_choice(self):
  self.choice_counter = 0
  self.increment_choice(direction=0)

 def last_choice(self):
  self.choice_counter = len(self.choices)-1
  self.increment_choice(direction=0)

 def increment_choice(self, direction):
  wrapped = False
  self.choice_counter += direction
  if self.can_wrap:
   if self.choice_counter == len(self.choices):
    self.choice_counter = 0
    wrapped = True
   if self.choice_counter < 0:
    self.choice_counter = len(self.choices)-1
    wrapped = True
   if self.wrap_sound and wrapped:
    self.wrap_sound.play(True)
  if not self.can_wrap:
   if self.choice_counter == len(self.choices):
    self.choice_counter = len(self.choices)-1
   if self.choice_counter < 0:
    self.choice_counter = 0
  if self.click_sound and not wrapped:
   self.click_sound.play(True)
  if self.choices[self.choice_counter]['sub'] == True:
  #check to see if the menu launches a sub. If not, make self.sub_menu false
   self.sub_menu = True
  else:
   self.sub_menu = False
  self.announce_choice()

 def announce_choice(self):
  if hasattr(self, 'intro_timer') and self.intro_timer.isAlive():
   self.intro_timer.cancel()
  if self.intro_sound is not None and self.intro_sound.is_playing:
   self.intro_sound.stop()
  if self.choices[self.choice_counter]['sound']:
   self.choices[self.choice_counter]['sound'].play(True)
  if self.choices[self.choice_counter]['text']:
   self.speaker.say(self.choices[self.choice_counter]['text'], True)

 def confirm_choice(self):
  if not self.choices[self.choice_counter]['method'] and self.default_method == None:
  #if there is no default method and no method on the menu item, return
   return
  if self.confirm_sound:
   self.confirm_sound.play(True)
  self.end()
  if not self.choices[self.choice_counter]['method'] and self.default_method is not None:
   #if there is no choice on the menu item, but there is a default method, call it
   if self.choices[self.choice_counter]['args']:
    return self.default_method(self.choices[self.choice_counter]['args'])
   else:
    return self.default_method()
  if self.choices[self.choice_counter]['args']:
   self.choices[self.choice_counter]['method'](self.choices[self.choice_counter]['args'])
  else:
   self.choices[self.choice_counter]['method']()

 def escape_menu(self):
  if self.escape_method is None:
   return
  if self.escape_sound:
   self.escape_sound.play(True)
  self.end(escaping=True)
  self.escape_method()

 def end(self, escaping=False):
  if self.choices[self.choice_counter]['stay_open']:
   return
  self.keyboard_handler.unregister_key('up', self.previous_choice)
  self.keyboard_handler.unregister_key('down', self.next_choice)
  self.keyboard_handler.unregister_key('home', self.first_choice)
  self.keyboard_handler.unregister_key('end', self.last_choice)
  self.keyboard_handler.unregister_key('return', self.confirm_choice)
  self.keyboard_handler.unregister_key('escape', self.escape_menu)
  if (self.is_sub_menu and escaping) or self.sub_menu == True:
   return
  if self.menu_music is not None:
   self.menu_music.stop()
