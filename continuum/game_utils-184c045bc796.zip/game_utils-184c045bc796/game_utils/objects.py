import sound

class GameEntity(object):
 ambient_sound = None #This can be either a filename or a list of filenames
 name = "Unnamed"
 
 
 def __init__(self, name=None, location=None, sound_manager=sound.SoundManager):
  super(GameEntity, self).__init__()
  if name is None:
   name = self.name
  self.name = name
  self.sound_manager = sound_manager
  self.ambience = None

 def cycle(self):
  """Method called each iteration through the game loop."""
  super(GameEntity, self).cycle()
  if self.ambience is None or self.ambience.is_stopped:
   self.ambience = self.sound_manager.play(self.ambient_sound)
 
class MovableObject(GameEntity):

 def encounter(self, what):
  """method called when this object encounters another while moving."""
  pass
  
 def encountered_by(self, what):
  """Method called when another object encounters this one as it tries to move to this object's location."""
  pass 
 

class LivingEntity(MovableObject):
 max_health = 0
 pain_sound = None #Like all sounds, a filename or a list 
 death_sound = None

 def __init__(self, health=None, **kwargs):
  super(LivingEntity, self).__init__(**kwargs)
  if health is None:
   health = self.max_health
  self.health = health
  self.inventory = []
  self.equipment = {}

 def harm(self, amount):
  self.sound_manager.play(self.pain_sound)
  self.health -= amount
  if self.health <= 0:
   self.die()

 def die(self):
  self.sound_manager.play(self.death_sound)

 def take(self, obj):
  obj.pick_up(player=self)
  self.inventory.append(obj)
  obj.location = self

 def drop(self, obj):
  if obj not in self.inventory:
   raise ValueError("Cannot drop an object which is not being held.")
  obj.drop(player=self)
  self.inventory.remove(obj)
  obj.location = self.location

class TakeableObject(GameEntity):
 pick_up_sound = None #What does it sound like to pick up this item?
 drop_sound = None #and to drop it?
 inventory_sound = None #The sound this object makes while it's in the player's inventory

 def pick_up(self, player):
  self.sound_manager.play(self.pick_up_sound)

 def drop(self, player):
  self.sound_manager.play(self.drop_sound)

 def cycle(self):
  super(UseableObject, self).cycle()
  if isinstance(self.location, LivingEntity) and self.location.is_holding(self):
   self.sound_manager.play(self.inventory_sound)

class UseableObject(TakeableObject):
 use_sound = None #what's it sound like to use this thing

 def use(self, target=None):
  self.sound_manager.play(self.use_sound)

class EquippableObject(UseableObject):
 equip_sound = None

 def __init__(self, **kwargs):
  super(EquippableObject, self).__init__(**kwargs)
  self.equipped = False

 def equip(self):
  self.sound_manager.play(self.equip_sound)
  self.equipped = True

 def use(self, target=None):
  if not self.equipped:
   return
  super(EquippableObject, self).use(target=target)

class Weapon(EquippableObject):
 potential_damage = 0
 can_attack = True #override with a property for weapons that need preconditions for attacking, such as guns that need loading.
  
 def use(self, target=None):
  if not self.can_attack:
   return
  damage = self.calculate_damage()
  super(Weapon, self).use()
  target.harm(damage)

class InteractableObject(GameEntity):
 interaction_sound = None #What does it sound like to interact with this thing

 def interact(self):
  self.sound_manager.play(self.interaction_sound)

