import os
import sound_lib

class SoundManager(object):

 def __init__(self, default_path="", default_extension='.wav', *args, **kwargs):
  self.default_path = default_path
  self.default_extension = default_extension
  self.sounds = {}
  super(SoundManager, self).__init__(*args, **kwargs)

 def load_sound(self, name, extension=None, path=None, key=None):
  if key is None:
   key = name
  if extension is None:
   extension = self.default_extension
  if path is None:
   path = self.default_path
  filename = os.path.join(path, '%s%s' % (name, extension))
  self.sounds[key] = sound_lib.stream.FileStream(file=filename)

 def play_sound(self, key, pan=0, looping=False, restart=False, volume=1.0, frequency=None):
  snd = self.sounds[key]
  if frequency is None:
   frequency = snd.frequency
  snd.looping = looping
  snd.pan = pan
  snd.volume = volume
  snd.frequency = frequency
  snd.play(restart)

 play = play_sound

 def stop_sound(self, key):
  self.sounds[key].stop()

 def __del__(self):
  self.stop_all_sounds()

 def stop_all_sounds(self):
  for i in self.sounds:
   self.sounds[i].stop()

 def play_all_sounds(self):
  for i in self.sounds:
   self.sounds[i].play()

 