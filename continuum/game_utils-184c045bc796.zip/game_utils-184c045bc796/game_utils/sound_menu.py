import menu
import sound_lib

class SoundMenu(menu.GameMenu):

 def __init__(self, keyboard_handler, choices=None, menu_music=None, intro_sound=None, intro_text="", click_sound=None, wrap_sound=None, confirm_sound=None, escape_sound=None, escape_method=None, default_method=None, is_sub_menu=False, can_wrap=True, use_sapi=False):
  super(SoundMenu, self).__init__(keyboard_handler=keyboard_handler, choices=choices, menu_music=menu_music, intro_sound=intro_sound, intro_text=intro_text, click_sound=click_sound, wrap_sound=wrap_sound, confirm_sound=confirm_sound, escape_sound=escape_sound, escape_method=escape_method, default_method=default_method, is_sub_menu=is_sub_menu, can_wrap=can_wrap, use_sapi=use_sapi)
  self.default_method = self.play_sound

 def add_sound(self, sound_description, sound):
  self.add_choice(text=sound_description, args=sound, stay_open=True)

 def play_sound(self, sound):
  sound.play(True)