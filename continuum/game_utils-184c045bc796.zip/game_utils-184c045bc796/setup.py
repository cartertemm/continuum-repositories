from setuptools import setup, find_packages

__version__ = 0.11
__doc__ = """Commonly-used utilities which most games will need"""

setup(
 name = "game_utils",
 version = __version__,
 description = __doc__,
 package_dir = {'game_utils': 'game_utils'},
 packages = find_packages(),
 classifiers = [
  'Development Status :: 3 - Alpha',
  'Intended Audience :: Developers',
  'Programming Language :: Python',
  'License :: OSI Approved :: MIT License',
  'Topic :: Software Development :: Libraries',
],
)
