from setuptools import setup, find_packages

__doc__ = """A simple wrapper to the Goodreads.com web API"""


setup(
 name = 'goodreads_API',
 version = 0.1,
 description = __doc__,
 packages = find_packages(),
 install_requires = [
  'rauth',
  'xmltodict',
 ],
 classifiers = [
  'Development Status :: 4 - Beta',
  'Intended Audience :: Developers',
  'Programming Language :: Python',
  'Topic :: Software Development :: Libraries',
 ],
)
