from setuptools import setup, find_packages

__version__ = 0.263
__doc__ = """Common GUI components and utilities for WX"""

setup(
 name = "gui_components",
 version = __version__,
 description = __doc__,
 package_dir = {'gui_components': 'gui_components'},
 packages = find_packages(),
 classifiers = [
  'Development Status :: 3 - Alpha',
  'Intended Audience :: Developers',
  'Programming Language :: Python',
  'License :: OSI Approved :: MIT License',
  'Topic :: Software Development :: Libraries',
],
)
