__author__ = 'K.Inanloo'

import os
import xsend
#import win32traceutil

def hook(ui, repo, **kwargs):
    username = ui.config('jabber', 'userid')
    password = ui.config('jabber', 'password')
    xsend.logon(username, password)
    project = os.path.basename(repo.root)
    changesets = []
    first = repo[kwargs['node']].rev()
    for i in range(first, len(repo)):
        changeset = repo[i]
        message = "{user}:\n{branch}: {description}".format(
            user=changeset.user(), description=changeset.description(), branch=changeset.branch())
        changesets.append(message)
    text = "New commits to {project}:\n".format(project=project)
    text += "\n".join(changesets)
    recipients = []
    if ui.config('jabber', project):
        recipients = ui.config('jabber', project).split(',')
    if ui.config('jabber', 'all_repositories'):
        recipients += ui.config('jabber', 'all_repositories').split(',')
    if recipients:
        xsend.sendMessage(text, *recipients)
