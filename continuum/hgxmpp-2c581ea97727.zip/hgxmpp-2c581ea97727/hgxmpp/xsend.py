import xmpp
#import win32traceutil


def logon(username, password, presence=False):
    global cl
    jid = xmpp.protocol.JID(username)
    cl = xmpp.Client(jid.getDomain(), debug=[])
    con = cl.connect()
    if not con:
        print 'Could not connect to jabber!'
    auth = cl.auth(jid.getNode(), password, resource=jid.getResource())
    if not auth:
        print 'Could not authenticate to jabber!'
    if presence:
        cl.SendInitPresence(requestRoster=0)


def sendMessage(message, *recipients):
    global cl
    result = []
    for person in recipients:
        result.append(cl.send(xmpp.protocol.Message(person.strip(), message)))
    return result