from setuptools import setup, find_packages

__version__ = 0.1
__doc__ = """Simple Jabber Mercurial Hook to notify on changesets"""

setup(
	name = 'hgxmpp',
	version = __version__,
	description = __doc__,
	packages = find_packages(),
	install_requires = [
		'xmpppy',
	],
	classifiers = [
		'Development Status :: 5 - Stable',
		'Intended Audience :: Developers',
		'Programming Language :: Python',
		'Topic :: Software Development :: Libraries',
	],
)
