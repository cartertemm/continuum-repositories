from setuptools import setup, find_packages

__name__ = 'i18n_utils'
__version__ = 0.25

setup(
 name = __name__,
 version =__version__,
 description = 'Internationalization utilities',
 package_dir = {'i18n_utils': 'i18n_utils'},
 packages = find_packages(),
 classifiers = [
  'Development Status :: 3 - Alpha',
  'Intended Audience :: Developers',
  'Programming Language :: Python',
  'License :: OSI Approved :: MIT License',
'Topic :: Software Development :: Libraries'
],
)
