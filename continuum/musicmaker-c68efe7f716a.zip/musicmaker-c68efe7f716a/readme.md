This contains a database of lots of lyrics, and a patch file which will convert it to a format so it can be used in SQLite

This is part of a project to automatically generate music

