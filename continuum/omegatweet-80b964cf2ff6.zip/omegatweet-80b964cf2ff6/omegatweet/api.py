from logging import getLogger
logger = getLogger('omegatweet.api')
from urlparse import parse_qs
from urllib import urlencode
from oauth_hook import hook
from client import TwitterClient

class TwitterAPI(TwitterClient):

 report_spam = lambda self, **kwargs: self.POST('report_spam', **kwargs)

 def __init__(self, API_URL="https://api.twitter.com", API_version=1, **kwargs):
  super(TwitterAPI, self).__init__(API_URL=API_URL, API_version=API_version, **kwargs)
  self.account = AccountMethods(self)
  self.statuses = StatusesMethods(self)
  self.users = UsersMethods(self)
  self.lists = ListsMethods(self)
  self.list_members = ListMembersMethods(self)
  self.list_subscribers = ListSubscribersMethods(self)
  self.direct_messages = DirectMessagesMethods(self)
  self.friendships = FriendshipsMethods(self)
  self.favorites = FavoritesMethods(self)
  self.notifications = NotificationsMethods(self)
  self.blocks = BlocksMethods(self)
  self.search = Search(self) #the odd one!
  self.saved_searches = SavedSearchesMethods(self)
  self.trends = TrendsMethods(self)
  self.geo = GeoMethods(self)
  self.oauth = oAuthMethods(self)
  self.help = HelpMethods(self)

 def get_request_token(self, oauth_callback=""):
  """A helper method to get the request token from Twitter and set it up on this API"""
  token = self.oauth.request_token(oauth_callback=oauth_callback)
  self.set_token(token['oauth_token'], token['oauth_token_secret'])

 def get_authorize_URL(self, **kwargs):
  return self.oauth.authorize_URL(oauth_token=self.key, **kwargs)

 def get_access_token(self, oauth_verifier):
  """Gets the access token from Twitter and sets it on this API"""
  self.client.hooks['pre_request'].token.verifier = oauth_verifier
  token = self.oauth.access_token()
  self.set_token(token['oauth_token'], token['oauth_token_secret'])

 def set_token(self, key, secret):
  new_token = hook.Token(key=key, secret=secret)
  self.key, self.secret = new_token.key, new_token.secret
  self.client.hooks['pre_request'].token = new_token



class TwitterMethods(object):
 URL_BASE = ""

 def __init__(self, API, URL_BASE=""):
  self.API = API
  if URL_BASE:
   self.URL_BASE = URL_BASE

 def _build_method(self, method_name):
  if not method_name and self.URL_BASE:
   return self.URL_BASE
  method = method_name
  if self.URL_BASE:
   method = '%s/%s' % (self.URL_BASE, method_name)
  return method

 def GET(self, method, **kwargs):
  return self.API.GET(self._build_method(method), **kwargs)

 def POST(self, method, **kwargs):
  return self.API.POST(self._build_method(method), **kwargs)

class Search(object):
 #The inconsistent twitter API forces this upon us.
 search_url = 'http://search.twitter.com'

 __call__ = lambda self, **kwargs: self.API.process(self.API.client.get('%s/search.json' % self.search_url, data=kwargs))

 def __init__(self, API, search_url=None):
  self.API = API
  self.search_url = search_url or self.search_url


class AccountMethods(TwitterMethods):
 URL_BASE = 'account'
 verify_credentials = lambda self, **kwargs: self.GET('verify_credentials', **kwargs)
 rate_limit_status = lambda self, **kwargs: self.GET('rate_limit_status', **kwargs)
 end_session = lambda self, **kwargs: self.POST('end_session', **kwargs)
 update_delivery_device = lambda self, **kwargs: self.POST('update_delivery_device', **kwargs)
 update_profile_colors = lambda self, **kwargs: self.API.POST('update_profile_colors', **kwargs)
 update_profile = lambda self, **kwargs: self.POST('update_profile', **kwargs)

class StatusesMethods(TwitterMethods):
 URL_BASE = 'statuses'
 public_timeline = lambda self, **kwargs: self.GET('public_timeline', **kwargs)
 home_timeline = lambda self, **kwargs: self.GET('home_timeline', **kwargs)
 friends_timeline = lambda self, **kwargs: self.GET('friends_timeline', **kwargs)
 user_timeline = lambda self, **kwargs: self.GET('user_timeline', **kwargs)
 mentions = lambda self, **kwargs: self.GET('mentions', **kwargs)
 retweeted_by_me = lambda self, **kwargs: self.GET('retweeted_by_me', **kwargs)
 retweeted_to_me = lambda self, **kwargs: self.GET('retweeted_to_me', **kwargs)
 retweets_of_me = lambda self, **kwargs: self.GET('retweets_of_me', **kwargs)
 show = lambda self, **kwargs: self.GET('show', **kwargs)
 update = lambda self, **kwargs: self.POST('update', **kwargs)
 destroy = lambda self, **kwargs: self.POST('destroy', **kwargs)
 retweet = lambda self, id, **kwargs: self.POST('retweet/%d' % id, **kwargs)
 retweets = lambda self, **kwargs: self.GET('retweets', **kwargs)
 friends = lambda self, **kwargs: self.GET('friends', **kwargs)
 followers = lambda self, **kwargs: self.GET('followers', **kwargs)

 def __init__(self, API):
  super(StatusesMethods, self).__init__(API)
  self.retweeted_by = RetweetedByMethods(self)

class RetweetedByMethods(TwitterMethods):
 URL_BASE = 'retweeted_by'
 __call__ = lambda self, id, **kwargs: self.API.GET('%s/%s' % (str(id), self.URL_BASE), **kwargs)
 ids = lambda self, id, **kwargs: self.API.GET('%r/%s/ids' % (id, self.URL_BASE), **kwargs)

class UsersMethods(TwitterMethods):
 URL_BASE = 'users'
 show = lambda self, **kwargs: self.GET('show', **kwargs)
 lookup = lambda self, **kwargs: self.GET('lookup', **kwargs)
 search = lambda self, **kwargs: self.GET('search', **kwargs)

 def __init__(self, API):
  super(UsersMethods, self).__init__(API)
  self.suggestions = SuggestionsMethods(self)

class SuggestionsMethods(TwitterMethods):
 URL_BASE = 'suggestions'
 __call__ = lambda self, **kwargs: self.GET('', **kwargs)
 category = lambda self, slug, **kwargs: self.API.GET('suggestions/%s' % slug, **kwargs)

class ListsMethods(TwitterMethods):
 """
 Twitter's list API departs from the rest of their API somewhat in style. URIs are different, starting generally with the user's screen_name, and a
 greater importance is given to the verbs which are used for accessing the data, with several methods only differing in which verb is used with it. On the
 developer Wiki, names are given to relate this API to others like it, such as the DM API. 
 This class uses the alternative names for these methods as presented by twitter.
 """
 create = lambda self, username, **kwargs: self.API.POST('%s/lists' % username, **kwargs)
 update = lambda self, username, id, **kwargs: self.API.POST('%s/lists/%s' % (username, str(id)), **kwargs)
 __call__ = lambda self, username, **kwargs: self.API.GET('%s/lists' % username, **kwargs)
 show = lambda self, username, id, **kwargs: self.API.GET('%s/lists/%s' % (username, str(id)), **kwargs)
 destroy = lambda self, username, id, **kwargs: self.API.DELETE('%s/lists/%s' % (username, str(id)), **kwargs)
 statuses = lambda self, username, id, **kwargs: self.API.GET('%s/lists/%s/statuses' % (username, str(id)), **kwargs)
 memberships = lambda self, username, id, **kwargs: self.API.GET('%s/lists/%s/memberships' % (username, str(id)), **kwargs)
 subscriptions = lambda self, username, id, **kwargs: self.GET('%s/lists/%s/subscriptions' % (username, str(id)), **kwargs)

class ListMembersMethods(TwitterMethods):
 __call__ = lambda self, username, list_id, **kwargs: self.API.GET('%s/%s/members' % (username, str(list_id)), **kwargs)
 create = lambda self, username, list_id, **kwargs: self.API.POST('%s/%s/members' % (username, str(list_id)), **kwargs)
 destroy = lambda self, username, list_id, **kwargs: self.API.DELETE('%s/%s/members' % (username, str(list_id)), **kwargs)
 show = lambda self, username, list_id, id, **kwargs: self.GET('%s/%s/members/%s' % (username, str(list_id), str(id)), **kwargs)

class ListSubscribersMethods(TwitterMethods):
 __call__ = lambda self, username, list_id, **kwargs: self.API.GET('%s/%s/subscribers' % (username, str(list_id)), **kwargs)
 create = lambda self, username, list_id, **kwargs: self.API.POST('%s/%s/subscribers' % (username, str(list_id)), **kwargs)
 destroy = lambda self, username, list_id, **kwargs: self.API.DELETE('%s/%s/subscribers' % (username, str(list_id)), **kwargs)
 show = lambda self, username, list_id, id, **kwargs: self.GET('%s/%s/subscribers/%s' % (username, str(list_id), str(id)), **kwargs)

class DirectMessagesMethods(TwitterMethods):
 URL_BASE = 'direct_messages'
 __call__ = lambda self, **kwargs: self.GET('', **kwargs)
 sent = lambda self, **kwargs: self.GET('sent', **kwargs)
 new = lambda self, **kwargs: self.POST('new', **kwargs)
 destroy = lambda self, **kwargs: self.POST('destroy', **kwargs)

class FriendshipsMethods(TwitterMethods):
 URL_BASE = 'friendships'
 create = lambda self, **kwargs: self.POST('create', **kwargs)
 destroy = lambda self, **kwargs: self.POST('destroy', **kwargs)
 exists = lambda self, **kwargs: self.GET('exists', **kwargs)
 show = lambda self, **kwargs: self.GET('show', **kwargs)
 incoming = lambda self, **kwargs: self.GET('incoming', **kwargs)
 outgoing = lambda self, **kwargs: self.GET('outgoing', **kwargs)

class FavoritesMethods(TwitterMethods):
 URL_BASE = 'favorites'
 __call__ = lambda self, **kwargs: self.GET('', **kwargs)
 create = lambda self, **kwargs: self.POST('create', **kwargs)
 destroy = lambda self, **kwargs: self.POST('destroy', **kwargs)

class NotificationsMethods(TwitterMethods):
 BASE_URL = 'notifications'
 follow = lambda self, **kwargs: self.POST('follow', **kwargs)
 leave = lambda self, **kwargs: self.POST('leave', **kwargs)

class BlocksMethods(TwitterMethods):
 URL_BASE = 'blocks'
 create = lambda self, **kwargs: self.POST('create', **kwargs)
 destroy = lambda self, **kwargs: self.POST('destroy', **kwargs)
 exists = lambda self, **kwargs: self.GET('exists', **kwargs)
 
 def __init__(self, API):
  super(BlocksMethods, self).__init__(API)
  self.blocking = BlockingMethods(self)

class BlockingMethods(TwitterMethods):
 URL_BASE = 'blocking'
 __call__ = lambda self, **kwargs: self.GET('', **kwargs)
 ids = lambda self, **kwargs: self.GET('ids', **kwargs)

class SavedSearchesMethods(TwitterMethods):
 URL_BASE = 'saved_searches'
 __call__ = lambda self, **kwargs: self.GET('', **kwargs)
 show = lambda self, **kwargs: self.GET('show', **kwargs)
 create = lambda self, **kwargs: self.POST('create', **kwargs)
 destroy = lambda self, **kwargs: self.POST('destroy', **kwargs)

class TrendsMethods(TwitterMethods):
 URL_BASE = 'trends'
 available = lambda self, **kwargs: self.GET('available', **kwargs)
 location = lambda self, **kwargs: self.GET('location', **kwargs)
 current = lambda self, **kwargs: self.GET('current', **kwargs)
 daily = lambda self, **kwargs: self.GET('daily', **kwargs)
 weekly = lambda self, **kwargs: self.GET('weekly', **kwargs)

class GeoMethods(TwitterMethods):
 URL_BASE = 'geo'
 nearby_places = lambda self, **kwargs: self.GET('nearby_places', **kwargs)
 reverse_geocode = lambda self, **kwargs: self.GET('reverse_geocode', **kwargs)
 id = lambda self, **kwargs: self.GET('id', **kwargs)

class HelpMethods(TwitterMethods):
 URL_BASE = 'help'
 test = lambda self, **kwargs: self.GET('test', **kwargs)

class oAuthMethods(TwitterMethods):
 def request_token(self, oauth_callback, **kwargs):
  kwargs['oauth_callback'] = oauth_callback
  response = self.API.client.post('%s/oauth/request_token' % self.API.API_URL, data=kwargs)
  self.response = response
  response.raise_for_status()
  loaded = parse_qs(response.content)
  loaded = {k: v[0] for k, v in loaded.iteritems()}
  return loaded

 authenticate_URL = lambda self, oauth_token: '%s/oauth/authenticate?oauth_token=%s' % (self.API.API_URL, oauth_token)
 authorize_URL = lambda self, **kwargs: '%s/oauth/authorize?%s' % (self.API.API_URL, urlencode(kwargs))

 def access_token(self, oauth_token=None, oauth_secret=None, oauth_verifier=None):
  url = '%s/oauth/access_token' % self.API.API_URL
  #hook, client = self.API.create_hook(oauth_token, oauth_secret, consumer_key=self.API.consumer_key, consumer_secret=self.API.consumer_secret)
  #hook.token.verifier = str(oauth_verifier)
  resp = self.API.client.post(url, data={})
  return {k: v[0] for k, v in parse_qs(resp.content).iteritems()}

