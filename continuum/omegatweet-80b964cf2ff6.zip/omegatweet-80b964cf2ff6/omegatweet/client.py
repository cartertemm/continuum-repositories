from logging import getLogger
logger = getLogger('omegatweet.client')

import requests
import oauth_hook
import json

__version__ = 0.232

class TwitterAPIError(Exception): pass

class TwitterClient(object):
 API_URL = None
 API_version = 1

 def __init__(self, consumer_key=None, consumer_secret=None, key=None, secret=None, API_URL=None, API_version=None, deserializer=json.loads):
  super(TwitterClient, self).__init__()
  if None in (consumer_key, consumer_secret):
   raise ValueError("Must supply a consumer key and secret.")
  if API_URL is None and self.API_URL is not None:
   API_URL = self.API_URL
  if API_version is None:
   API_version = self.API_version
  self.API_URL = API_URL
  self.API_version = API_version
  self.deserializer = deserializer
  self.OAuth_hook, self.client = self.create_hook(key=key, secret=secret, consumer_key=consumer_key, consumer_secret=consumer_secret)
  self.consumer_key, self.consumer_secret = consumer_key, consumer_secret
  self.key, self.secret = key, secret
  
 def create_hook(self, key=None, secret=None, consumer_key=None, consumer_secret=None):
  if not consumer_key:
   consumer_key = self.consumer_key
  if not consumer_secret:
   consumer_secret = self.consumer_secret
  #Create the OAuth hook.
  hook = oauth_hook.OAuthHook(key, secret, consumer_key=consumer_key, consumer_secret=consumer_secret)
  client = requests.session(hooks={'pre_request': hook})
  client.config['base_headers']['user-agent'] = "Omegatweet / %s" % __version__
  return (hook, client)

 def has_authentication_information(self):
  """Returns a boolean indicating if this item has all required oAuth information. It does not verify if the information is correct -- for that, use account.verify_credentials"""
  return None not in (self.OAuth_hook.token, self.OAuth_hook.consumer)

 def GET(self, method, postprocess=True, versioned=True, **kwargs):
  return self.process(self.client.get, method, postprocess=postprocess, versioned=versioned, **kwargs)

 def POST(self, method, postprocess=True, versioned=True, **kwargs):
  return self.process(self.client.post, method, postprocess=postprocess, versioned=versioned, **kwargs)

 def DELETE(self, method, postprocess=True, versioned=True, **kwargs):
  return self.process(self.client.delete, method, postprocess=postprocess, versioned=versioned, **kwargs)

 def process(self, func, method, postprocess=True, versioned=True, **kwargs):
  data = func(self.build_URL(method, versioned=versioned), data=kwargs)
  if postprocess:
   data = self.postprocess(data)
  return data

 def postprocess(self, response):
  try:
   response.raise_for_status()
  except requests.exceptions.HTTPError:
   raise TwitterAPIError(response.content)
  data = response.content
  if self.deserializer:
   data = self.deserializer(data)
  return data

 def build_URL(self, method, versioned=True, format='.json'):
  API_URL = self.API_URL
  if versioned and self.API_version:
   API_URL = '%s/%s' % (API_URL, self.API_version)
  if format:
   url = '%s/%s%s' % (API_URL, method, format)
  else:
   url = '%s/%s' % (API_URL, method)
  logger.debug("build_URL constructed the URL %r" % url)
  return url
