from client import TwitterClient
import time
import json
from ssl import SSLError

class ConnectionError(Exception): pass

class UserStream(TwitterClient):
 BUFFER_SEP = '\r'

 def __init__(self, url='https://userstream.twitter.com/2/user.json', callback=None, reconnected_callback=None, retry_delay=5, **kwargs):
  super(UserStream, self).__init__(**kwargs)
  self.url = url
  self.response = None
  self.connected = False
  self.callback = callback
  self.reconnected_callback = reconnected_callback
  self.retry_delay = retry_delay
  self.connect_times = 0

 def stream(self):
  while True:
   try:
    if self.response is None:
     self.create_connection()
     if self.connect_times > 1:
      self.call_callback(self.reconnected_callback)
    self.perform_read()
   except ConnectionError:
    time.sleep(self.retry_delay)
    self.response = None
    self.reconnecting = True
  self.connected = False

 def perform_read(self):
  data = self.response.iter_content(1)
  buffer = []
  try:
   for counter, char in enumerate(data): #there's probably a better way of doing this.
    if char == self.BUFFER_SEP:
     self.load_data("".join(buffer))
     del buffer[:]
    else:
     buffer.append(char)
  except SSLError:
   raise ConnectionError

 def load_data(self, buffer):
  buffer = buffer.strip()
  if not buffer:
   return
  loaded = json.loads(buffer)
  self.call_callback(self.callback, loaded)

 def create_connection(self):
  self.response = self.client.get(self.url, timeout=self.retry_delay*10)
  self.connected = True
  self.connect_times += 1

 @staticmethod
 def call_callback(callback, *args, **kwargs):
  if not callable(callback):
   return
  try:
   callback(*args, **kwargs)
  except:
   pass
