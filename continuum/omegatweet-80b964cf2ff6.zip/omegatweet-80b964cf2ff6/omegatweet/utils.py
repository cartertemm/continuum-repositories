import calendar
import rfc822

def convert_twitter_timestamp_to_time(timestamp):
    """Given a time from Twitter such as "Thu Nov 10 01:24:24 +0000 2011", returns its equivalent Unix timestamp."""
    return calendar.timegm(rfc822.parsedate(timestamp))
