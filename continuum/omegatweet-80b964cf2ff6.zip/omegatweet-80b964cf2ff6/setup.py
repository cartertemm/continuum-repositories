from setuptools import setup, find_packages
from omegatweet import client


__version__ = client.__version__
__doc__ = """Lightweight and faithful wrapper to the Twitter REST and Streaming APIs."""
__author__ = u'Christopher Toth'

setup(
 name = u'omegatweet',
 version = __version__,
 author = __author__,
 author_email = u'q@qwitter-client.net',
 description = __doc__,
 package_dir = {'omegatweet': 'omegatweet'},
 packages = find_packages(),
 install_requires = [
  'requests',
  'requests-oauth',
 ],
 classifiers = [
  'Development Status :: 3 - Alpha',
  'Intended Audience :: Developers',
  'Programming Language :: Python',
  'License :: OSI Approved :: MIT License',
  'Topic :: Software Development :: Libraries',
 ],
)
