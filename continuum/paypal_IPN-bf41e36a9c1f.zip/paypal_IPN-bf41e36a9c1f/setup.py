from setuptools import setup

setup(
 name = "paypal_IPN",
 version = 0.15,
 description = "Simple PayPal IPN Listener",
 package_dir = {'paypal_IPN': '.'},
 packages = ['paypal_IPN'],
 install_requires = ['requests'],
)
