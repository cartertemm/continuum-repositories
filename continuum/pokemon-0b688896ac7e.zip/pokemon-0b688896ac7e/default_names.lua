{
  [257] = {
    map = "Olivine Pokémon Center 1F"
  },
  [258] = {
    map = "Olivine Gym"
  },
  [259] = {
    map = "Olivine Voltorb House"
  },
  [260] = {
    map = "Olivine House Beta"
  },
  [261] = {
    map = "Olivine Punishment Speech House"
  },
  [262] = {
    map = "Olivine Good Rod House"
  },
  [263] = {
    map = "Olivine Cafe"
  },
  [264] = {
    map = "Olivine Mart"
  },
  [265] = {
    map = "Route 38 Ecruteak Gate"
  },
  [266] = {
    map = "Route 39 Barn"
  },
  [267] = {
    map = "Route 39 Farmhouse"
  },
  [268] = {
    map = "Route 38"
  },
  [269] = {
    map = "Route 39"
  },
  [270] = {
    map = "Olivine City"
  },
  [513] = {
    map = "Mahogany Red Gyarados Speech House"
  },
  [514] = {
    map = "Mahogany Gym"
  },
  [515] = {
    map = "Mahogany Pokémon Center 1F"
  },
  [516] = {
    map = "Route 42 Ecruteak Gate"
  },
  [517] = {
    map = "Route 42"
  },
  [518] = {
    map = "Route 44"
  },
  [519] = {
    map = "Mahogany Town"
  },
  [769] = {
    map = "Sprout Tower 1F"
  },
  [770] = {
    map = "Sprout Tower 2F"
  },
  [771] = {
    map = "Sprout Tower 3F"
  },
  [772] = {
    map = "Tin Tower 1F"
  },
  [773] = {
    map = "Tin Tower 2F"
  },
  [774] = {
    map = "Tin Tower 3F"
  },
  [775] = {
    map = "Tin Tower 4F"
  },
  [776] = {
    map = "Tin Tower 5F"
  },
  [777] = {
    map = "Tin Tower 6F"
  },
  [778] = {
    map = "Tin Tower 7F"
  },
  [779] = {
    map = "Tin Tower 8F"
  },
  [780] = {
    map = "Tin Tower 9F"
  },
  [781] = {
    map = "Burned Tower 1F"
  },
  [782] = {
    map = "Burned Tower B1F"
  },
  [783] = {
    map = "National Park"
  },
  [784] = {
    map = "National Park Bug Contest"
  },
  [785] = {
    map = "Radio Tower 1F"
  },
  [786] = {
    map = "Radio Tower 2F"
  },
  [787] = {
    map = "Radio Tower 3F"
  },
  [788] = {
    map = "Radio Tower 4F"
  },
  [789] = {
    map = "Radio Tower 5F"
  },
  [790] = {
    map = "Ruins of Alph Outside"
  },
  [791] = {
    map = "Ruins of Alph Ho-oh Chamber"
  },
  [792] = {
    map = "Ruins of Alph Kabuto Chamber"
  },
  [793] = {
    map = "Ruins of Alph Omanyte Chamber"
  },
  [794] = {
    map = "Ruins of Alph Aerodactyl Chamber"
  },
  [795] = {
    map = "Ruins of Alph Inner Chamber"
  },
  [796] = {
    map = "Ruins of Alph Research Center"
  },
  [797] = {
    map = "Ruins of Alph Ho-oh Item Room"
  },
  [798] = {
    map = "Ruins of Alph Kabuto Item Room"
  },
  [799] = {
    map = "Ruins of Alph Omanyte Item Room"
  },
  [800] = {
    map = "Ruins of Alph Aerodactyl Item Room"
  },
  [801] = {
    map = "Ruins of Alph Ho-Oh Word Room"
  },
  [802] = {
    map = "Ruins of Alph Kabuto Word Room"
  },
  [803] = {
    map = "Ruins of Alph Omanyte Word Room"
  },
  [804] = {
    map = "Ruins of Alph Aerodactyl Word Room"
  },
  [805] = {
    map = "Union Cave 1F"
  },
  [806] = {
    map = "Union Cave B1F"
  },
  [807] = {
    map = "Union Cave B2F"
  },
  [808] = {
    map = "Slowpoke Well B1F"
  },
  [809] = {
    map = "Slowpoke Well B2F"
  },
  [810] = {
    map = "Olivine Lighthouse 1F"
  },
  [811] = {
    map = "Olivine Lighthouse 2F"
  },
  [812] = {
    map = "Olivine Lighthouse 3F"
  },
  [813] = {
    map = "Olivine Lighthouse 4F"
  },
  [814] = {
    map = "Olivine Lighthouse 5F"
  },
  [815] = {
    map = "Olivine Lighthouse 6F"
  },
  [816] = {
    map = "Mahogany Mart 1F"
  },
  [817] = {
    map = "Team Rocket Base B1F"
  },
  [818] = {
    map = "Team Rocket Base B2F"
  },
  [819] = {
    map = "Team Rocket Base B3F"
  },
  [820] = {
    map = "Ilex Forest"
  },
  [821] = {
    map = "Warehouse Entrance"
  },
  [822] = {
    map = "Underground Path Switch Room Entrances"
  },
  [823] = {
    map = "Goldenrod Dept Store B1F"
  },
  [824] = {
    map = "Underground Warehouse"
  },
  [825] = {
    map = "Mount Mortar 1F Outside"
  },
  [826] = {
    map = "Mount Mortar 1F Inside"
  },
  [827] = {
    map = "Mount Mortar 2F Inside"
  },
  [828] = {
    map = "Mount Mortar B1F"
  },
  [829] = {
    map = "Ice Path 1F"
  },
  [830] = {
    map = "Ice Path B1F"
  },
  [831] = {
    map = "Ice Path B2F Mahogany Side"
  },
  [832] = {
    map = "Ice Path B2F Blackthorn Side"
  },
  [833] = {
    map = "Ice Path B3F"
  },
  [834] = {
    map = "Whirl Island NW"
  },
  [835] = {
    map = "Whirl Island NE"
  },
  [836] = {
    map = "Whirl Island SW"
  },
  [837] = {
    map = "Whirl Island Cave"
  },
  [838] = {
    map = "Whirl Island SE"
  },
  [839] = {
    map = "Whirl Island B1F"
  },
  [840] = {
    map = "Whirl Island B2F"
  },
  [841] = {
    map = "Whirl Island Lugia Chamber"
  },
  [842] = {
    map = "Silver Cave Room 1"
  },
  [843] = {
    map = "Silver Cave Room 2"
  },
  [844] = {
    map = "Silver Cave Room 3"
  },
  [845] = {
    map = "Silver Cave Item Rooms"
  },
  [846] = {
    map = "Dark Cave Violet Entrance"
  },
  [847] = {
    map = "Dark Cave Blackthorn Entrance"
  },
  [848] = {
    map = "Dragon's Den 1F"
  },
  [849] = {
    map = "Dragon's Den B1F"
  },
  [850] = {
    map = "Dragon Shrine"
  },
  [851] = {
    map = "Tohjo Falls"
  },
  [852] = {
    map = "Diglett's Cave"
  },
  [853] = {
    map = "Mount Moon"
  },
  [854] = {
    map = "Underground"
  },
  [855] = {
    map = "Rock Tunnel 1F"
  },
  [856] = {
    map = "Rock Tunnel B1F"
  },
  [857] = {
    map = "Safari Zone Fuchsia Gate Beta"
  },
  [858] = {
    map = "Safari Zone Beta"
  },
  [859] = {
    map = "Victory Road"
  },
  [1025] = {
    map = "Ecruteak House"
  },
  [1026] = {
    map = "Wise Trio's Room"
  },
  [1027] = {
    map = "Ecruteak Pokémon Center 1F"
  },
  [1028] = {
    map = "Ecruteak Lugia Speech House"
  },
  [1029] = {
    map = "Dance Theatre"
  },
  [1030] = {
    map = "Ecruteak Mart"
  },
  [1031] = {
    map = "Ecruteak Gym"
  },
  [1032] = {
    map = "Ecruteak Itemfinder House"
  },
  [1033] = {
    map = "Ecruteak City"
  },
  [1281] = {
    map = "Blackthorn Gym 1F"
  },
  [1282] = {
    map = "Blackthorn Gym 2F"
  },
  [1283] = {
    map = "Blackthorn Dragon Speech House"
  },
  [1284] = {
    map = "Blackthorn Dodrio Trade House"
  },
  [1285] = {
    map = "Blackthorn Mart"
  },
  [1286] = {
    map = "Blackthorn Pokémon Center 1F"
  },
  [1287] = {
    map = "Move Deleter's House"
  },
  [1288] = {
    map = "Route 45"
  },
  [1289] = {
    map = "Route 46"
  },
  [1290] = {
    map = "Blackthorn City"
  },
  [1537] = {
    map = "Cinnabar Pokémon Center 1F"
  },
  [1538] = {
    map = "Cinnabar Pokémon Center 2F Beta"
  },
  [1539] = {
    map = "Route 19 - Fuchsia Gate"
  },
  [1540] = {
    map = "Seafoam Gym"
  },
  [1541] = {
    map = "Route 19"
  },
  [1542] = {
    map = "Route 20"
  },
  [1543] = {
    map = "Route 21"
  },
  [1544] = {
    map = "Cinnabar Island"
  },
  [1793] = {
    map = "Cerulean Gym Badge Speech House"
  },
  [1794] = {
    map = "Cerulean Police Station"
  },
  [1795] = {
    map = "Cerulean Trade Speech House"
  },
  [1796] = {
    map = "Cerulean Pokémon Center 1F"
  },
  [1797] = {
    map = "Cerulean Pokémon Center 2F Beta"
  },
  [1798] = {
    map = "Cerulean Gym"
  },
  [1799] = {
    map = "Cerulean Mart"
  },
  [1800] = {
    map = "Route 10 Pokémon Center 1F"
  },
  [1801] = {
    map = "Route 10 Pokémon Center 2F Beta"
  },
  [1802] = {
    map = "Power Plant"
  },
  [1803] = {
    map = "Bill's House"
  },
  [1804] = {
    map = "Route 4"
  },
  [1805] = {
    map = "Route 9"
  },
  [1806] = {
    map = "Route 10 North"
  },
  [1807] = {
    map = "Route 24"
  },
  [1808] = {
    map = "Route 25"
  },
  [1809] = {
    map = "Cerulean City"
  },
  [2049] = {
    map = "Azalea Pokémon Center 1F"
  },
  [2050] = {
    map = "Charcoal Kiln"
  },
  [2051] = {
    map = "Azalea Mart"
  },
  [2052] = {
    map = "Kurt's House"
  },
  [2053] = {
    map = "Azalea Gym"
  },
  [2054] = {
    map = "Route 33"
  },
  [2055] = {
    map = "Azalea Town"
  },
  [2305] = {
    map = "Lake of Rage Hidden Power House"
  },
  [2306] = {
    map = "Lake of Rage Magikarp House"
  },
  [2307] = {
    map = "Route 43 Mahogany Gate"
  },
  [2308] = {
    map = "Route 43 Gate"
  },
  [2309] = {
    map = "Route 43"
  },
  [2310] = {
    map = "Lake of Rage"
  },
  [2561] = {
    map = "Route 32"
  },
  [2562] = {
    map = "Route 35"
  },
  [2563] = {
    map = "Route 36"
  },
  [2564] = {
    map = "Route 37"
  },
  [2565] = {
    map = "Violet City"
  },
  [2566] = {
    map = "Violet Mart"
  },
  [2567] = {
    map = "Violet Gym"
  },
  [2568] = {
    map = "Earl's Pokémon Academy"
  },
  [2569] = {
    map = "Violet Nickname Speech House"
  },
  [2570] = {
    map = "Violet Pokémon Center 1F"
  },
  [2571] = {
    map = "Violet Onix Trade House"
  },
  [2572] = {
    map = "Route 32 Ruins of Alph Gate"
  },
  [2573] = {
    map = "Route 32 Pokémon Center 1F"
  },
  [2574] = {
    map = "Route 35 Goldenrod gate"
  },
  [2575] = {
    map = "Route 35 National Park gate"
  },
  [2576] = {
    map = "Route 36 Ruins of Alph gate"
  },
  [2577] = {
    map = "Route 36 National Park gate"
  },
  [2817] = {
    map = "Route 34"
  },
  [2818] = {
    map = "Goldenrod City"
  },
  [2819] = {
    map = "Goldenrod Gym"
  },
  [2820] = {
    map = "Goldenrod Bike Shop"
  },
  [2821] = {
    map = "Goldenrod Happiness Rater"
  },
  [2822] = {
    map = "Goldenrod Bill's House"
  },
  [2823] = {
    map = "Goldenrod Magnet Train Station"
  },
  [2824] = {
    map = "Goldenrod Flower Shop"
  },
  [2825] = {
    map = "Goldenrod PP Speech House"
  },
  [2826] = {
    map = "Goldenrod Name Rater's House"
  },
  [2827] = {
    map = "Goldenrod Dept Store 1F"
  },
  [2828] = {
    map = "Goldenrod Dept Store 2F"
  },
  [2829] = {
    map = "Goldenrod Dept Store 3F"
  },
  [2830] = {
    map = "Goldenrod Dept Store 4F"
  },
  [2831] = {
    map = "Goldenrod Dept Store 5F"
  },
  [2832] = {
    map = "Goldenrod Dept Store 6F"
  },
  [2833] = {
    map = "Goldenrod Dept Store Elevator"
  },
  [2834] = {
    map = "Goldenrod Dept Store Roof"
  },
  [2835] = {
    map = "Goldenrod Game Corner"
  },
  [2836] = {
    map = "Goldenrod Pokémon Center 1F"
  },
  [2837] = {
    map = "Goldenrod PokéCom Center 2F Mobile"
  },
  [2838] = {
    map = "Ilex Forest Azalea Gate"
  },
  [2839] = {
    map = "Route 34 Ilex Forest Gate"
  },
  [2840] = {
    map = "Day Care"
  },
  [3073] = {
    map = "Route 6"
  },
  [3074] = {
    map = "Route 11"
  },
  [3075] = {
    map = "Vermilion City"
  },
  [3076] = {
    map = "Vermilion House Fishing Speech House"
  },
  [3077] = {
    map = "Vermilion Pokémon Center 1F"
  },
  [3078] = {
    map = "Vermilion Pokémon Center 2F Beta"
  },
  [3079] = {
    map = "Pokémon Fan Club"
  },
  [3080] = {
    map = "Vermilion Magnet Train Speech House"
  },
  [3081] = {
    map = "Vermilion Mart"
  },
  [3082] = {
    map = "Vermilion House Diglett's Cave Speech House"
  },
  [3083] = {
    map = "Vermilion Gym"
  },
  [3084] = {
    map = "Route 6 Saffron Gate"
  },
  [3085] = {
    map = "Route 6 Underground Entrance"
  },
  [3329] = {
    map = "Route 1"
  },
  [3330] = {
    map = "Pallet Town"
  },
  [3331] = {
    map = "Red's House 1F"
  },
  [3332] = {
    map = "Red's House 2F"
  },
  [3333] = {
    map = "Blue's House"
  },
  [3334] = {
    map = "Oak's Lab"
  },
  [3585] = {
    map = "Route 3"
  },
  [3586] = {
    map = "Pewter City"
  },
  [3587] = {
    map = "Pewter Nidoran Speech House"
  },
  [3588] = {
    map = "Pewter Gym"
  },
  [3589] = {
    map = "Pewter Mart"
  },
  [3590] = {
    map = "Pewter Pokémon Center 1F"
  },
  [3591] = {
    map = "Pewter Pokémon Center 2F Beta"
  },
  [3592] = {
    map = "Pewter Snooze Speech House"
  },
  [3841] = {
    map = "Olivine Port"
  },
  [3842] = {
    map = "Vermilion Port"
  },
  [3843] = {
    map = "Fast Ship 1F"
  },
  [3844] = {
    map = "Fast Ship Cabins NNW, NNE, NE"
  },
  [3845] = {
    map = "Fast Ship Cabins SW, SSW, NW"
  },
  [3846] = {
    map = "Fast Ship Cabins SE, SSE, Captain's Cabin"
  },
  [3847] = {
    map = "Fast Ship B1F"
  },
  [3848] = {
    map = "Olivine Port Passage"
  },
  [3849] = {
    map = "Vermilion Port Passage"
  },
  [3850] = {
    map = "Mount Moon Square"
  },
  [3851] = {
    map = "Mount Moon Gift Shop"
  },
  [3852] = {
    map = "Tin Tower Roof"
  },
  [4097] = {
    map = "Route 23"
  },
  [4098] = {
    map = "Indigo Plateau Pokémon Center 1F"
  },
  [4099] = {
    map = "Will's Room"
  },
  [4100] = {
    map = "Koga's Room"
  },
  [4101] = {
    map = "Bruno's Room"
  },
  [4102] = {
    map = "Karen's Room"
  },
  [4103] = {
    map = "Lance's Room"
  },
  [4104] = {
    map = "Hall of Fame"
  },
  [4353] = {
    map = "Route 13"
  },
  [4354] = {
    map = "Route 14"
  },
  [4355] = {
    map = "Route 15"
  },
  [4356] = {
    map = "Route 18"
  },
  [4357] = {
    map = "Fuchsia City"
  },
  [4358] = {
    map = "Fuchsia Mart"
  },
  [4359] = {
    map = "Safari Zone Main Office"
  },
  [4360] = {
    map = "Fuchsia Gym"
  },
  [4361] = {
    map = "Fuchsia Bill Speech House"
  },
  [4362] = {
    map = "Fuchsia Pokémon Center 1F"
  },
  [4363] = {
    map = "Fuchsia Pokémon Center 2F Beta"
  },
  [4364] = {
    map = "Safari Zone Warden's Home"
  },
  [4365] = {
    map = "Route 15 Fuchsia Gate"
  },
  [4609] = {
    map = "Route 8"
  },
  [4610] = {
    map = "Route 12"
  },
  [4611] = {
    map = "Route 10 South"
  },
  [4612] = {
    map = "Lavender Town"
  },
  [4613] = {
    map = "Lavender Pokémon Center 1F"
  },
  [4614] = {
    map = "Lavender Pokémon Center 2F Beta"
  },
  [4615] = {
    map = "Mr. Fuji's House"
  },
  [4616] = {
    map = "Lavender Town Speech House"
  },
  [4617] = {
    map = "Lavender Name Rater"
  },
  [4618] = {
    map = "Lavender Mart"
  },
  [4619] = {
    map = "Soul House"
  },
  [4620] = {
    map = "Lav Radio Tower 1F"
  },
  [4621] = {
    map = "Route 8 Saffron Gate"
  },
  [4622] = {
    map = "Route 12 Super Rod House"
  },
  [4865] = {
    map = "Route 28"
  },
  [4866] = {
    map = "Silver Cave Outside"
  },
  [4867] = {
    map = "Silver Cave Pokémon Center 1F"
  },
  [4868] = {
    map = "Route 28 Famous Speech House"
  },
  [5121] = {
    map = "Pokémon Center 2F"
  },
  [5122] = {
    map = "Trade Center"
  },
  [5123] = {
    map = "Colosseum"
  },
  [5124] = {
    map = "Time Capsule"
  },
  [5125] = {
    map = "Mobile Trade Room Mobile"
  },
  [5126] = {
    map = "Mobile Battle Room"
  },
  [5377] = {
    map = "Route 7"
  },
  [5378] = {
    map = "Route 16"
  },
  [5379] = {
    map = "Route 17"
  },
  [5380] = {
    map = "Celadon City"
  },
  [5381] = {
    map = "Celadon Dept Store 1F"
  },
  [5382] = {
    map = "Celadon Dept Store 2F"
  },
  [5383] = {
    map = "Celadon Dept Store 3F"
  },
  [5384] = {
    map = "Celadon Dept Store 4F"
  },
  [5385] = {
    map = "Celadon Dept Store 5F"
  },
  [5386] = {
    map = "Celadon Dept Store 6F"
  },
  [5387] = {
    map = "Celadon Dept Store Elevator"
  },
  [5388] = {
    map = "Celadon Mansion 1F"
  },
  [5389] = {
    map = "Celadon Mansion 2F"
  },
  [5390] = {
    map = "Celadon Mansion 3F"
  },
  [5391] = {
    map = "Celadon Mansion Roof"
  },
  [5392] = {
    map = "Celadon Mansion Roof House"
  },
  [5393] = {
    map = "Celadon Pokémon Center 1F"
  },
  [5394] = {
    map = "Celadon Pokémon Center 2F Beta"
  },
  [5395] = {
    map = "Celadon Game Corner"
  },
  [5396] = {
    map = "Celadon Game Corner Prize Room"
  },
  [5397] = {
    map = "Celadon Gym"
  },
  [5398] = {
    map = "Celadon Cafe"
  },
  [5399] = {
    map = "Route 16 Fuchsia Speech House"
  },
  [5400] = {
    map = "Route 16 Gate"
  },
  [5401] = {
    map = "Route 7 Saffron Gate"
  },
  [5402] = {
    map = "Route 17 18 Gate"
  },
  [5633] = {
    map = "Route 40"
  },
  [5634] = {
    map = "Route 41"
  },
  [5635] = {
    map = "Cianwood City"
  },
  [5636] = {
    map = "Mania's House"
  },
  [5637] = {
    map = "Cianwood Gym"
  },
  [5638] = {
    map = "Cianwood Pokémon Center 1F"
  },
  [5639] = {
    map = "Cianwood Pharmacy"
  },
  [5640] = {
    map = "Cianwood City Photo Studio"
  },
  [5641] = {
    map = "Cianwood Lugia Speech House"
  },
  [5642] = {
    map = "Poke Seer's House"
  },
  [5643] = {
    map = "Battle Tower 1F"
  },
  [5644] = {
    map = "Battle Tower Battle Room"
  },
  [5645] = {
    map = "Battle Tower Elevator"
  },
  [5646] = {
    map = "Battle Tower Hallway"
  },
  [5647] = {
    map = "Route 40 Battle Tower Gate"
  },
  [5648] = {
    map = "Battle Tower Outside"
  },
  [5889] = {
    map = "Route 2"
  },
  [5890] = {
    map = "Route 22"
  },
  [5891] = {
    map = "Viridian City"
  },
  [5892] = {
    map = "Viridian Gym"
  },
  [5893] = {
    map = "Viridian Nickname Speech House"
  },
  [5894] = {
    map = "Trainer House 1F"
  },
  [5895] = {
    map = "Trainer House B1F"
  },
  [5896] = {
    map = "Viridian Mart"
  },
  [5897] = {
    map = "Viridian Pokémon Center 1F"
  },
  [5898] = {
    map = "Viridian Pokémon Center 2F Beta"
  },
  [5899] = {
    map = "Route 2 Nugget Speech House"
  },
  [5900] = {
    map = "Route 2 Gate"
  },
  [5901] = {
    map = "Victory Road Gate"
  },
  [6145] = {
    map = "Route 26"
  },
  [6146] = {
    map = "Route 27"
  },
  [6147] = {
    map = "Route 29"
  },
  [6148] = {
    map = "New Bark Town"
  },
  [6149] = {
    map = "Elm's Lab"
  },
  [6150] = {
    map = "Kris's House 1F"
  },
  [6151] = {
    map = "Kris's House 2F"
  },
  [6152] = {
    map = "Kris's Neighbor's House"
  },
  [6153] = {
    map = "Elm's House"
  },
  [6154] = {
    map = "Route 26 Heal Speech House"
  },
  [6155] = {
    map = "Route 26 Day of Week Siblings House"
  },
  [6156] = {
    map = "Route 27 Sandstorm House"
  },
  [6157] = {
    map = "Route 29 46 Gate"
  },
  [6401] = {
    map = "Route 5"
  },
  [6402] = {
    map = "Saffron City"
  },
  [6403] = {
    map = "Fighting Dojo"
  },
  [6404] = {
    map = "Saffron Gym"
  },
  [6405] = {
    map = "Saffron Mart"
  },
  [6406] = {
    map = "Saffron Pokémon Center 1F"
  },
  [6407] = {
    map = "Saffron Pokémon Center 2F Beta"
  },
  [6408] = {
    map = "Mr. Psychic's House"
  },
  [6409] = {
    map = "Saffron Train Station"
  },
  [6410] = {
    map = "Silph Co. 1F"
  },
  [6411] = {
    map = "Copycat's House 1F"
  },
  [6412] = {
    map = "Copycat's House 2F"
  },
  [6413] = {
    map = "Route 5 Underground Entrance"
  },
  [6414] = {
    map = "Route 5 Saffron City Gate"
  },
  [6415] = {
    map = "Route 5 Cleanse Tag Speech House"
  },
  [6657] = {
    map = "Route 30"
  },
  [6658] = {
    map = "Route 31"
  },
  [6659] = {
    map = "Cherrygrove City"
  },
  [6660] = {
    map = "Cherrygrove Mart"
  },
  [6661] = {
    map = "Cherrygrove Pokémon Center 1F"
  },
  [6662] = {
    map = "Cherrygrove Gym Speech House"
  },
  [6663] = {
    map = "Guide Gent's House"
  },
  [6664] = {
    map = "Cherrygrove Evolution Speech House"
  },
  [6665] = {
    map = "Route 30 Berry Speech House"
  },
  [6666] = {
    map = "Mr. Pokémon's House"
  },
  [6667] = {
    map = "Route 31 Violet Gate"
  }
}