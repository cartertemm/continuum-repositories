import math
import time as _time

minint = -2147483648
maxint = 2147483647

def abs(x):
 return abs(x)

def acos(x):
 return math.acos(x)

def asin(x):
 return math.asin(x)

def atan(x):
 return math.atan(x)

def ceil(x):
 return math.ceil(x)

def cos(x):
 return math.cos(x)

def cosh(x):
 return math.cosh(x)

def floor(x):
 return math.floor(x)

def max(*a):
 return max(*a)

def min(*a):
 return min(*a)

def length(obj):
 return len(obj)

def sin(x):
 return math.sin(x)

def sinh(x):
 return math.sinh(x)

def sqrt(x):
 return math.sqrt(x)

def tan(x):
 return math.tan(x)

def tanh(x):
 return math.tanh(x)

def index(str1, str2, case_matters=False):
 if not case_matters:
  str1 = str1.lower()
  str2=str2.lower()
 return str1.index(str2)

def rindex(str1, str2, case_matters=False):
 if not case_matters:
  str1 = str1.lower()
  str2=str2.lower()
 return str1.rindex(str2)

def exp(x):
 return math.e ** x

def typeof(what):
 mapping = {
  str: STR,
  float: FLOAT,
  int: INT,
  list: LIST,
  Exception: ERR
 }
 return mapping[what.__class__]


def verbs(obj):
 #todo: respect read permission model
 return obj.verbs

def valid(obj):
 return obj.database.is_valid(obj)

def toint(x):
 try:
  val = int(float(x))
 except ValueError:
  val = 0
 return val

def tofloat(x):
 return float(x)

def time():
 return int(_time.time())

def ctime(x=time()):
 if x < minint or x > maxint:
  return "ERR INVALID TIME"
 timestr = _time.ctime(x)
 tzstr = _time.tzname[_time.localtime(x)[8]]
 tzspl = tzstr.split()
 tzname = ""
 if len(tzspl) != 1:
  for w in tzspl:
   tzname = tzname + w[0]
 else:
  tzname = tzstr
 return timestr + " " + tzname

