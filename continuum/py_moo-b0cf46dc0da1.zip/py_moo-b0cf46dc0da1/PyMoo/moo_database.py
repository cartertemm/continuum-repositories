from logging import getLogger
logger = getLogger('database')

import new
from moo_object import MooObjectStub, MooObject, ObjRef

class DatabaseError(Exception):
 pass

class MooDatabase(object):

 def __init__(self, version_string=None, total_objects=0, total_verbs=0, total_players=0, players=None, objects=None):
  self.version_string = version_string
  self.total_objects = total_objects
  self.total_verbs = total_verbs
  self.total_players = total_players
  if players is None:
   players = []
  self.players = players
  if objects is None:
   objects = {}
  self.stub_objects = objects
  self.objects = {}
  self.objects[-1] = MooObject(-1)
  l = self.stub_objects.keys()
  for i in l:
   if i in self.objects:
    continue
   self.create_object(self.stub_objects[i])
  self.resolve_relationships()
 
 def resolve_relationships(self):
  for o in self.objects.itervalues():
   if o is None or o.oid == -1:
    continue
   if isinstance(o.owner, ObjRef):
    o.owner = self.objects[o.owner.obj_num]
   if isinstance(o.location, ObjRef):
    o.location = self.objects[o.location.obj_num]
   for v in o.verbs:
    v.owner = self.objects[v.owner.obj_num]
   for p in o.properties:
    p.owner = self.objects[p.owner.obj_num]
    if isinstance(p.value, ObjRef):
     resolved = self.objects.get(p.value.obj_num, None)
     logger.debug("Resolving %r to %r" % (p.value, resolved))
     p.value = resolved

 def create_object(self, stub):
  parent = stub.parent.obj_num
  if parent in self.stub_objects:
   self.create_object(self.stub_objects[parent])
  if parent not in self.objects:
   raise DatabaseError("Parent object not located for child stub %r" % stub)
  new_object = new.classobj(stub.name, (self.objects[parent].__class__,), {})(oid=stub.oid, name=stub.name, owner=stub.owner, location=stub.location, flags=stub.flags, properties=stub.properties, verbs=stub.verbs, database=self)
  self.objects[stub.oid] = new_object
  del self.stub_objects[stub.oid]

 def is_valid(self, obj):
  return obj in self.objects.itervalues() and obj is not None
