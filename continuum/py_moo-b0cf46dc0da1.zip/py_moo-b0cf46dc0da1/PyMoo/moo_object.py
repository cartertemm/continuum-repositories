class MooObjectStub(object):

 def __init__(self, oid, name="", flags=0, owner=None, parent=None, location=None, contents=None, children=None, properties=None, verbs=None):
  self.oid = oid
  self.name = name
  self.parent = parent
  self.owner = owner
  self.location = location
  self.flags = flags
  if contents is None:
   contents = []
  self.contents = contents
  if children is None:
   children = []
  self.children = children
  if properties is None:
   properties = []
  if verbs is None:
   verbs = []
  self.properties = properties
  self.verbs = verbs

 def flags2str(self):
  """Return this object's flags as a string, e.g. 'r programmer player'"""  
  flags = ''
  objflags = self.flags
  if objflags >= 128:
   objflags -= 128
   flags += 'f '
  if objflags >= 64:
   objflags -= 64
   # obsolete
  if objflags >= 32:
   objflags -= 32
   flags += 'w '
  if objflags >= 16:
   objflags -= 16
   flags += 'r '
  if objflags >= 8:
   objflags -= 8
   # obsolete
  if objflags >= 4:
   objflags -= 4
   flags += 'wizard '
  if objflags >= 2:
   objflags -= 2
   flags += 'programmer '
  if objflags >= 1:
   objflags -= 1
   flags += 'player '
  if objflags != 0:
   # A remainder means unknown extensions have been used.
   flags = '???'
  return flags.rstrip()

 def decodePropFlags(propperms):
  """Return a property's flags as a string, e.g. 'r c'"""
  propflags = ''
  if propperms >= 4:
   propperms -= 4
   propflags += 'c '
  if propperms >= 2:
   propperms -= 2
   propflags += 'w '
  if propperms >= 1:
   propperms -= 1
   propflags += 'r '
  if propperms != 0:
   # A remainder means unknown extensions have been used.
   propflags = '???'
  return propflags.rstrip()

 def decodeVerbFlagsDobjPrepIobj(self, verbperms, verbprep):
  """Return a verb's flags, direct object, proposition and indirect object.
  e.g. ('r x', 'none', 'for/about' 'this')"""
  verbflags = ''
  verbdobj = 'none'
  verbiobj = 'none'
  if verbperms >= 1024:
   verbperms -= 1024
   verbflags += 'o ' # non-standard extension
  if verbperms >= 512:
   verbperms -= 512 # unused
  if verbperms >= 256:
   verbperms -= 256 # unused
  if verbperms >= 128:
   verbperms -= 128
   verbiobj = 'this'
  if verbperms >= 64:
   verbperms -= 64
   verbiobj = 'any'
  if verbperms >= 32:
   verbperms -= 32
   verbdobj = 'this'
  if verbperms >= 16:
   verbperms -= 16
   verbdobj = 'any'
  if verbperms >= 8:
   verbperms -= 8
   verbflags += 'd '
  if verbperms >= 4:
   verbperms -= 4
   verbflags += 'x '
  if verbperms >= 2:
   verbperms -= 2
   verbflags += 'w '
  if verbperms >= 1:
   verbperms -= 1
   verbflags += 'r '
  return (verbflags.rstrip(), verbdobj, Prepositions[verbprep+2], verbiobj)


class MooObject(object):

 def __init__(self, oid, name=None, owner=None, location=None, properties=None, verbs=None, flags=None, database=None):
  self.oid = oid
  self.name = name
  self.owner = owner
  self.flags = flags
  self.location = location
  if properties is None:
   properties = []
  self.properties = properties
  if verbs is None:
   verbs = []
  self.verbs = verbs
  self.database = database


 def __repr__(self):
  return '#%s' % self.oid

 __unicode__ = __str__ = __repr__

 def get_verb_by_name(self, verb_name):
  return [v for v in self.verbs if v.name == verb_name][0]

 def get_property_by_name(self, prop_name):
  return [p for p in self.properties if p.name == prop_name][0]

 def get_children(self):
  return self.database.get_children_for(self)


class ObjRef(object):

 def __init__(self, obj_num=None):
  self.obj_num = obj_num
