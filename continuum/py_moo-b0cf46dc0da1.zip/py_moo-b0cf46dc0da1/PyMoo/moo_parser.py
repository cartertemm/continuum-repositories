from logging import getLogger
logger = getLogger('parser')
from collections import deque

from moo_types import errors, prepositions, INT, OBJ, STR, ERR, CLEAR, LIST, FLOAT, WAIF
from moo_object import MooObjectStub, ObjRef
from moo_database import MooDatabase
from property import Property
from verb import Verb
from waif import Waif

class ParseError(Exception):
 
 def __init__(self, line_number=None, *args, **kwargs):
  super(ParseError, self).__init__(*args, **kwargs)
  self.line_number = line_number

class MooParser(object):
 VERB_SEPARATOR = ':'
 VERB_TERMINATOR = '.'

 def __init__(self, database_path):
  self.database_path = database_path
  self.database = open(database_path, 'r')
  self.line = 0
  #logger.info("Opened database %s" % self.database_path)
  self.object_registry = {}

 def read_line(self):
  """Read a line from the database file"""
  line = self.database.readline().rstrip("\r\n")
  self.line += 1
  return line

 def read_integer(self):
  """Read an integer from the database file."""
  return int(self.read_line())

 def read_objnum(self):
  return ObjRef(self.read_integer())

 def read_error(self):
  return errors[self.read_integer()]

 def read_list(self):
  new_list = []
  length = self.read_integer()
  ##logger.debug("Attempting to read in list of length %d" % length)
  for i in xrange(length):
   new_value = self.read_value()
   new_list.append(new_value)
  return new_list

 def read_float(self):
  return float(self.read_line())

 def read_verb_metadata(self):
  verb_name = self.read_line()
  verb_owner = self.read_objnum()
  verb_permissions = self.read_integer()
  verb_prepositions = self.read_integer()
  #logger.debug("Read in verb %r" % verb_name)
  return Verb(verb_name, verb_owner, verb_permissions, verb_prepositions)

 def read_properties(self):
  properties = []
  property_names = []
  property_names_length = self.read_integer()
  #logger.debug("%d property names" % property_names_length)
  for p in xrange(property_names_length):
   property_names.append(self.read_line())
  propdefs_length = self.read_integer()
  #logger.debug("Reading in %d property definitions." % propdefs_length)
  for v in xrange(propdefs_length):
   property_name = None
   if property_names:
    property_name = property_names.pop(0)
   #logger.debug("Reading property number %d: %r" % (v, property_name))
   property_value = self.read_value()
   property_owner = self.read_objnum()
   property_permissions = self.read_integer()
   new_property = Property(name=property_name, value=property_value, owner=property_owner, permissions=property_permissions)
   properties.append(new_property)
  return properties

 def read_verb(self):
  """Read all the lines associated with a verb"""
  verb_location = self.read_line()
  if self.VERB_SEPARATOR not in verb_location:
   raise ParseError("Verb location not found.")
  colon = verb_location.index(self.VERB_SEPARATOR)
  object_number = int(verb_location[1:colon])
  verb_number = int(verb_location[colon+1:])
  code = []
  last_line = self.read_line()
  while last_line != self.VERB_TERMINATOR:
   code.append(last_line)
   last_line = self.read_line()
  self.object_registry[object_number].verbs[verb_number].code = code

 def read_object(self):
  obj_number = self.read_line()
  if '#' not in obj_number:
   raise ParseError("Object number not found")
  if obj_number.find('recycled') != -1:
   return
  #logger.debug("Reading object %s" % obj_number)
  obj_number = int(obj_number[1:])
  name = self.read_line()
  self.read_line() #stupid
  flags = self.read_integer()
  owner = self.read_objnum()
  location = self.read_objnum()
  first_content = self.read_integer()
  neighbor = self.read_integer()
  parent = self.read_objnum()
  first_child = self.read_integer()
  sibling = self.read_integer()
  num_verbs = self.read_integer()
  verb_metadata = []
  for v in xrange(num_verbs):
   metadata = self.read_verb_metadata()
   verb_metadata.append(metadata)
  properties = self.read_properties()
  new_obj = MooObjectStub(obj_number, name=name, flags=flags, owner=owner, location=location, parent=parent, verbs=verb_metadata, properties=properties)
  return (obj_number, new_obj)

 def read_waif(self):
  ref, index = self.read_line().split(' ')
  if ref == 'r':
   self.read_line()
   return
  waif_properties = []
  waif_class = self.read_objnum()
  waif_owner = self.read_objnum()
  propdefs_length = self.read_integer() + 1
  for p in xrange(propdefs_length):
   try:
    cur = self.read_integer()
   except ValueError:
    return
   if cur == -1:
    break
   val = self.read_value()
   waif_properties.append(val)
   #logger.debug("Waif properties: %r" % waif_properties)
  self.read_line()
  waif = Waif(waif_class=waif_class, owner=waif_owner, properties=waif_properties)
  #logger.debug("Created WAIF class %r" % waif.waif_class)
  return waif

 def read_value(self):
  type_readers = {
   INT: self.read_line,
   OBJ: self.read_objnum,
   STR: self.read_line,
   ERR: self.read_error,
   LIST: self.read_list,
   CLEAR: lambda: None,
   FLOAT: self.read_float,
   WAIF: self.read_waif,
  } 
  value_type = self.read_integer()
  value =  type_readers[value_type]()
  #logger.debug("Read in value %r" % value)
  return value

 def parse_database(self):
  version_string = self.read_line()
  total_objects = self.read_integer()
  total_verbs = self.read_integer()
  self.read_line()
  total_players = self.read_integer()
  players = []
  for i in xrange(total_players):
   players.append(self.read_line())
  for p in xrange(total_objects):
   new = self.read_object()
   self.object_registry[new[0]] = new[1]
  for v in xrange(total_verbs):
   self.read_verb()
  return MooDatabase(version_string=version_string, total_objects=total_objects, total_verbs=total_verbs, total_players=total_players, players=players, objects=self.object_registry)
