
#Variable types
INT = 0
OBJ = 1
STR = 2
ERR = 3
LIST = 4
CLEAR = 5
FLOAT = 9
WAIF = 10

# -2 is 'any', -1 is 'none', then the list is as defined in db_verbs.c
prepositions = 'any', 'none', 'with/using', 'at/to', 'in front of', 'in/inside/into', 'on top of/on/onto/upon', 'out of/from inside/from', 'over', 'through', 'under/underneath/beneath', 'behind', 'beside', 'for/about', 'is', 'as', 'off/off of'


#Exception classes

class MooError(Exception):
 def __init__(self, name=None, *args, **kwargs):
  self.name=name

class PermissionError(MooError): pass

class InvalidIndirectionError(MooError): pass

class RecursiveMoveError(MooError): pass

class VerbCallsError(MooError): pass

class ArgumentsError(MooError): pass

class MoveError(MooError): pass

class InvalidArgumentsError(MooError): pass

class QuotaError(MooError): pass

errors = dict(
 enumerate(
  [
   ['E_NONE', Exception],
   ['E_TYPE', TypeError],
   ['E_DIV', ZeroDivisionError],
   ['E_PERM', PermissionError],
   ['E_PROPNF', NameError],
   ['E_VERBNF', NameError],
   ['E_VARNF', NameError],
   ['E_INVIND', InvalidIndirectionError],
   ['E_RECMOVE', RecursiveMoveError],
   ['E_MAXREC', VerbCallsError],
   ['E_RANGE', IndexError],
   ['E_ARGS', ArgumentsError],
   ['E_NACC', MoveError],
   ['E_INVARG', InvalidArgumentsError],
   ['E_QUOTA', QuotaError],
   ['E_FLOAT', FloatingPointError]
  ]
 )
)



class MooList(list):

 def __getitem__(self, index):
  return super(MooList, self).__getitem__(index - 1)

 def __repr__(self):
  resp = super(MooList, self).__repr__()
  resp = resp.replace('[', '{')
  resp = resp.replace(']', '}')
  return resp

