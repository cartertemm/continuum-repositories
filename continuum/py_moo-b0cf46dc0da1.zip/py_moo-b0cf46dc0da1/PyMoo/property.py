class Property(object):

 def __init__(self, name=None, value=None, owner=None, permissions=None):
  self.name = name
  self.value = value
  self.owner = owner
  self.permissions = permissions
