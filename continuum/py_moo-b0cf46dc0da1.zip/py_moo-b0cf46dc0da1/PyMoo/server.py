from logging import getLogger
logger = getLogger('server')

from gevent.server import StreamServer

class Server(object):

 def __init__(self, listen_address='0.0.0.0', port=7777):
  self.listen_address = listen_address
  self.port = port
  logger.info("Creating server and binding to address %s port %d" % (listen_address, port))
  self.server = StreamServer((self.listen_address, self.port), self.handle_connection)
  self.connections = []

 def start(self):
  self.server.start()
  logger.info("Started server.")
 
 def handle_connection(self, socket, address):
  new_connection = Connection(socket, address)
  self.connections.append(new_connection)
  logger.info("Connection accepted from %s port %d" % (address[0], address[1]))


class Connection(object):
 LINE_SEPARATOR = '\r\n'

 def __init__(self, socket, address):
  self.socket = socket
  self.address = address
  self.file_obj = socket.makefile()
  
 def write(self, data):
  self.file_obj.write(data)
  self.file_obj.flush()

 def read_line(self):
  return self.file_obj.readline().strip(self.LINE_SEPARATOR)

 def write_line(self, line):
  self.write('%s%s' % (line, self.LINE_SEPARATOR))
