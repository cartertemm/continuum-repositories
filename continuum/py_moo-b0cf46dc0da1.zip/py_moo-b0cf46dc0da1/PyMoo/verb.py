class Verb(object):

 def __init__(self, name=None, owner=None, permissions=None, prepositions=None, code=None):
  self.name = name
  self.owner = owner
  self.permissions = permissions
  self.prepositions = prepositions
  self.code = code

