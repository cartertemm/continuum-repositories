class Waif(object):

 def __init__(self, waif_class=None, owner=None, properties=None):
  self.waif_class = waif_class
  self.owner = owner
  self.properties = properties
