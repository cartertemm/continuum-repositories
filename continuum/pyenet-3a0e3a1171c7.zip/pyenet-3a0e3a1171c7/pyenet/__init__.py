from .enet import *
def find_datafiles():
 import os
 import platform
 from glob import glob
 import pyenet
 if platform.system() != 'Windows':
  return []
 path = os.path.join(pyenet.__path__[0], 'enet.dll')
 results = glob(path)
 dest_dir = 'pyenet'
 return [(dest_dir, results)]
