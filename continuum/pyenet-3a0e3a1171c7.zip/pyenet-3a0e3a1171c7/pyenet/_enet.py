import os
from ctypes import *
import platform
from ctypes.util import find_library
from platform_utils import paths
def load_library(libname):
 if paths.is_frozen():
  libfile = os.path.join(paths.embedded_data_path(), 'pyenet', libname)
 else:
  libfile = os.path.join(paths.module_path(), libname)
 return cdll[libfile]

if platform.system() == 'Windows':
#	lib = cdll['enet.dll']
	lib = load_library('enet.dll')
else:
	lib = cdll[find_library('enet')]
lib.enet_initialize()

enet_uint8 = c_uint8
enet_uint16 = c_int16
enet_uint32 = c_uint32
ENetSocket = c_int

ENET_PROTOCOL_MAXIMUM_PACKET_COMMANDS = 32
ENET_BUFFER_MAXIMUM = (1 + 2 * ENET_PROTOCOL_MAXIMUM_PACKET_COMMANDS)
ENET_PROTOCOL_MAXIMUM_MTU = 4096


class ENetAddress(Structure):
	_fields_ = (
		('host', enet_uint32),
		('port', enet_uint16),
	)

class ENetEvent(Structure):
	pass

class ENetPeer(Structure):
	pass

class ENetProtocolCommandHeader(Structure):
	_pack_ = 1
	_fields_ = (
		('command', enet_uint8),
		('channelID', enet_uint8),
		('reliableSequenceNumber', enet_uint16)
	)

class ENetProtocolAcknowledge(Structure):
	_pack_ = 1
	_fields_ = (
		('header', ENetProtocolCommandHeader),
		('receivedReliableSequenceNumber', enet_uint16),
		('receivedSentTime', enet_uint16),
	)

class ENetProtocolConnect(Structure):
	_pack_ = 1
	_fields_ = (
		('header', ENetProtocolCommandHeader),
		('outgoingPeerID', enet_uint16),
		('incomingSessionID', enet_uint8),
		('outgoingSessionID', enet_uint8),
		('mtu', enet_uint32),
		('windowSize', enet_uint32),
		('channelCount', enet_uint32),
		('incomingBandwidth', enet_uint32),
		('outgoingBandwidth', enet_uint32),
		('packetThrottleInterval', enet_uint32),
		('packetThrottleAcceleration', enet_uint32),
		('packetThrottleDeceleration', enet_uint32),
		('connectID', enet_uint32),
		('data', enet_uint32),
	)

class ENetProtocolVerifyConnect(Structure):
	_pack_ = 1
	_fields_ = (
		('header', ENetProtocolCommandHeader),
		('outgoingPeerID', enet_uint16),
		('incomingSessionID', enet_uint8),
		('outgoingSessionID', enet_uint8),
		('mtu', enet_uint32),
		('windowSize', enet_uint32),
		('channelCount', enet_uint32),
		('incomingBandwidth', enet_uint32),
		('outgoingBandwidth', enet_uint32),
		('packetThrottleInterval', enet_uint32),
		('packetThrottleAcceleration', enet_uint32),
		('packetThrottleDeceleration', enet_uint32),
		('connectID', enet_uint32),
	)

class ENetProtocolBandwidthLimit(Structure):
	_pack_ = 1
	_fields_ = (
		('header', ENetProtocolCommandHeader),
		('incomingBandwidth', enet_uint32),
		('outgoingBandwidth', enet_uint32),
	)

class ENetProtocolThrottleConfigure(Structure):
	_pack_ = 1
	_fields_ = (
		('header', ENetProtocolCommandHeader),
		('packetThrottleInterval', enet_uint32),
		('packetThrottleAcceleration', enet_uint32),
		('packetThrottleDeceleration', enet_uint32),
	)

class ENetProtocolDisconnect(Structure):
	_pack_ = 1
	_fields_ = (
		('header', ENetProtocolCommandHeader),
		('data', enet_uint32),
	)

class ENetProtocolPing(Structure):
	_pack_ = 1
	_fields_ = (
		('header', ENetProtocolCommandHeader),
	)

class ENetProtocolSendReliable(Structure):
	_pack_ = 1
	_fields_ = (
		('header', ENetProtocolCommandHeader),
		('dataLength', enet_uint16),
	)

class ENetProtocolSendUnreliable(Structure):
	_pack_ = 1
	_fields_ = (
		('header', ENetProtocolCommandHeader),
		('unreliableSequenceNumber', enet_uint16),
		('dataLength', enet_uint16),
	)

class ENetProtocolSendUnsequenced(Structure):
	_pack_ = 1
	_fields_ = (
		('header', ENetProtocolCommandHeader),
		('unsequencedGroup', enet_uint16),
		('dataLength', enet_uint16),
	)

class ENetProtocolSendFragment(Structure):
	_pack_ = 1
	_fields_ = (
		('header', ENetProtocolCommandHeader),
		('startSequenceNumber', enet_uint16),
		('dataLength', enet_uint16),
		('fragmentCount', enet_uint32),
		('fragmentNumber', enet_uint32),
		('totalLength', enet_uint32),
		('fragmentOffset', enet_uint32),
	)

class ENetPacket(Structure):
	pass
ENetPacketFreeCallback = CFUNCTYPE(None, POINTER(ENetPacket))
ENetPacket._fields_ = (
	('referenceCount', c_int),
	('flags', enet_uint32),
	('data', POINTER(enet_uint8)),
	('dataLength', c_int),
	('freeCallback', ENetPacketFreeCallback),
	('userData', c_void_p),
	)

class ENetProtocolHeader(Structure):
	_pack_ = 1
	_fields_ = (
		('peerID', enet_uint16),
		('sentTime', enet_uint16),
	)

class ENetProtocol(Union):
	_pack_ = 1
	_fields_ = (
		('header', ENetProtocolCommandHeader),
		('acknowledge', ENetProtocolAcknowledge),
		('connect', ENetProtocolConnect),
		('verifyConnect', ENetProtocolVerifyConnect),
		('disconnect', ENetProtocolDisconnect),
		('ping', ENetProtocolPing),
		('sendReliable', ENetProtocolSendReliable),
		('sendUnreliable', ENetProtocolSendUnreliable),
		('sendUnsequenced', ENetProtocolSendUnsequenced),
		('sendFragment', ENetProtocolSendFragment),
		('bandwidthLimit', ENetProtocolBandwidthLimit),
		('throttleConfigure', ENetProtocolThrottleConfigure),
	)

class ENetHost(Structure):
	pass
class ENetListNode(Structure):
	pass
ENetListNode._fields_ = (
	('previous', POINTER(ENetListNode)),
	('next', POINTER(ENetListNode))
)

class ENetList(Structure):
	_fields_ = (
		('sentinel', ENetListNode),
	)

ENET_PEER_RELIABLE_WINDOWS = 16
ENET_PEER_UNSEQUENCED_WINDOW_SIZE = 1024

class ENetChannel(Structure):
	_fields_ = (
		('outgoingReliableSequenceNumber', enet_uint16),
		('outgoingUnreliableSequenceNumber', enet_uint16),
		('usedReliableWindows', enet_uint16),
		('reliableWindows', enet_uint16 * ENET_PEER_RELIABLE_WINDOWS),
		('incomingReliableSequenceNumber', enet_uint16),
		('incomingUnreliableSequenceNumber', enet_uint16),
		('incomingReliableCommands', ENetList),
		('incomingUnreliableCommands', ENetList),
	)
if platform.system() == 'Windows':
	class ENetBuffer(Structure):
		_fields_ = (
			('dataLength', c_int),
			('data', c_void_p),
		)
else:
	class ENetBuffer(Structure):
		_fields_ = (
			('data', c_void_p),
			('dataLength', c_int)
		)
ENetEvent._fields_ = (
	('type', c_int),
	('peer', POINTER(ENetPeer)),
	('channelID', enet_uint8),
	('data', enet_uint32),
	('packet', POINTER(ENetPacket)),
)

class ENetCompressor(Structure):
	_fields_ = (
		('context', c_void_p),
		('compress', CFUNCTYPE(c_int, c_void_p, POINTER(ENetBuffer), c_int, c_int, POINTER(enet_uint8), c_int)),
	('decompress', CFUNCTYPE(c_int, c_void_p, POINTER(enet_uint8), c_int, POINTER(enet_uint8), c_int)),
	('destroy', CFUNCTYPE(None, c_void_p)),
)

ENetChecksumCallback = CFUNCTYPE(enet_uint32, POINTER(ENetBuffer), c_int)
ENetInterceptCallback = CFUNCTYPE(c_int, POINTER(ENetHost), POINTER(ENetEvent))

ENetHost._fields_ = (
	('socket', ENetSocket),
	('address', ENetAddress),
	('incomingBandwidth', enet_uint32),
	('outgoingBandwidth', enet_uint32),
	('bandwidthThrottleEpoch', enet_uint32),
	('mtu', enet_uint32),
	('randomSeed', enet_uint32),
	('recalculateBandwidthLimits', c_int),
	('peers', POINTER(ENetPeer)),
	('peerCount', c_int),
	('channelLimit', c_int),
	('serviceTime', enet_uint32),
	('dispatchQueue', ENetList),
	('continueSending', c_int),
	('packetSize', c_int),
	('headerFlags', enet_uint16),
	('commands', ENetProtocol*ENET_PROTOCOL_MAXIMUM_PACKET_COMMANDS),
	('commandCount', c_int),
	('buffers', ENetBuffer * ENET_BUFFER_MAXIMUM),
	('bufferCount', c_int),
	('checksum', ENetChecksumCallback),
	('compressor', ENetCompressor),
	('packetData', enet_uint8 * 2 * ENET_PROTOCOL_MAXIMUM_MTU),
	('receivedAddress', ENetAddress),
	('receivedData', POINTER(enet_uint8)),
	('receivedDataLength', c_int),
	('totalSentData', enet_uint32),
	('totalSentPackets', enet_uint32),
	('totalReceivedData', enet_uint32),
	('totalReceivedPackets', enet_uint32),
	('intercept', ENetInterceptCallback),
	('connectedPeers', c_int),
	('bandwidthLimitedPeers', c_int),
	('duplicate_peers', c_int),
	('maximumPacketSize', c_int),
	('maximumWaitingData', c_int),
	)

ENetPeer._fields_ = (
	('dispatchList', ENetListNode),
	('host', POINTER(ENetHost)),
	('outgoingPeerID', enet_uint16),
	('incomingPeerID', enet_uint16),
	('connectID', enet_uint32),
	('outgoingSessionID', enet_uint8),
	('incomingSessionID', enet_uint8),
	('address', ENetAddress),
	('data', c_void_p),
	('state', c_int), #ENetPeerState state;
	('channels', POINTER(ENetChannel)),
	('channelCount', c_int),
	('incomingBandwidth', enet_uint32),
	('outgoingBandwidth', enet_uint32),
	('incomingBandwidthThrottleEpoch', enet_uint32),
	('outgoingBandwidthThrottleEpoch', enet_uint32),
	('incomingDataTotal', enet_uint32),
	('outgoingDataTotal', enet_uint32),
	('lastSendTime', enet_uint32),
	('lastReceiveTime', enet_uint32),
	('nextTimeout', enet_uint32),
	('earliestTimeout', enet_uint32),
	('packetLossEpoch', enet_uint32),
	('packetsSent', enet_uint32),
	('packetsLost', enet_uint32),
	('packetLoss', enet_uint32),
	('packetLossVariance', enet_uint32),
	('packetThrottle', enet_uint32),
	('packetThrottleLimit', enet_uint32),
	('packetThrottleCounter', enet_uint32),
	('packetThrottleEpoch', enet_uint32),
	('packetThrottleAcceleration', enet_uint32),
	('packetThrottleDeceleration', enet_uint32),
	('packetThrottleInterval', enet_uint32),
	('pingInterval', enet_uint32),
	('timeoutLimit', enet_uint32),
	('timeoutMinimum', enet_uint32),
	('timeoutMaximum', enet_uint32),
	('lastRoundTripTime', enet_uint32),
	('lowestRoundTripTime', enet_uint32),
	('lastRoundTripTimeVariance', enet_uint32),
	('highestRoundTripTimeVariance', enet_uint32),
	('roundTripTime', enet_uint32),
	('roundTripTimeVariance', enet_uint32),
	('mtu', enet_uint32),
	('windowSize', enet_uint32),
	('reliableDataInTransit', enet_uint32),
	('outgoingReliableSequenceNumber', enet_uint16),
	('acknowledgements', ENetList),
	('sentReliableCommands', ENetList),
	('sentUnreliableCommands', ENetList),
	('outgoingReliableCommands', ENetList),
	('outgoingUnreliableCommands', ENetList),
	('dispatchedCommands', ENetList),
	('needsDispatch', c_int),
	('incomingUnsequencedGroup', enet_uint16),
	('outgoingUnsequencedGroup', enet_uint16),
	('unsequencedWindow', enet_uint32 * (ENET_PEER_UNSEQUENCED_WINDOW_SIZE / 32)), 
	('eventData', enet_uint32),
	('totalWaitingData', c_int),
)

lib.enet_address_set_host.argtypes = (POINTER(ENetAddress), c_char_p)
lib.enet_host_create.argtypes = (POINTER(ENetAddress), c_uint, c_uint, c_uint, c_uint)
lib.enet_host_create.restype = POINTER(ENetHost)
lib.enet_host_service.argtypes = (POINTER(ENetHost), POINTER(ENetEvent), enet_uint32)
lib.enet_host_connect.argtypes = (POINTER(ENetHost), POINTER(ENetAddress), c_int, enet_uint32)
lib.enet_host_connect.restype = POINTER(ENetPeer)
lib.enet_packet_create.argtypes = (c_char_p, c_int, enet_uint32)
lib.enet_packet_create.restype = POINTER(ENetPacket)
lib.enet_peer_send.argtypes = (POINTER(ENetPeer), enet_uint8, POINTER(ENetPacket))
lib.enet_host_flush.argtypes = (POINTER(ENetHost),)
lib.enet_packet_destroy.argtypes = (POINTER(ENetPacket),)
lib.enet_peer_disconnect.argtypes = (POINTER(ENetPeer), enet_uint32)
