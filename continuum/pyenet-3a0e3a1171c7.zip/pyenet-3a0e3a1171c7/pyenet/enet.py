from _enet import *
import socket
import struct
import ctypes
EVENT_TYPE_NONE = 0
EVENT_TYPE_CONNECT = 1
EVENT_TYPE_DISCONNECT = 2
EVENT_TYPE_RECEIVE = 3
PACKET_FLAG_RELIABLE = 1 << 0

class Host(object):
	def __init__(self, address, peer_count, channel_limit, incoming_bandwidth=0, outgoing_bandwidth=0):
		if address is not None:
			address = address._address
		self._host = lib.enet_host_create(address, peer_count, channel_limit, incoming_bandwidth, outgoing_bandwidth)

	def service(self, timeout):
		event = ENetEvent()
		lib.enet_host_service(self._host, event, timeout)
		return Event(event)

	def connect(self, address, channel_count, data=0):
		peer = lib.enet_host_connect(self._host, address._address, channel_count, data)
		return Peer(peer.contents)

	def flush(self):
		lib.enet_host_flush(self._host)

class Address(object):
	def __init__(self, host, port):
		self._address = ENetAddress()
		if host:
			lib.enet_address_set_host(self._address, host)
		else:
			self._address.host = 0
		self._address.port = port
		self.host = host
		self.port = port

	def __eq__(self, other):
		return self.host == other.host and self.port == other.port

class Packet(object):
	def __init__(self, data=None, flags=0):
		if not data:
			return #We're setting this from something else
		self._packet = lib.enet_packet_create(data, len(data), flags)

	@property
	def data(self):
		return string_at(self._packet.contents.data, self._packet.contents.dataLength)

	def destroy(self):
		lib.enet_packet_destroy(self._packet)

class Peer(object):
	def __init__(self, peer):
		self._peer = peer

	def send(self, channel, packet):
		return lib.enet_peer_send(self._peer, channel, packet._packet)

	@property
	def address(self):
		addr = self._peer.address
		host = socket.inet_ntoa(struct.pack('=L', addr.host))
		return Address(host, addr.port)

	def __eq__(self, other):
		return self.address == other.address

	def __hash__(self):
		return ctypes.addressof(self._peer)

	def disconnect(self, data=0):
		return lib.enet_peer_disconnect(self._peer, data)

class Event(object):
	def __init__(self, event):
		self._event = event

	@property
	def peer(self):
		return Peer(self._event.peer.contents)

	@property
	def type(self):
		return self._event.type

	@property
	def packet(self):
		packet = Packet()
		packet._packet = self._event.packet
		return packet

	@property
	def channel_id(self):
		return self._event.channelID
