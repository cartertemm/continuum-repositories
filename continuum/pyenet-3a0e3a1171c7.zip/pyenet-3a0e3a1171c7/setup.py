from setuptools import setup, find_packages
from platform import system

_system = system()

install_requires = []

__doc__ = 'Wrapper around the enet library'

setup(
	name = 'pyenet',
	author = 'Tyler Spivey',
	author_email = 'tspivey@pcdesk.net',
	version='0.1',
	description = __doc__,
	package_dir = {'pyenet': 'pyenet'},
	packages = find_packages(),
	package_data = {"pyenet": ["enet.dll"]},
	zip_safe = False,
	classifiers = [
		'Development Status :: 4 - Beta',
		'Intended Audience :: Developers',
		'Operating System :: Microsoft :: Windows',
		'Programming Language :: Python',
		'License :: OSI Approved :: MIT License',
		'Topic :: Software Development :: Libraries'
],
	install_requires = install_requires,
)
