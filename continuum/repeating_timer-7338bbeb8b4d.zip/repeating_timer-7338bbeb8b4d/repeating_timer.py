import threading

class RepeatingTimer(threading.Thread):
 """Call a function after a specified number of seconds, it will then repeat again after the specified number of seconds
    Note: If the function provided takes time to execute, this time is NOT taken from the next wait period

 t = RepeatingTimer(30.0, f, *args, **kwargs)
 t.start()
 t.cancel() # stop the timer's actions
 """

 def __init__(self, interval, function, daemon=True, *args, **kwargs):
  threading.Thread.__init__(self)
  self.daemon = daemon
  self.interval = interval
  self.function = function
  self.args = args
  self.kwargs = kwargs
  self.finished = threading.Event()
  self.running = False


 def cancel(self):
  """Stop the timer if it hasn't finished yet"""
  self.finished.set()
 stop = cancel

 def run(self):
  self.running = True
  while not self.finished.is_set():
   self.finished.wait(self.interval)
   if self.finished.is_set():  #In case someone has canceled while waiting
    self.running = False
    return
   try:
    self.function(*self.args, **self.kwargs)
   except:
    pass
