
DISJOINT, SUBSET, INTERSECT_OR_SUPERSET = -1, 0, 1

class SegmentTree(object):

 def __init__(self, intervals):
  endpoints = calculate_endpoints(intervals)
  self.root = self.insert_endpoints(endpoints)
  self.insert_intervals(intervals)

 def insert_endpoints(self, endpoints):
  node = None
  if len(endpoints) == 2:
   node = Node(*endpoints)
   if endpoints[1] == float('inf'):
    node.left = Node(*endpoints)
    node.right = Node(endpoints[1], endpoints[1])
  else:
   node = Node(endpoints[0], endpoints[-1])
   #divide in half and insert in children
   center = len(endpoints) / 2
   node.left = self.insert_endpoints(endpoints[0:center+1])
   node.right = self.insert_endpoints(endpoints[center:])
  return node

 def search(self, query):
  return self.root.search(query)

 def insert_intervals(self, intervals):
  for interval in intervals:
   self.root.insert_interval(interval)

 def serialize(self):
  return self.root.serialize()


class Node(object):

 def __init__(self, start, end):
  self.left = None
  self.right = None
  self.segment = (start, end)
  self.intervals = []

 def insert_interval(self, interval):
  res = compare_intervals(self.segment, interval)
  if res == SUBSET:
   self.intervals.append(interval)
  elif res == INTERSECT_OR_SUPERSET:
   if self.left:
    self.left.insert_interval(interval)
   if self.right:
    self.right.insert_interval(interval)

 def search(self, point):
  res = [interval for interval in self.intervals if number_in_range(point, interval)]
  if self.left is not None and number_in_range(point, self.left.segment):
   res.extend(self.left.search(point))
  if self.right is not None and number_in_range(point, self.right.segment):
   res.extend(self.right.search(point))
  return res

 def serialize(self):
  res = {
   'segment': self.segment,
   'intervals': self.intervals,
  }
  if self.left is not None:
   res['left'] = self.left.serialize(),
  if self.right is not None:
   res['right'] = self.right.serialize()
  return res


def number_in_range(num, num_range):
 return num >= num_range[0] and num <= num_range[1]

def compare_intervals(interval1, interval2):
 if interval2[0] > interval1[1] or interval2[1] < interval1[0]:
  return DISJOINT
 elif interval2[0] <= interval1[0] and interval2[1] >= interval1[1]:
  return SUBSET
 return INTERSECT_OR_SUPERSET

def calculate_endpoints(intervals):
 endpoints = [float('-inf'), float('inf')]
 for item in intervals:
  endpoints.extend(list(item)[:2])
 return sorted(set(endpoints))
