from distutils.core import setup

__version__ = 0.1
__doc__ = """Basic segment tree implementation for fast stabbing queries."""
__author__ = "Christopher Toth"

setup(
 name = 'repeating_timer',
 version = str(__version__),
 author = __author__,
 author_email = 'q@q-continuum.net',
 description = __doc__,
 py_modules = ["segment_tree"],
 classifiers = [
  'Development Status :: 3 - Alpha',
  'Intended Audience :: Developers',
  'Programming Language :: Python',
  'License :: OSI Approved :: MIT License',
  'Topic :: Software Development :: Libraries',
 ],
)
