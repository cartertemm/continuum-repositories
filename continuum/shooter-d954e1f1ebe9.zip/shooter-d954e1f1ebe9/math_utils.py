from __future__ import division
import math

def percentage(what, percent):
	return (what / 100.0) * percent

def inverse_percentage(what, percent):
	return 100.0 / 100.0 / what * percent
