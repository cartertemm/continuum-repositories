#!/bin/sh
openssl genrsa -out key.out 2048
openssl rsa -in key.out -pubout >key.pub
