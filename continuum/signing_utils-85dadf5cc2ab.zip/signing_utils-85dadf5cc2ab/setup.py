from setuptools import setup

__version__ = 0.1
__doc__ = """Package for signing/verifying files with RSA keys"""
__author__ = u'Tyler Spivey'

setup(
 name = u'signing_utils',
 version = str(__version__),
 author = __author__,
 author_email = u'tspivey@pcdesk.net',
 description = __doc__,
 py_modules = ["signing_utils"],
  install_requires=["pycrypto"],
 classifiers = [
  'Development Status :: 3 - Alpha',
  'Intended Audience :: Developers',
  'Programming Language :: Python',
  'License :: OSI Approved :: MIT License',
  'Topic :: Software Development :: Libraries',
 ],
)
