import os
import Crypto.PublicKey.RSA as RSA
import Crypto.Hash.SHA as SHA

def digest_for(file):
 """Returns SHA digest for file, which is the name of an existing file."""
 digest = SHA.new()
 with open(file, 'rb') as fp:
  s = fp.read(8192)
  while s:
   digest.update(s)
   s = fp.read(8192)
 return digest.digest()

def sign(file, key):
 """Signs file with key. Key must be a pycrypto RSA key object,
 and file the name of an existing file."""
 digest = digest_for(file)
 return key.sign(digest, '')

def verify(file, key, signature):
 """Verifies that file was signed with key."""
 digest = digest_for(file)
 return key.verify(digest, signature)

def rsa_from_file(file):
 """Imports an RSA key, either public or private, from file."""
 with open(file, 'rb') as fp:
  return RSA.importKey(fp.read())
