from __future__ import absolute_import
from sound_lib.effects import tempo
