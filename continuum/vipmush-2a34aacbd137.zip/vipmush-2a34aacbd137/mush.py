import xmltodict
from pathlib import Path
from attr import attr, attrs, asdict, Factory
import copy
import datetime

DEFAULT_DOCUMENT = {
	'muclient': {
		'world': {},
		'triggers': {},
	}
}

def from_attributes(adict):
	res = {}
	for k, v in adict.items():
		if k.startswith('@'):
			k = k[1:]
		res[k] = v
	return res

def to_attributes(d):
	return {
		'@' + k: v
		for k, v in d.items()
	}

@attrs
class World:
	muclient_version = attr(repr=False)
	world_file_version = attr(repr=False)
	auto_say_override_prefix = attr(repr=False)
	auto_say_string = attr(repr=False)
	chat_name = attr(repr=False)
	command_stack_character = attr(repr=False)
	id = attr(repr=True)
	input_font_name = attr(repr=False)
	mapping_failure = attr(repr=False)
	name = attr(repr=True)
	new_activity_sound = attr(repr=False)
	output_font_name = attr(repr=False)
	script_editor = attr(repr=False)
	script_editor_argument = attr(repr=False)
	script_language = attr(repr=False)
	site = attr(repr=True)
	spam_message = attr(repr=False)
	speed_walk_prefix = attr(repr=False)
	terminal_identification = attr(repr=False)
	arrows_change_history = attr(repr=False)
	auto_pause = attr(repr=False)
	auto_resize_minimum_lines = attr(repr=False)
	auto_resize_maximum_lines = attr(repr=False)
	chat_foreground_colour = attr(repr=False)
	chat_background_colour = attr(repr=False)
	chat_port = attr(repr=False)
	confirm_before_replacing_typing = attr(repr=False)
	confirm_on_paste = attr(repr=False)
	confirm_on_send = attr(repr=False)
	default_trigger_sequence = attr(repr=False)
	default_alias_sequence = attr(repr=False)
	detect_pueblo = attr(repr=False)
	display_my_input = attr(repr=False)
	echo_hyperlink_in_output_window = attr(type=bool, repr=False)
	edit_script_with_notepad = attr(type=bool, repr=False)
	enable_aliases = attr(repr=False)
	enable_beeps = attr(repr=False)
	enable_scripts = attr(repr=False)
	enable_timers = attr(repr=False)
	enable_triggers = attr(repr=False)
	enable_trigger_sounds = attr(repr=False)
	history_lines = attr(repr=False)
	hyperlink_adds_to_command_history = attr(repr=False)
	hyperlink_colour = attr(repr=False)
	indent_paras = attr(repr=False)
	input_background_colour = attr(repr=False)
	input_font_height = attr(repr=False)
	input_font_weight = attr(repr=False)
	input_text_colour = attr(repr=False)
	keypad_enable = attr(repr=False)
	log_output = attr(repr=False)
	max_output_lines = attr(repr=False)
	mud_can_change_link_colour = attr(repr=False)
	mud_can_change_options = attr(repr=False)
	note_text_colour = attr(repr=False)
	output_font_height = attr(repr=False)
	output_font_weight = attr(repr=False)
	paste_delay_per_lines = attr(repr=False)
	pixel_offset = attr(repr=False)
	port = attr(repr=True, converter=int)
	proxy_port = attr(repr=False)
	send_file_delay_per_lines = attr(repr=False)
	send_mxp_afk_response = attr(repr=False)
	show_connect_disconnect = attr(repr=False)
	show_italic = attr(repr=False)
	show_underline = attr(repr=False)
	spam_line_count = attr(repr=False)
	tab_completion_lines = attr(repr=False)
	timestamp_input_text_colour = attr(repr=False)
	timestamp_notes_text_colour = attr(repr=False)
	timestamp_output_text_colour = attr(repr=False)
	timestamp_input_back_colour = attr(repr=False)
	timestamp_notes_back_colour = attr(repr=False)
	timestamp_output_back_colour = attr(repr=False)
	tool_tip_visible_time = attr(repr=False)
	tool_tip_start_time = attr(repr=False)
	underline_hyperlinks = attr(repr=False)
	unpause_on_send = attr(repr=False)
	use_custom_link_colour = attr(repr=False)
	use_default_input_font = attr(repr=False)
	use_default_output_font = attr(repr=False)
	warn_if_scripting_inactive = attr(repr=False)
	wrap = attr(repr=False)
	wrap_column = attr(repr=False)
	write_world_name_to_log = attr(repr=False)
	convert_ga_to_newline = attr(default=False, repr=False)
	date_saved = attr(default=None)
	line_information = attr(default=None, repr=False)
	on_mxp_set_variable = attr(default=None, repr=False)
	omit_date_from_save_files = attr(default=None, repr=False)
	script_errors_to_output_window = attr(type=bool, default=False, repr=False)
	script_filename = attr(default=None, repr=False)
	script_prefix = attr(default=None, repr=False)
	treeview_triggers = attr(default=False, repr=False)
	treeview_aliases = attr(default=False, repr=False)
	treeview_timers = attr(default=False, repr=False)
	use_mxp = attr(type=bool, default=False, repr=False)
	triggers = attr(type=list, default=Factory(list), repr=True)

	@classmethod
	def load(cls, fn):
		with open(fn, 'rb') as f:
			loaded = xmltodict.parse(f)
		world = cls(**from_bools(from_attributes(loaded['muclient']['world'])))
		world.triggers = cls.load_triggers(loaded)
		return world

	@classmethod
	def load_triggers(cls, loaded):
		triggers = []
		for trig in loaded['muclient']['triggers'].get('trigger', []):
			send = trig.pop('send', None)
			triggers.append(Trigger(send=send, **from_bools(from_attributes(trig))))
		return triggers

	def save(self, fn, update_save_date=True):
		update_save_date = update_save_date and not self.omit_date_from_save_files
		document = {}
		if Path(fn).exists():
			with open(fn, 'rb') as f:
				document = xmltodict.parse(f)
		else:
			document = copy.deepcopy(DEFAULT_DOCUMENT)
		document['muclient']['world'].update(self.serialize())
		document['muclient']['triggers']['trigger'] = [i.serialize() for i in self.triggers]
		with open(fn, 'wt') as f:
			xmltodict.unparse(document, f, pretty=True)

	def serialize(self):
		res = asdict(self)
		del res['triggers']
		return remove_nulls(to_attributes(to_bools(res)))

@attrs
class Trigger:
	match = attr(repr=True)
	enabled = attr(default=True)
	send = attr(default=None)
	group = attr(default='')
	omit_from_log = attr(default=False, repr=False)
	omit_from_output = attr(default=False, repr=False)
	regexp = attr(default=False)
	script = attr(default='', repr=False)
	send_to = attr(default=None, repr=False)
	sequence = attr(default=100)

	def serialize(self):
		res = asdict(self)
		send = res.pop('send', None)
		res = remove_nulls(to_bools(to_attributes(res)))
		if send:
			res['send'] = send
		return res

def from_bools(data):
	res = {}
	for k, v in data.items():
		if v == 'y':
			v = True
		elif v == 'n':
			v = False
		res[k] = v
	return res

def to_bools(data):
	res = {}
	for k, v in data.items():
		if v == True:
			v = 'y'
		elif v == False:
			v = 'n'
		res[k] = v
	return res

def remove_nulls(data):
	return {
		k: v
		for k, v in data.items()
		if v is not None
	}

if __name__ == '__main__':
	w = World.load('test.mcl')
	w.save('out.mcl')
