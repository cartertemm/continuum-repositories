#! python3
import io
import re
from attr import attr, attrs, asdict
from parse import Parser

"""\
Parse VIPMud set files
"""

token_types = {}

def register_token(token_type):
	token_types[token_type.__name__.lower()] = token_type
	return token_type

@attrs
class Token:
	token = attr(default="", repr=False)
	template = attr(default="", repr=False)
	multiline = attr(default=False, repr=False)
	startpos = attr(default=0)
	length = attr(default=0)

	@classmethod
	def read(cls, reader):
		startpos = reader.curpos
		parser = cls.create_parser()
		res = parser.search(reader.rest(), evaluate_result=True)
		args = res.named
		token = cls(startpos=startpos, token=cls.token, template=cls.template, multiline=cls.multiline, **args)
		read = len(token.to_original()) # hack
		token.length = read
		reader.curpos += read
		return token

	def to_original(self):
		template = re.sub(r':\w+', '', self.template)
		return template.format(**self.as_dict())

	def as_dict(self):
		return asdict(self)

	@classmethod
	def create_parser(cls):
		p = Parser(cls.template, cls.type_converters(), case_sensitive=False)
		if cls.multiline:
			p._re_flags = p._re_flags | re.M
		return p

	@classmethod
	def type_converters(cls):
		return dict(
			identifier = read_name,
		)

Token.multiline = False

@attrs
class NamedToken(Token):
	name = attr(default="")

@register_token
@attrs
class Command(NamedToken):
	token = '#'
	template = '#{name:identifier}'

@register_token
@attrs
class Variable(NamedToken):
	token = '@'
	template = "@{name:identifier}"

@register_token
@attrs
class Comment(Token):
	token = ';'
	text = attr(default="")
	template = ";{text}\n"
	multiline = True

@register_token
@attrs
class String(Token):
	token = ''
	template = "{{{text:string}}}"
	text = attr(default="")
	multiline = True

	@classmethod
	def type_converters(cls):
		return dict(
			string = read_string
		)

@register_token
@attrs
class OpenBlock(Token):
	token = ''
	template = '{{'

@register_token
@attrs
class CloseBlock(Token):
	token = '}'
	template = '}}'

@register_token
@attrs
class Word(Token):
	token = ''
	template = r"{text:identifier}"
	text = attr(default="")

def read_name(text):
	return str(text)
read_name.pattern = r'[A-Za-z0-9]+(;)?'

def read_string(text):
	return text
read_string.pattern = r'.*?'

@attrs
class SetFileReader:
	curpos = attr(default=0)
	buffer = attr(default="", repr=False)

	def read(self, fn):
		self.load_from_file(fn)
		return self.tokenize()

	def tokenize(self):
		token_type = self.next_token()
		while token_type and self.curpos < len(self.buffer) - 1:
			yield token_type.read(self)
			token_type = self.next_token()
			if token_type is None and self.curpos < len(self.buffer) - 1:
				raise ValueError("Don't know how to read token starting at {curpos}".format(curpos=self.curpos))

	def load_from_file(self, fn):
		with io.open(fn, 'rt') as f:
			self.buffer = f.read()

	def next_token(self):
		self.skip_whitespace()
		return self.current_token_type()

	def skip_whitespace(self):
		while self.current_char == ' ' or self.current_char == '\n':
			if self.curpos < len(self.buffer) - 1:
				self.curpos += 1
			else:
				break

	def current_token_type(self):
		for token_type in token_types.values():
			if token_type.token == self.current_char:
				if token_type is Comment:
					if self.curpos > 0 and self.buffer[self.curpos - 1] != '\n':
						self.curpos += 1
						continue
				return token_type
		if (self.current_char == '{'):
			next_command = self.next_index('#')
			next_terminator = self.next_index('}')
			if next_command < next_terminator:
				return OpenBlock
			else:
				return String
		return Word

	def next_index(self, match):
		try:
			return self.buffer.index(match, self.curpos)
		except ValueError:
			return -1

	@property
	def current_char(self):
		return self.buffer[self.curpos]

	def lineno(self, pos=None):
		if pos is None:
			pos = self.curpos
		text = self.buffer[:pos]
		lines = text.split('\n')
		return len(lines) + 1, len(lines[-1])

	def rest(self):
		return self.buffer[self.curpos:]

if __name__ == '__main__':
	reader = SetFileReader()
	reader.load_from_file('yugioh.set')
	for t in reader.tokenize():
		print(t)
