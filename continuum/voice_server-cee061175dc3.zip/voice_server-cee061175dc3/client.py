
import sys
import sound_lib.input
import sound_lib.recording
import sound_lib.output
import sound_lib.stream
from sound_lib.external.pybass import BASS_RECORD_PAUSE, MAKELONG, BASS_StreamPutData
import Queue
from ctypes import string_at
import enet
import json
import threading
import logger_setup
logger_setup.setup_logging(error_log='out.log')
import opus
import struct
import libaudioverse
import datetime
import getpass
import audioop
import time
import click


class BaseClient(object):
	ENET_MESSAGE_CHANNEL = 0
	ENET_VOICE_CHANNEL = 1
	NUM_CHANNELS = 2

	def __init__(self, nickname=""):
		self.packet_queue = Queue.Queue()
		self.users = {}
		self.host = enet.Host(None, 2, 0, 0, 0)
		self.input = sound_lib.input.Input()
		self.output = sound_lib.output.Output()
		self.recording = None
		self.connection = None
		self.user_id = None
		self.channel = None
		self.sim = libaudioverse.Simulation(device_index = -1)
		self.mixer = libaudioverse.MixerObject(self.sim, max_parents = 1, inputs_per_parent = 2)
		self.attenuator = libaudioverse.AttenuatorObject(self.sim, 2)
		self.attenuator.inputs[0] = self.mixer, 0
		self.attenuator.inputs[1] = self.mixer, 1
		self.sim.output_object = self.attenuator
		self.nickname = nickname
		self.running = False
		self.stop_after_disconnect = False
		self.muted = False

	def connect(self, address, port=1234):
		self.connection = self.host.connect(enet.Address(address, port), self.NUM_CHANNELS)

	def run(self):
		self.running = True
		while self.running:
			event = self.host.service(10)
			if event.type == enet.EVENT_TYPE_CONNECT:
				self.on_connect(self.connection)
			elif event.type == enet.EVENT_TYPE_DISCONNECT:
				self.on_disconnect(event.peer)
			elif event.type == enet.EVENT_TYPE_RECEIVE:
				if event.channel_id == self.ENET_MESSAGE_CHANNEL:
					self.on_server_message(event)
				else:
					self.on_audio_packet(event)
				event.packet.destroy()
			self.send_queued_packets(self.connection)
			self.tick()

	def tick(self):
		"""Function that runs after each host.service call."""
		pass

	def disconnect(self):
		self.connection.disconnect()
		self.connection = None


	def login(self, nickname):
		self.send_server_message('login', nickname=nickname)

	def send_server_message(self, type, **data):
		message = {'type': type}
		message.update(data)
		message = json.dumps(message)
		packet = enet.Packet(message, enet.PACKET_FLAG_RELIABLE)
		self.connection.send(self.ENET_MESSAGE_CHANNEL, packet)

	def on_connect(self, peer):
		pass

	def on_disconnect(self, event):
		print "disconnected from server, waiting for send_audio to die"
		if self.channel is not None:
			self.channel.destroy()
		self.channel = None
		if self.stop_after_disconnect:
			self.stop_after_disconnect = False
			self.running = False
			return
		if self.connection is not None:
			self.reconnect()

	def reconnect(self):
		self.connection = self.host.connect(self.connection.address, self.NUM_CHANNELS)

	def send_queued_packets(self, peer):
		while True:
			try:
				item = self.packet_queue.get_nowait()
			except Queue.Empty:
				return
			peer.send(self.ENET_VOICE_CHANNEL, enet.Packet(item))

	def on_server_message(self, event):
		data = event.packet.data
		data = json.loads(data)
		if 'type' not in data:
			print "Missing type: %s" % data
			return
		fn = getattr(self, "msg_%s" % (data['type'],), None)
		if not fn:
			print "function msg_%s not found" % data['type']
			return
		fn(data)

	def msg_connected(self, message):
		self.user_id = message['user_id']

	def msg_join(self, message):
		"""Sent when someone else joins a channel."""
		self.channel.join(message['user'])

	def msg_joined(self, message):
		"""Sent when you join a channel."""
		channel = message['channel']
		self.channel = Channel(self, name=channel['name'], frequency=channel['frequency'], channels=channel['channels'], type=channel['type'])
		for member in channel['members']:
			self.channel.join(member)

	def msg_chat(self, data):
		print "<%s> %s" % (data['sender_nick'], data['message'])

	def msg_history(self, data):
		for item in data['history']:
			date = datetime.datetime.fromtimestamp(item['time']).strftime('%H:%M')
			print "{date} <{user}> {message}".format(
				date=date, user=item['sender_nick'], message=item['message'])

	def on_audio_packet(self, event):
		data = event.packet.data
		user_id = struct.unpack('l', data[:4])[0]
		data = data[4:]
		if self.channel is not None:
			self.channel.on_audio_packet(user_id, data)

	def msg_part(self, data):
		self.channel.part(data['user'])
		if data['user']['id'] == self.user_id:
			self.channel.destroy()
			self.channel = None

class Channel(object):
	RMS_TIMEOUT = 2.0

	def __init__(self, client, name=None, frequency=48000, channels=1, type='normal'):
		self.client = client
		self.audio_queue = Queue.Queue()
		self.encoder = opus.Encoder(application=opus.OPUS_APPLICATION_VOIP, fs=frequency, channels=channels)
		self.frequency = frequency
		self.name = name
		self.channels = channels
		self.type = type
		self.recording = sound_lib.recording.Recording(frequency=frequency, channels=channels, proc=self.process_audio)
		self.recording.play()
		self.users = {}
		self.send_audio_thread = None
		self.send_audio_thread = threading.Thread(target=self.send_audio)
		self.send_audio_thread.daemon = True
		self.send_audio_thread.start()
		self.first_rms_time = 0
		self.rms_blocks = []
		self.rms_threshold = 1000
		self.sending = False
		self.frame_size = int(self.frequency*0.04) #Samples
		self.remaining_audio = ""
		self.print_rms = False

	def reset_rms(self):
		self.first_rms_time = time.time()
		self.rms_blocks = []

	def process_audio(self, handle, buffer, length, user):
		if self.remaining_audio:
			data = self.remaining_audio+string_at(buffer, length)
			length += len(self.remaining_audio)
			self.remaining_audio = ""
		else:
			data = string_at(buffer, length)
		#One sample across all channels
		sample_size = 2*self.channels
		for i in range(length/sample_size/self.frame_size):
			start = i*self.frame_size*sample_size
			end = start+(self.frame_size*sample_size)
			self.audio_queue.put(data[start:end])
		remaining = (length/sample_size) % self.frame_size
		if remaining:
			self.remaining_audio = data[-(remaining*sample_size):]
		return 1

	def on_audio_packet(self, user_id, data):
		if user_id not in self.users:
			return
		user = self.users[user_id]
		user.decode(data)

	def send_audio(self):
		"""Thread function to read audio from the recording stream, and enqueue it for later sending to the server."""
		while True:
			item = self.audio_queue.get()
			if item is None:
				break
			if self.should_send(item):
				encoded = self.encoder.encode(item, self.frame_size)
				self.client.packet_queue.put(encoded)

	def should_send(self, item):
		if self.client.muted or (len(self.users) == 1 and self.type != 'echo'):
			return False
		if self.rms_threshold == 0:
			return True
		rms = audioop.rms(item, 2)
		#If we aren't sending, and rms goes above threshold, send.
		if not self.sending and rms > self.rms_threshold:
			self.reset_rms()
			self.sending = True
			return True
		#Don't send if we hear silence
		elif not self.sending and rms < self.rms_threshold:
			return False
		duration = time.time() - self.first_rms_time
		#We haven't got all the data we need to check yet,
		#But we're sending. Keep sending
		if duration <= self.RMS_TIMEOUT:
			return True
		self.rms_blocks.append(rms)
		if duration > self.RMS_TIMEOUT:
			average = sum(self.rms_blocks)/len(self.rms_blocks)
			if self.print_rms:
				print "average rms: %d" % average
			if average < self.rms_threshold:
				self.reset_rms()
				self.sending = False
				return False
			elif average >= self.rms_threshold:
				self.reset_rms()
				return True

	def part(self, user):
		if user['id'] in self.users:
			self.users[user['id']].destroy()
			del self.users[user['id']]

	def join(self, user):
		self.users[user['id']] = User(self, user)

	def destroy(self):
		self.recording.stop()
		self.audio_queue.put(None)
		self.send_audio_thread.join()
		self.send_audio_thread = None

class User(object):

	def __init__(self, channel, user):
		self.channel = channel
		self.id = user['id']
		self.nickname = user['nickname']
		self.decoder = opus.Decoder(channels=self.channel.channels, fs=self.channel.frequency)
		self.mixer = channel.client.mixer
		self.stream = libaudioverse.PushObject(channel.client.sim, self.channel.frequency, self.channel.channels)
		if debug_mode:
			self.stream.out_callback = self.out_callback
		self.input = None
		self.add_to_mixer()
		self.last_packet_time = 0

	def out_callback(self, obj):
		print "in out callback"

	def decode(self, audio):
		time_since_last_packet = time.time()-self.last_packet_time
		if time_since_last_packet > 0.2:
			zeros = [0.0]*1920*2
			self.stream.feed(len(zeros), zeros)
		decoded = self.decoder.decode(audio)
		length = len(decoded)
		lst = struct.unpack(str(int(length/2)) + "h", decoded)
		lst = [i/32768.0 for i in lst]
		self.stream.feed(len(lst), lst)
		self.last_packet_time = time.time()

	def add_to_mixer(self):
		free = -1
		for i, input in enumerate(self.mixer.inputs):
			if input is None:
				free = i
				break
		if free == -1:
			self.mixer.max_parents += 1
			free = self.mixer.max_parents * self.mixer.inputs_per_parent - self.mixer.inputs_per_parent
		for i in range(self.mixer.inputs_per_parent):
			self.mixer.inputs[free+i] = self.stream, i%self.channel.channels
		self.input = free

	def destroy(self):
		self.remove_from_mixer()
		self.decoder.destroy()

	def remove_from_mixer(self):
		for i in range(self.mixer.inputs_per_parent):
			self.mixer.inputs[self.input+i] = None

class TextClient(BaseClient):
	def __init__(self, *args, **kwargs):
		super(TextClient, self).__init__(*args, **kwargs)
		self.input_queue = Queue.Queue()
		self.input_thread = threading.Thread(target=self.receive_input)
		self.input_thread.daemon = True
		self.input_thread.start()
		self.new_connection = None

	def on_connect(self, peer):
		super(TextClient, self).on_connect(peer)
		print "connected to server"
		self.login(self.nickname)
		self.send_server_message('join', channel='lobby')

	def msg_join(self, message):
		super(TextClient, self).msg_join(message)
		user = message['user']
		print "%s joined the channel" % message['user']['nickname']

	def msg_joined(self, message):
		super(TextClient, self).msg_joined(message)
		print "Joined channel %s with frequency %d and %d channels" % (self.channel.name, self.channel.frequency, self.channel.channels)
		members = [m['nickname'] for m in message['channel']['members']]
		members = ", ".join(members)
		print "Members: %s" % members

	def msg_part(self, message):
		super(TextClient, self).msg_part(message)
		print "%s left the channel." % message['user']['nickname']

	def msg_message(self, data):
		sender = data['sender']['nickname']
		message = data['message']
		print "Message from %s: %s" % (sender, message)

	def msg_channels(self, data):
		for channel in data['channels']:
			print "{name}, {member_count} members, {channels} channels, frequency {frequency}".format(
			name=channel['name'], channels=channel['channels'], frequency=channel['frequency'], member_count=len(channel['members']))

	def reconnect(self):
		super(TextClient, self).reconnect()
		print "reconnecting..."

	def on_disconnect(self, peer):
		super(TextClient, self).on_disconnect(peer)
		if self.new_connection:
			self.connect(self.new_connection)
			self.new_connection = None

	def tick(self):
		super(TextClient, self).tick()
		self.process_input_queue()

	def receive_input(self):
		while True:
			line = raw_input().strip()
			if line == '':
				continue
			self.input_queue.put(line)

	def process_input_queue(self):
		while True:
			try:
				item = self.input_queue.get_nowait()
			except Queue.Empty:
				return
			if item[0] == '/':
				command, sep, args = item[1:].partition(' ')
				args = args.strip()
				fn = getattr(self, 'cmd_%s' % command.lower(), None)
				if fn is None:
					print "Unknown command %s" % command
					continue
				fn(args)
			else:
				if not self.connection:
					print "Not connected to server"
					return
				self.send_server_message('chat', message=item)

	def cmd_mute(self, args):
		"""Toggle mute status on your audio"""
		if not self.muted:
			self.muted = True
			print "Muted"
		else:
			self.muted = False
			print "unmuted"

	def cmd_volume(self, args):
		"""Control master volume as a percentage"""
		try:
			value = int(args)/100.0
		except ValueError:
			print "Invalid volume %s" % args
			return
		self.attenuator.multiplier = value

	def cmd_quit(self, args):
		"""Quit the client"""
		if self.connection:
			self.send_server_message('logout', message=args)
			self.disconnect()
			self.stop_after_disconnect = True
		else:
			self.running = False

	def cmd_rms(self, args):
		"""Adjust voice activation level"""
		if not args:
			print "Current rms level is %d" % self.channel.rms_threshold
			return
		try:
			value = int(args)
			if value < 0:
				raise ValueError
		except ValueError:
			print "Invalid value"
			return
		self.channel.rms_threshold = value

	def cmd_join(self, args):
		"""Join the specified channel"""
		if not args:
			print "Must supply a channel"
			return
		self.send_server_message('join', channel=args)

	def cmd_part(self, args):
		"""Part the current channel"""
		self.send_server_message('part')

	def cmd_help(self, args):
		"""Get a list of commands"""
		for command in dir(self):
			if not command.startswith('cmd_'):
				continue
			info = "/%s " % command.split('_')[-1]
			doc = getattr(self, command).__doc__
			if doc:
				info += doc
			print info

	def cmd_users(self, args):
		"""Show a list of users on the current channel"""
		members = ", ".join([m.nickname for m in self.channel.users.values()])
		print "Members: %s" % members

	def cmd_disconnect(self, args):
		"""Disconnects from the current server"""
		self.disconnect()

	def cmd_server(self, args):
		"""Connect to a server"""
		if self.connection:
			self.disconnect()
			self.new_connection = args
		else:
			self.connect(args)

	def cmd_msg(self, args):
		"""Send a message to the specified user"""
		split = args.split(' ')
		if len(split) < 2:
			print "Usage: /msg <user> <message>"
			return
		user = split[0]
		message = ' '.join(split[1:])
		self.send_server_message('message', recipient=user, message=message)

	def cmd_list(self, args):
		self.send_server_message('channels')

	def cmd_printrms(self, args):
		self.channel.print_rms = not self.channel.print_rms
		print self.channel.print_rms

@click.command()
@click.option('-d', '--debug', is_flag=True, help='Enable debug features')
@click.argument('hostname', required=False)
@click.argument('nickname', default=getpass.getuser())
def main(debug, hostname, nickname):
	libaudioverse.initialize()
	global debug_mode
	debug_mode = debug
	c = TextClient(nickname=nickname)
	if hostname:
		c.connect(hostname)
	c.run()
	libaudioverse.shutdown()

if __name__ == '__main__':
	try:
		main()
	except KeyboardInterrupt:
		pass
