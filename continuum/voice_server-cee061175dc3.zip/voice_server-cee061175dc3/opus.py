import platform
from ctypes import *
from ctypes.util import find_library
if platform.system() == 'Windows':
	lib = cdll['libopus-0.dll']
else:
	lib = cdll[find_library('opus')]

class OpusError(Exception):
	pass

OPUS_APPLICATION_VOIP = 2048
OPUS_APPLICATION_AUDIO = 2049
OPUS_APPLICATION_RESTRICTED_LOWDELAY = 2051
lib.opus_encode.argtypes = (c_void_p, POINTER(c_int16), c_int, c_char_p, c_int32)
lib.opus_encode.restype = c_int32

class Encoder(object):

	def __init__(self, fs=48000, channels=2, application=OPUS_APPLICATION_AUDIO):
		error = c_int()
		self.handle = lib.opus_encoder_create(fs, channels, application, pointer(error))

	def encode(self, pcm, frame_size):
		pcm = cast(pcm, POINTER(c_int16))
		max_data_bytes = 4096
		data = create_string_buffer(max_data_bytes)
		bytes = lib.opus_encode(self.handle, pcm, frame_size, data, max_data_bytes)
		return string_at(data, bytes)

class Decoder(object):
	def __init__(self, fs=48000, channels=2):
		error = c_int()
		self.channels = channels
		self.handle = lib.opus_decoder_create(fs, channels, pointer(error))

	def decode(self, packet):
		max_size = 960*6
		data = create_string_buffer(max_size*2*self.channels)
		frame_size = lib.opus_decode(self.handle, packet, len(packet), data, max_size, 0)
		if frame_size < 0:
			raise OpusError("Decoding returned frame_size %d" % frame_size)
		return string_at(data, frame_size*2*self.channels)

	def destroy(self):
		lib.opus_decoder_destroy(self.handle)
