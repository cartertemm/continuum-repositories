import os
import time
import enet
from ctypes import string_at
import json
import struct
import re
import logging
logging.basicConfig(level='INFO')
logger = logging.getLogger("server")
import yaml

class Server(object):

	CONTROL_RE = re.compile(r'[\x01-\x1f]')
	def __init__(self, port=1234):
		self.users = {}
		self.host = enet.Host(enet.Address(b'', port), 100, 2, 0, 0)
		self.channels = {}

	def run(self):
		i=0
		while True:
			event = self.host.service(1000)
			if event.type == enet.EVENT_TYPE_NONE:
				continue
			elif event.type == enet.EVENT_TYPE_CONNECT:
				self.on_connect(event)
			elif event.type == enet.EVENT_TYPE_DISCONNECT:
				self.on_disconnect(event)
			elif event.type == enet.EVENT_TYPE_RECEIVE:
				if event.channel_id == 0:
					self.on_server_message(event)
				else:
					self.on_voice_message(event)
				event.packet.destroy()
			else:
				print "Unknown event %s" % event.type

	def on_connect(self, event):
		print "connection from ", event.peer.address.host
		user = User(event.peer)
		print "User %d created" % user.id
		self.users[event.peer] = user
		user.send_server_message('connected', user_id=user.id)

	def on_voice_message(self, event):
		if event.channel_id != 1:
			print "unknown message received on channel %d" % event.channel_id
			return
		user = self.users[event.peer]
		if user.channel is None:
			return
		user.channel.send_voice_data(user, event.packet.data)

	def on_server_message(self, event):
		data = event.packet.data
		current_user = self.users[event.peer]
		data = json.loads(data)
		print data
		if 'type' not in data:
			print "Missing type: %s" % data
			return
		fn = getattr(self, "msg_%s" % (data['type'],), None)
		if not fn:
			print "function msg_%s not found" % data['type']
			return
		fn(current_user, data)

	def on_disconnect(self, event):
		user = self.users[event.peer]
		self.disconnect(user)

	def disconnect(self, user):
		if user.channel is not None:
			user.channel.part(user)
		del self.users[user.peer]
		print "user %d disconnected." % user.id

	def msg_chat(self, current_user, data):
		if 'message' not in data:
			print "field message missing from %r" % data
			return
		if not current_user.nickname:
			return #Not logged in
		if not current_user.channel:
			return
		if self.CONTROL_RE.search(data['message']):
			return
		current_user.channel.chat(current_user, data['message'])

	def msg_message(self, current_user, data):
		nickname = data['recipient']
		recipient = None
		for user in self.users.values():
			if user.nickname.lower() == nickname.lower():
				recipient = user
		if recipient is None:
			print "Could not find recipient %s" % nickname
			return
		sender = current_user.to_dict()
		recipient.send_server_message('message', message=data['message'], sender=sender)


	def msg_login(self, current_user, data):
		current_user.nickname = data['nickname']

	def msg_logout(self, current_user, message):
		print "logout"
		self.disconnect(current_user)

	def msg_part(self, current_user, message):
		if current_user.channel is None:
			return
		current_user.channel.part(current_user)

	def add_channel(self, channel):
		self.channels[channel.name] = channel
		channel.server = self
		logger.info("Added {type} channel {name}, frequency {frequency} channels {channels}".format(
		name=channel.name, frequency=channel.frequency, channels=channel.channels, type=channel.type))

	def msg_join(self, user, message):
		if not user.nickname:
			return #Not logged in
		channel = message['channel']
		if channel in self.channels:
			if user.channel is not None:
				user.channel.part(user)
			self.channels[channel].join(user)

	def msg_channels(self, user, message):
		data = [channel.to_dict() for channel in self.channels.itervalues()]
		user.send_server_message('channels', channels=data)

class User(object):
	id = 1

	def __init__(self, peer):
		self.id = User.id
		User.id += 1
		self.peer = peer
		self.channel = None
		self.nickname = ""

	def send(self, id, channel, message, flags=0):
		packed_user = struct.pack('l', id)
		packet = enet.Packet(packed_user+message, flags)
		self.peer.send(channel, packet)

	def send_server_message(self, type, **data):
		message = {'type': type, }
		message.update(**data)
		message = json.dumps(message)
		packet = enet.Packet(message, enet.PACKET_FLAG_RELIABLE)
		self.peer.send(0, packet)

	def to_dict(self):
		return {'nickname': self.nickname, 'id': self.id}

class Channel(object):

	def __init__(self, server, frequency=48000, channels=1, parent=None, name=None, password=None, type="normal"):
		self.server = server
		self.frequency = frequency
		self.channels = channels
		self.parent = parent
		self.name = name
		self.password = password
		self.members = {}
		self.operators = set()
		self.banned_users = set()
		self.history = []
		self.history_limit = 20
		self.type = type

	def join(self, member):
		print 'User %d joined %s' % (member.id, self.name)
		self.send_server_message('join', user=member.to_dict())
		self.members[member.id] = member
		member.channel = self
		member.send_server_message('joined', channel=self.to_dict())
		member.send_server_message('history', history=self.history)

	def part(self, member):
		self.send_server_message('part', user=member.to_dict())
		del self.members[member.id]
		member.channel = None

	def chat(self, sender, message):
		self.send_server_message('chat', sender_id=sender.id, sender_nick=sender.nickname, message=message)
		self.history.append({'time': time.time(), 'sender': sender.id, 'sender_nick': sender.nickname, 'message': message})
		if len(self.history) >= self.history_limit:
			self.history.pop(0)

	def send_server_message(self, *args, **kwargs):
		for user in self.members.values():
			user.send_server_message(*args, **kwargs)

	def send_voice_data(self, sender, data):
		for user in self.members.values():
			if self.type != 'echo' and user == sender:
				continue
			user.send(sender.id, 1, data)

	def to_dict(self):
		members = [m.to_dict() for m in self.members.itervalues()]
		return {'name': self.name, 'frequency': self.frequency, 'channels': self.channels, 'type': self.type, 'members': members}

if __name__ == '__main__':
	config = {'channels': []}
	config_file = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'config.yml')
	if not os.path.exists(config_file):
		logger.warning("Configuration file %s not found, adding default lobby." % config_file)
	else:
		with open(config_file, 'rb') as fp:
			config = yaml.load(fp)
	s = Server()
	for c in config['channels']:
		chan = Channel(server=s, **c)
		s.add_channel(chan)
	if not s.channels:
		s.add_channel(Channel(s, name='lobby'))
	s.run()
