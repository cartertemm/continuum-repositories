import sound_lib
import libaudioverse
from distutils.core import setup
import py2exe
data_files = [
('', ['enet.dll', 'libopus-0.dll']),
]

setup(
 data_files = sound_lib.find_datafiles()+libaudioverse.find_datafiles()+data_files,
console=['client.py'],
options={
"py2exe": {
"excludes": ['win32com.gen_py'],
}
}
)
