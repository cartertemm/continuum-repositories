from setuptools import setup, find_packages

__version__ = 0.1
__doc__ = """Package for parsing and rendering various fiction websites to a standard format"""
__author__ = u'Tyler Spivey'

setup(
 name = u'web_fiction',
 version = __version__,
 author = __author__,
 author_email = u'tspivey@pcdesk.net',
 description = __doc__,
 package_dir = {'web_fiction': 'web_fiction'},
 packages = find_packages(),
 classifiers = [
  'Development Status :: 3 - Alpha',
  'Intended Audience :: Developers',
  'Programming Language :: Python',
  'License :: OSI Approved :: MIT License',
  'Topic :: Software Development :: Libraries',
 ],
zip_safe=False,
)
