from fanfiction import FanfictionParser
from fictionpress import FictionpressParser

parsers = [
FanfictionParser,
FictionpressParser,
]

def find_parser(url):
 for p in parsers:
  if p.handles(url):
   return p
 raise NotImplementedError, "No parser available for this URL"
