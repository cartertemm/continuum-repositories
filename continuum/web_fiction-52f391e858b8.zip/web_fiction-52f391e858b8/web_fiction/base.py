class ParseError(Exception):
 pass
class BaseParser(object):
 """The base parser for fanfiction websites.
 Anything inheriting this should override handles(url), and provide a download(url) method."""
 @classmethod
 def handles(cls, url):
  return False
