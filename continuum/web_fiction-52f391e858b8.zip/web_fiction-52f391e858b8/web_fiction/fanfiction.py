from base import BaseParser, ParseError
import StringIO
import gzip
import re
import urllib2
import lxml
import lxml.html
import requests
chapters_re = re.compile(r"- Chapters: (\d+)")
from lxml.cssselect import CSSSelector
TEXT_SELECTOR = CSSSelector("div.storytext")

class FanfictionParser(BaseParser):
 url_re = re.compile(r'^http://(www\.)?fanfiction.net/s/(\d+)')
 url_string = "http://www.fanfiction.net/s/%(sid)s/%(chapter)s"

 @classmethod
 def handles(cls, url):
  if cls.url_re.match(url):
   return True
  return False

 def download(self, url, callback=None):
  sid = self.url_re.match(url).group(2)
  self.real_callback = callback
  self.chapters_fetched = 0
  self.last_chapter = None
  self.chapters = []
  session = requests.session()
  session.headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:23.0) Gecko/20100101 Firefox/23.0'
 #first, download chapter 1, synchronously.
  text = self.download_chapter(session, sid, 1)
  self.chapter_info = new_info(text)
  self.last_chapter = self.chapter_info['last_chapter']
  self.chapters.append(text)
  #and the rest
  for i in range(2, self.chapter_info['last_chapter'] + 1):
   text = self.download_chapter(session, sid, i)
   self.chapters.append(text)

 def download_chapter(self, session, sid, chapter):
  url = self.url_string % {'sid':sid, 'chapter':chapter}
  r = session.get(url)
  self.download_callback()
  #and get its info
  r.encoding = 'utf-8'
  return r.text

 def download_callback(self):
  self.chapters_fetched += 1
  if self.real_callback is not None:
   self.real_callback(self.chapters_fetched, self.last_chapter)

 def find_title(self):
  return self.chapter_info['title']
  

 def get_chapters(self):
  for i, c in enumerate(self.chapters):
   yield (i+1, _chapter_to_html(c))

 def info(self):
  return self.chapter_info

def is_valid_chapter(chapterText):
 if "</html>" not in chapterText: return False
 if chapterText.find("storytext") > 0:
  return True
 return False

title_re = re.compile(r"<b class='xcontrast_txt'>(.+?)</b>")
share_re = re.compile(r"<div class='a2a_kit a2a_default_style' style='float:right;margin-left:10px;border:none;'>.*?</div>", re.S|re.M)
storytext_re = re.compile(r"(?:<div class='storytext xcontrast_txt' id='storytext'>|<div id=storytext [^>]+>)(.*?)</div>", re.M|re.S)

def _chapter_to_html(c, write_title=False):
 writer = StringIO.StringIO()
 if write_title:
  t = title_re.search(c)
  if t: writer.write(t.group(1)+"<br>\n")
#now for the share links
 c = share_re.sub('', c)
 tree = lxml.html.fromstring(c)
 story = TEXT_SELECTOR(tree)[0]
 text = lxml.html.tostring(story)
 writer.write(text+"\n")
 return writer.getvalue()

#new info#
rating_re = re.compile(r'Rated: .+?>(.+?)<\/a> - +(.+?) - (.*) - (.*?Published: \d+-\d+-\d+)', re.I)
author_re = re.compile(r"Author:</span> <a class='xcontrast_txt' href='[^']+'>(.+?)</a>")
dateu_re = re.compile(r'Updated: (\d+-\d+-\d+)')
datep_re = re.compile(r'Published: (\d+-\d+-\d+)')
category_re = re.compile(r"\">(.+?)</a> <span class=xcontrast_txt>\&#187;</span>\n")
summary_re = re.compile(r"<div style='margin-top:2px' class='xcontrast_txt'>(.+?)</div>")
uid_re = re.compile(r"/u/(\d+)/")
network_re = re.compile(r'<title>(.+?)</title>')
def new_info(s):
 dct = {}
 s = s.replace('\r\n', '\n')
 h = rating_re.search(s)
 title = title_re.search(s).group(1)
 #fix escaped apostrophes
 title = title.replace(r"\'", "'")
 published = datep_re.search(s).group(1)
 updated = dateu_re.search(s)
 if updated:
  updated = updated.group(1)
 else:
  updated = published
 author = author_re.search(s).group(1)
 completed = '- Complete -' in h.group(0)
 last_chapter = chapters_re.search(s)
 if last_chapter:
  last_chapter = last_chapter.group(1)
 else:
  last_chapter = 1
 category = category_re.search(s).group(1)
 summary = summary_re.search(s).group(1)
 uid = int(uid_re.search(s).group(1))
 network = network_re.search(s).group(1)
 if network.endswith('FanFiction'):
  network = 'ff'
 elif network.endswith("FictionPress"):
  network = 'fp'
 else:
  raise Error, "Story has no network, neither ffn nor fp"
 rating = h.group(1).strip()
 lang = h.group(2).strip()
 chapters =  chapter_names(s)
 (genre, characters) = genre_and_characters(s)
 return {
  'title': title,
  'completed': completed,
  'updated': updated,
  'last_chapter': int(last_chapter),
  'category':category,
  'uid': uid,
  'author': author,
  'network':network,
  'published': published,
  'summary': summary,
  'chapters': chapters,
  'genre': genre,
  'characters': characters.decode('utf-8'),
'rating': rating,
'language': lang
 }

def _unescape_javascript_string(string_):
    """Removes JavaScript-specific string escaping characters."""
    return string_.replace("\\'", "'").replace('\\"', '"').replace('\\\\', '\\')
select_re = re.compile(r'<select[^>]*.*?</select>', re.I|re.S|re.M)

def chapter_names(s):
 matches = ''.join(select_re.findall(s))
 s=matches
 lst = []
 tree = lxml.html.fromstring(s)
 select = tree.xpath('.//select[@name="chapter"]')
 if not select: return []
 for item in lxml.etree.ElementTextIterator(select[-1]):
  (chapter, title) = item.split('. ', 1)
  lst.append((chapter, title))
 return lst
def genre_and_characters(s):
 genre = characters = ''
 m = rating_re.search(s)
 tokens = [token.strip() for token in m.group(3).split(' - ')]
 stopwords = ('Reviews:', 'Published:', 'Updated:', 'Chapters:', 'Words:')
 genres = (
    'General', 'Romance', 'Humor', 'Drama', 'Poetry', 'Adventure', 'Mystery',
    'Horror', 'Parody', 'Angst', 'Supernatural', 'Suspense', 'Sci-Fi',
    'Fantasy', 'Spiritual', 'Tragedy', 'Western', 'Crime', 'Family' ,'Hurt',
    'Comfort', 'Friendship'
)
 for token in tokens:
  if any(token.startswith(x) for x in stopwords):
   break
  if (token in genres) or any(t in genres for t in token.split('/')):
   genre = token
  #This is probably the character
  characters = token
 return (genre, characters)
