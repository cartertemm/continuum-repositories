import re

from fanfiction import FanfictionParser
class FictionpressParser(FanfictionParser):
 url_re = re.compile(r'^http://(www\.)?fictionpress.com/s/(\d+)')
 url_string = "http://www.fictionpress.com/s/%(sid)s/%(chapter)s"
