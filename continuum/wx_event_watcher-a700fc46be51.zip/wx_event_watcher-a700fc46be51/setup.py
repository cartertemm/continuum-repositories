from setuptools import setup

__version__ = "0.1"
__doc__ = """Log all events which occur in a wxPython application"""

setup(
 name = 'wx_event_watcher',
 version = __version__,
 description = __doc__,
 py_modules = ['wx_event_watcher'],
 zip_safe = False,
 classifiers = [
  'Development Status :: 3 - Alpha',
  'Intended Audience :: Developers',
  'Programming Language :: Python',
  'License :: OSI Approved :: MIT License',
  'Topic :: Software Development :: Libraries',
 ],
)
