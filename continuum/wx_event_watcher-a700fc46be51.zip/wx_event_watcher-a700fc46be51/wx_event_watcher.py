import re
import wx
import wx.dataview

class WXEventWatcher(object):
	unwanted_events = {wx.EVT_UPDATE_UI, wx.EVT_UPDATE_UI_RANGE, wx.EVT_IDLE, wx.EVT_PAINT, }


	def __init__(self, widget, events=None):
		self.widget = widget
		if events is None:
			events = list(self.find_all_wx_events())
		self.watched_events = events

	def find_wx_events(self, module=wx):
		for attr in dir(module):
			if not attr.startswith('EVT_'):
				continue
			resolved = getattr(module, attr)
			if not isinstance(resolved, wx.PyEventBinder):
				continue
			if resolved in self.unwanted_events:
				continue
			yield (module, attr, resolved)

	def find_all_wx_events(self):
		for module in (wx, wx.dataview):
			for module, name, event in self.find_wx_events(module):
				yield module, name, event

	def watch(self):
		for module, binder_name, event_binder in self.watched_events:
			self.widget.Bind(event_binder, lambda evt, module=module, event_binder=event_binder, binder_name=binder_name: self.on_event(evt, module=module, binder=event_binder, binder_name=binder_name ))

	def stop(self):
		for event_binder in self.watched_events:
			self.widget.Unbind(event_binder)

	def on_event(self, evt, module=None, binder=None, binder_name=None):
		event_data = self.extract_event_data(evt)
		print "Received Event: %r bound from %s.%s with data %r" % (evt.__class__, module.__name__, binder_name, event_data)
		evt.Skip(True)

	unwanted_event_attributes = {'GetLoggingOff', 'GetClassName', 'GetClientData', 'GetClientObject', 'GetLogicalPosition', }

	def extract_event_data(self, event):
		event_args = {}
		for attribute_name in dir(event):
			if attribute_name.startswith('Get') and attribute_name not in self.unwanted_event_attributes:
				translated_name = case_to_underscore(attribute_name[3:])
				event_args[translated_name] = getattr(event, attribute_name)()
		return event_args

def case_to_underscore(s):
 return s[0].lower() + re.sub(r'([A-Z])', lambda m:"_" + m.group(0).lower(), s[1:])

